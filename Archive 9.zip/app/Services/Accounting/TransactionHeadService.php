<?php

namespace App\Services\Accounting;

use App\Models\AccountingOption;
use App\Models\AccountingRule;
use App\Models\ChartOfAccount;
use App\Models\TransactionHead;
use App\Support\TransactionTypes;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;

class TransactionHeadService
{
    public function __construct(
        private readonly AccountingOptionService $optionService,
        private readonly AutomaticCodeService $automaticCodeService,
    ) {}

    /** @return array<string, mixed> */
    public function pageData(int $companyId, array $filters = []): array
    {
        $filters = $this->normaliseFilters($filters);
        $transactionCategories = $this->optionService->forGroup(AccountingOption::GROUP_TRANSACTION_CATEGORY);
        $categoryLabels = $this->optionService->labels(AccountingOption::GROUP_TRANSACTION_CATEGORY);
        $partyTypeLabels = $this->optionService->labels(AccountingOption::GROUP_RULE_PARTY_TYPE);
        $settlementLabels = $this->optionService->labels(AccountingOption::GROUP_SETTLEMENT_TYPE);

        $transactionHeads = TransactionHead::query()
            ->with(['postingAccount', 'accountingRule'])
            ->where('company_id', $companyId)
            ->orderBy('category')
            ->orderBy('code')
            ->get();

        $accountingRules = AccountingRule::query()
            ->where('company_id', $companyId)
            ->orderBy('category')
            ->orderBy('code')
            ->get(['id', 'transaction_head_id', 'code', 'name', 'category', 'settlement_type', 'is_active']);

        $rulesByHead = $accountingRules
            ->whereNotNull('transaction_head_id')
            ->groupBy(fn (AccountingRule $rule): int => (int) $rule->transaction_head_id);

        $templateRulesByScope = $accountingRules
            ->whereNull('transaction_head_id')
            ->groupBy(fn (AccountingRule $rule): string => $this->ruleScopeKey($rule->category, $rule->settlement_type));

        $transactionHeads->each(function (TransactionHead $head) use ($rulesByHead, $templateRulesByScope): void {
            $allowedSettlementCodes = $head->allowedSettlementCodes();
            $headSpecificRules = collect($rulesByHead->get((int) $head->id, []))->values();
            $headSpecificBySettlement = $headSpecificRules
                ->groupBy(fn (AccountingRule $rule): string => strtoupper((string) $rule->settlement_type));
            $templateRules = collect();
            $applicableRules = collect();

            foreach ($allowedSettlementCodes as $settlementType) {
                $settlementKey = strtoupper((string) $settlementType);
                $specificRulesForSettlement = collect($headSpecificBySettlement->get($settlementKey, []));

                if ($specificRulesForSettlement->isNotEmpty()) {
                    $applicableRules = $applicableRules->merge($specificRulesForSettlement);
                    continue;
                }

                $rulesForSettlement = collect(
                    $templateRulesByScope->get($this->ruleScopeKey($head->category, $settlementType), [])
                );

                $templateRules = $templateRules->merge($rulesForSettlement);
                $applicableRules = $applicableRules->merge($rulesForSettlement);
            }

            if ($head->accountingRule) {
                $applicableRules->push($head->accountingRule);
                $headSpecificRules->push($head->accountingRule);
            }

            $applicableRules = $applicableRules->unique('id')->values();
            $headSpecificRules = $headSpecificRules->unique('id')->values();
            $templateRules = $templateRules->unique('id')->values();

            $head->setRelation('applicableAccountingRules', $applicableRules);
            $head->setAttribute('applicable_accounting_rules_count', $applicableRules->count());
            $head->setAttribute('active_applicable_accounting_rules_count', $applicableRules->where('is_active', true)->count());
            $head->setAttribute('head_specific_accounting_rules_count', $headSpecificRules->count());
            $head->setAttribute('template_accounting_rules_count', $templateRules->count());
        });

        $allTransactionHeadsCount = $transactionHeads->count();
        $transactionHeads = $this->filterTransactionHeads(
            $transactionHeads,
            $filters,
            $categoryLabels,
            $partyTypeLabels,
            $settlementLabels,
        );

        $coaTypeOptions = ChartOfAccount::query()
            ->where('company_id', $companyId)
            ->where('level', 3)
            ->whereNotNull('type')
            ->distinct()
            ->orderBy('type')
            ->pluck('type')
            ->filter()
            ->values()
            ->all();
        $coaTypeOptions = collect(['Asset', 'Liability', 'Income', 'Expense', 'Equity', ...$coaTypeOptions])
            ->unique()
            ->values();

        return [
            'transactionHeads' => $transactionHeads,
            'allTransactionHeadsCount' => $allTransactionHeadsCount,
            'filteredTransactionHeadsCount' => $transactionHeads->count(),
            'transactionHeadFilters' => $filters,
            'coaTypeOptions' => $coaTypeOptions,
            'accountingRules' => $accountingRules,
            'postingAccounts' => ChartOfAccount::query()
                ->where('company_id', $companyId)
                ->where('level', 3)
                ->orderBy('code')
                ->get(),
            'transactionCategories' => $transactionCategories,
            'categoryLabels' => $categoryLabels,
            'settlementTypes' => $this->optionService->forGroup(AccountingOption::GROUP_SETTLEMENT_TYPE),
            'settlementLabels' => $settlementLabels,
            'transactionTypeDefinitions' => $transactionCategories->mapWithKeys(fn (AccountingOption $option): array => [
                $option->value => TransactionTypes::configuredDefinition(
                    $option->value,
                    is_array($option->metadata) ? $option->metadata : [],
                    $option->label,
                ),
            ])->all(),
            'partyTypes' => $this->optionService->forGroup(AccountingOption::GROUP_RULE_PARTY_TYPE),
            'partyTypeLabels' => $partyTypeLabels,
        ];
    }

    /** @param array<string, mixed> $filters */
    private function normaliseFilters(array $filters): array
    {
        return [
            'search' => trim((string) ($filters['search'] ?? '')),
            'transaction_type' => trim((string) ($filters['transaction_type'] ?? '')),
            'coa_type' => trim((string) ($filters['coa_type'] ?? '')),
            'party_type' => trim((string) ($filters['party_type'] ?? '')),
            'accounting_rule' => trim((string) ($filters['accounting_rule'] ?? '')),
        ];
    }

    /**
     * @param Collection<int, TransactionHead> $transactionHeads
     * @param array<string, string> $filters
     * @param array<string, string> $categoryLabels
     * @param array<string, string> $partyTypeLabels
     * @param array<string, string> $settlementLabels
     * @return Collection<int, TransactionHead>
     */
    private function filterTransactionHeads(
        Collection $transactionHeads,
        array $filters,
        array $categoryLabels,
        array $partyTypeLabels,
        array $settlementLabels,
    ): Collection {
        $search = strtolower($filters['search'] ?? '');
        $transactionType = $filters['transaction_type'] ?? '';
        $coaType = $filters['coa_type'] ?? '';
        $partyType = $filters['party_type'] ?? '';
        $accountingRule = $filters['accounting_rule'] ?? '';

        return $transactionHeads
            ->filter(function (TransactionHead $head) use (
                $search,
                $transactionType,
                $coaType,
                $partyType,
                $accountingRule,
                $categoryLabels,
                $partyTypeLabels,
                $settlementLabels,
            ): bool {
                if ($transactionType !== '' && (string) $head->category !== $transactionType) {
                    return false;
                }

                if ($coaType !== '' && (string) ($head->postingAccount?->type ?? '') !== $coaType) {
                    return false;
                }

                $headPartyType = (string) ($head->party_type ?: 'Any');
                if ($partyType !== '' && $headPartyType !== $partyType) {
                    return false;
                }

                $rules = collect($head->getRelation('applicableAccountingRules') ?? []);
                if ($accountingRule !== '') {
                    $activeRuleCount = (int) ($head->active_applicable_accounting_rules_count ?? 0);
                    $totalRuleCount = (int) ($head->applicable_accounting_rules_count ?? 0);

                    if ($accountingRule === '__with_rule' && $totalRuleCount < 1) {
                        return false;
                    }

                    if ($accountingRule === '__without_rule' && $totalRuleCount > 0) {
                        return false;
                    }

                    if ($accountingRule === '__active_rule' && $activeRuleCount < 1) {
                        return false;
                    }

                    if ($accountingRule === '__inactive_rule' && ! ($totalRuleCount > 0 && $activeRuleCount < 1)) {
                        return false;
                    }

                    if (ctype_digit($accountingRule) && ! $rules->contains(fn (AccountingRule $rule): bool => (int) $rule->id === (int) $accountingRule)) {
                        return false;
                    }
                }

                if ($search === '') {
                    return true;
                }

                $searchableParts = [
                    $head->code,
                    $head->name,
                    $head->category,
                    $categoryLabels[(string) $head->category] ?? '',
                    $head->postingAccount?->code,
                    $head->postingAccount?->name,
                    $head->postingAccount?->type,
                    $headPartyType,
                    $partyTypeLabels[$headPartyType] ?? '',
                    collect($head->allowedSettlementCodes())->map(fn (string $value): string => $settlementLabels[$value] ?? $value)->join(' '),
                    $rules->map(fn (AccountingRule $rule): string => trim($rule->code.' '.$rule->name.' '.$rule->category.' '.$rule->settlement_type))->join(' '),
                ];

                $haystack = strtolower(implode(' ', array_filter($searchableParts, static fn ($value): bool => filled($value))));

                return str_contains($haystack, $search);
            })
            ->values();
    }

    private function ruleScopeKey(string|null $category, string|null $settlementType): string
    {
        return strtolower((string) $category).'|'.strtoupper((string) $settlementType);
    }

    /** @param array<string, mixed> $data */
    public function create(array $data, int $companyId): TransactionHead
    {
        $this->validateSetup($data, $companyId);

        return DB::transaction(function () use ($data, $companyId): TransactionHead {
            $this->automaticCodeService->lockCompany($companyId);
            $data['code'] = $this->automaticCodeService->transactionHeadCode($companyId, (string) $data['name']);

            return TransactionHead::query()->create([
                'company_id' => $companyId,
                ...$this->normalized($data),
            ]);
        }, attempts: 5);
    }

    /** @param array<string, mixed> $data */
    public function update(TransactionHead $head, array $data): TransactionHead
    {
        $this->validateSetup($data, (int) $head->company_id, $head);
        DB::transaction(function () use ($head, $data): void {
            $this->automaticCodeService->lockCompany((int) $head->company_id);
            $data['code'] = str_starts_with(strtoupper((string) $head->code), 'SYS-FEED-')
                || (string) $data['name'] === (string) $head->name
                ? $head->code
                : $this->automaticCodeService->transactionHeadCode(
                    (int) $head->company_id,
                    (string) $data['name'],
                    (int) $head->id,
                );
            $head->update($this->normalized($data));
        }, attempts: 5);

        return $head->refresh();
    }


    /**
     * @param Collection<int, TransactionHead> $heads
     */
    public function setActive(Collection $heads, bool $active): int
    {
        if ($heads->isEmpty()) {
            return 0;
        }

        if ($active) {
            $this->validateBulkActivation($heads);
        }

        return DB::transaction(function () use ($heads, $active): int {
            $ids = $heads->pluck('id')->map(fn ($id): int => (int) $id)->all();

            TransactionHead::query()
                ->whereIn('id', $ids)
                ->lockForUpdate()
                ->get(['id']);

            return TransactionHead::query()
                ->whereIn('id', $ids)
                ->where('is_active', '!=', $active)
                ->update(['is_active' => $active]);
        }, attempts: 5);
    }

    /**
     * @param Collection<int, TransactionHead> $heads
     */
    private function validateBulkActivation(Collection $heads): void
    {
        $activeCategories = AccountingOption::query()
            ->forGroup(AccountingOption::GROUP_TRANSACTION_CATEGORY)
            ->where('is_active', true)
            ->get()
            ->keyBy('value');
        $activeSettlements = AccountingOption::query()
            ->forGroup(AccountingOption::GROUP_SETTLEMENT_TYPE)
            ->where('is_active', true)
            ->pluck('value')
            ->all();
        $activePartyTypes = AccountingOption::query()
            ->forGroup(AccountingOption::GROUP_RULE_PARTY_TYPE)
            ->where('is_active', true)
            ->pluck('value')
            ->all();

        $invalid = $heads->filter(function (TransactionHead $head) use (
            $activeCategories,
            $activeSettlements,
            $activePartyTypes,
        ): bool {
            $category = (string) $head->category;
            $categoryOption = $activeCategories->get($category);
            $account = $head->postingAccount;
            $settlements = $head->allowedSettlementCodes();
            $partyType = (string) ($head->party_type ?: 'Any');

            if (! $categoryOption || ! $account || ! $account->is_active || (int) $account->level !== 3) {
                return true;
            }

            if ((int) $account->company_id !== (int) $head->company_id) {
                return true;
            }

            if ($settlements === [] || array_diff($settlements, $activeSettlements) !== []) {
                return true;
            }

            if (! in_array($partyType, $activePartyTypes, true)) {
                return true;
            }

            $definition = TransactionTypes::configuredDefinition(
                $category,
                is_array($categoryOption->metadata) ? $categoryOption->metadata : [],
                $categoryOption->label,
            );
            $postingTypes = array_values((array) ($definition['posting_types'] ?? []));
            $allowedSettlements = array_values((array) ($definition['allowed_settlements'] ?? []));
            $expectedPartyType = (string) ($definition['party_type'] ?? 'Any');

            if ($allowedSettlements !== [] && array_diff($settlements, $allowedSettlements) !== []) {
                return true;
            }

            if ($expectedPartyType !== 'Any' && $partyType !== $expectedPartyType) {
                return true;
            }

            return $postingTypes !== [] && ! in_array($account->type, $postingTypes, true);
        });

        if ($invalid->isNotEmpty()) {
            $names = $invalid
                ->take(5)
                ->map(fn (TransactionHead $head): string => $head->code.' — '.$head->name)
                ->implode(', ');

            throw ValidationException::withMessages([
                'record_ids' => 'These transaction heads cannot be activated because their linked COA, transaction type, party type, or payment types are incomplete or inactive: '.$names.'. Edit and repair them first.',
            ]);
        }
    }

    public function delete(TransactionHead $head): void
    {
        if ($head->transactions()->exists()) {
            throw ValidationException::withMessages([
                'transaction_head' => 'Cannot delete. Used by transaction.',
            ]);
        }

        DB::transaction(fn () => $head->delete(), attempts: 5);
    }

    /** @param array<string, mixed> $data */
    private function validateSetup(array $data, int $companyId, ?TransactionHead $existingHead = null): void
    {
        if ($existingHead && str_starts_with(strtoupper((string) $existingHead->code), 'SYS-FEED-')) {
            $expectedCategory = str_starts_with(strtoupper((string) $existingHead->code), 'SYS-FEED-PUR')
                ? TransactionTypes::PURCHASE
                : TransactionTypes::SALE;
            $expectedPartyType = $expectedCategory === TransactionTypes::PURCHASE ? 'Supplier' : 'Customer';

            if (strcasecmp((string) $data['category'], $expectedCategory) !== 0) {
                throw ValidationException::withMessages([
                    'category' => 'The Feed module head must remain under the existing '.$expectedCategory.' transaction type.',
                ]);
            }

            if ((string) $data['party_type'] !== $expectedPartyType) {
                throw ValidationException::withMessages([
                    'party_type' => 'The Feed module head must keep the '.$expectedPartyType.' party type.',
                ]);
            }
        }

        $account = ChartOfAccount::query()
            ->whereKey($data['posting_account_id'])
            ->where('company_id', $companyId)
            ->where('level', 3)
            ->first();

        if (! $account) {
            throw ValidationException::withMessages([
                'posting_account_id' => 'Select a Level 3 posting ledger that belongs to this company.',
            ]);
        }

        $transactionType = (string) $data['category'];
        $supportedSettlements = TransactionTypes::settlementCodes();
        $selectedSettlements = array_values((array) $data['allowed_settlements']);

        if (array_diff($selectedSettlements, $supportedSettlements) !== []) {
            throw ValidationException::withMessages([
                'allowed_settlements' => 'One or more selected payment types are not supported by the system.',
            ]);
        }

        $transactionTypeOption = AccountingOption::query()
            ->forGroup(AccountingOption::GROUP_TRANSACTION_CATEGORY)
            ->where('value', $transactionType)
            ->first();
        $transactionDefinition = TransactionTypes::configuredDefinition(
            $transactionType,
            is_array($transactionTypeOption?->metadata) ? $transactionTypeOption->metadata : [],
            $transactionTypeOption?->label,
        );
        $allowedPostingTypes = array_values((array) ($transactionDefinition['posting_types'] ?? []));
        if ($allowedPostingTypes !== [] && ! in_array($account->type, $allowedPostingTypes, true)) {
            throw ValidationException::withMessages([
                'posting_account_id' => 'Select a '.implode(' or ', $allowedPostingTypes).' account for this transaction type.',
            ]);
        }

        $expectedPartyType = (string) ($transactionDefinition['party_type'] ?? 'Any');
        if ($expectedPartyType !== 'Any' && $data['party_type'] !== $expectedPartyType) {
            throw ValidationException::withMessages([
                'party_type' => 'This transaction type uses '.$expectedPartyType.' parties.',
            ]);
        }

        if ((bool) $data['is_active'] && ! $account->is_active) {
            throw ValidationException::withMessages([
                'is_active' => 'An active transaction head must use an active linked account.',
            ]);
        }
    }

    /** @param array<string, mixed> $data @return array<string, mixed> */
    private function normalized(array $data): array
    {
        return [
            'code' => trim((string) $data['code']),
            'name' => trim((string) $data['name']),
            'category' => $data['category'],
            'accounting_rule_id' => null,
            'posting_account_id' => (int) $data['posting_account_id'],
            'allowed_settlements' => array_values($data['allowed_settlements']),
            'party_type' => $data['party_type'],
            'is_active' => (bool) $data['is_active'],
        ];
    }
}
