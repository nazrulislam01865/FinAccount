<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <?php echo $__env->make('partials.head', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</head>
<body class="hg-body hg-sidebar-booting">
<div class="hg-app" id="hgAppShell" data-user-id="<?php echo e((int) auth()->id()); ?>">
    <?php echo $__env->make('partials.accounting.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <button type="button" class="hg-sidebar-backdrop" data-hg-sidebar-close aria-label="Close navigation menu"></button>

    <main class="hg-main">
        <header class="hg-topbar">
            <button
                type="button"
                class="hg-sidebar-toggle"
                id="hgSidebarToggle"
                aria-controls="hgAccountingSidebar"
                aria-expanded="false"
                aria-label="Open navigation menu"
            >
                <span class="hg-sidebar-toggle-lines" aria-hidden="true"><span></span><span></span><span></span></span>
                <span class="hg-visually-hidden">Open navigation menu</span>
            </button>

            <div class="hg-topbar-context">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(isset($topbar)): ?>
                    <?php echo e($topbar); ?>

                <?php else: ?>
                    <div class="hg-topbar-title"><?php echo e($title ?? 'HisebGhor'); ?></div>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </div>

            <div class="hg-topbar-account-controls" aria-label="Notification and account controls">
                <?php if (isset($component)) { $__componentOriginal4c63a40c710484926478a321e816540a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4c63a40c710484926478a321e816540a = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.accounting.notification-bell','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('accounting.notification-bell'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4c63a40c710484926478a321e816540a)): ?>
<?php $attributes = $__attributesOriginal4c63a40c710484926478a321e816540a; ?>
<?php unset($__attributesOriginal4c63a40c710484926478a321e816540a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4c63a40c710484926478a321e816540a)): ?>
<?php $component = $__componentOriginal4c63a40c710484926478a321e816540a; ?>
<?php unset($__componentOriginal4c63a40c710484926478a321e816540a); ?>
<?php endif; ?>
                <?php if (isset($component)) { $__componentOriginal636e8822b8f637b213dfdffdf585f2c4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal636e8822b8f637b213dfdffdf585f2c4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.accounting.user-menu','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('accounting.user-menu'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal636e8822b8f637b213dfdffdf585f2c4)): ?>
<?php $attributes = $__attributesOriginal636e8822b8f637b213dfdffdf585f2c4; ?>
<?php unset($__attributesOriginal636e8822b8f637b213dfdffdf585f2c4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal636e8822b8f637b213dfdffdf585f2c4)): ?>
<?php $component = $__componentOriginal636e8822b8f637b213dfdffdf585f2c4; ?>
<?php unset($__componentOriginal636e8822b8f637b213dfdffdf585f2c4); ?>
<?php endif; ?>
            </div>
        </header>

        <div class="hg-content">
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(session('success')): ?><div class="hg-alert hg-alert-success"><?php echo e(session('success')); ?></div><?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(session('login_notice')): ?><div class="hg-alert hg-alert-success"><?php echo e(session('login_notice')); ?></div><?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(session('error')): ?><div class="hg-alert hg-alert-danger"><?php echo e(session('error')); ?></div><?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(session('warning')): ?><div class="hg-alert hg-alert-warning"><?php echo e(session('warning')); ?></div><?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($errors->any() && ! $errors->profilePhoto->any() && ! $errors->passwordUpdate->any()): ?>
                <div class="hg-alert hg-alert-danger"><strong>Please correct the following:</strong><ul><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?><li><?php echo e($error); ?></li><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?></ul></div>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

            <?php
                $layoutCompany = \App\Support\CompanyContext::company();
            ?>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($layoutCompany && (! $layoutCompany->isSetupComplete() || ! $layoutCompany->isActiveForPosting())): ?>
                <div class="hg-alert hg-alert-warning">
                    <strong><?php echo e($layoutCompany->isSetupComplete() ? 'Company posting is inactive.' : 'Company Setup is incomplete.'); ?></strong>
                    <?php echo e($layoutCompany->isSetupComplete()
                        ? 'Activate the company before posting or updating transactions.'
                        : 'Select valid Business Type, Currency, Time Zone, and an Open Financial Year before posting transactions.'); ?>

                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(auth()->user()?->canAnyAccounting(['company_setup.view', 'company_setup.manage'])): ?>
                        <a href="<?php echo e(route('company-setup.edit')); ?>">Open Company Setup</a>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </div>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

            <?php echo e($slot); ?>

        </div>

        <?php if (isset($component)) { $__componentOriginal2406b976bc9b7a352210f63b9be43324 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2406b976bc9b7a352210f63b9be43324 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.accounting.footer','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('accounting.footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2406b976bc9b7a352210f63b9be43324)): ?>
<?php $attributes = $__attributesOriginal2406b976bc9b7a352210f63b9be43324; ?>
<?php unset($__attributesOriginal2406b976bc9b7a352210f63b9be43324); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2406b976bc9b7a352210f63b9be43324)): ?>
<?php $component = $__componentOriginal2406b976bc9b7a352210f63b9be43324; ?>
<?php unset($__componentOriginal2406b976bc9b7a352210f63b9be43324); ?>
<?php endif; ?>
    </main>
</div>

<?php if (isset($component)) { $__componentOriginal715f2f6278f8f07034c11ba3294db507 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal715f2f6278f8f07034c11ba3294db507 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.accounting.safe-delete-modal','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('accounting.safe-delete-modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal715f2f6278f8f07034c11ba3294db507)): ?>
<?php $attributes = $__attributesOriginal715f2f6278f8f07034c11ba3294db507; ?>
<?php unset($__attributesOriginal715f2f6278f8f07034c11ba3294db507); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal715f2f6278f8f07034c11ba3294db507)): ?>
<?php $component = $__componentOriginal715f2f6278f8f07034c11ba3294db507; ?>
<?php unset($__componentOriginal715f2f6278f8f07034c11ba3294db507); ?>
<?php endif; ?>
<div class="hg-toast" id="hgNotificationToast" role="status" aria-live="polite"></div>

<?php
    $pusherEnabled = filled(config('services.pusher.key'))
        && filled(config('services.pusher.secret'))
        && filled(config('services.pusher.app_id'))
        && filled(config('services.pusher.cluster'));
    $notificationAsset = public_path('js/hisebghor-notifications.js');
    $notificationAssetVersion = is_file($notificationAsset) ? filemtime($notificationAsset) : time();
?>
<script>
    window.HISEBGHOR_FORM_DRAFTS = {
        enabled: true,
        showUrlTemplate: <?php echo json_encode(route('accounting.form-drafts.show', ['draftKey' => '__DRAFT_KEY__']), 512) ?>,
        storeUrlTemplate: <?php echo json_encode(route('accounting.form-drafts.store', ['draftKey' => '__DRAFT_KEY__']), 512) ?>,
        destroyUrlTemplate: <?php echo json_encode(route('accounting.form-drafts.destroy', ['draftKey' => '__DRAFT_KEY__']), 512) ?>
    };
</script>
<script>
    window.HISEBGHOR_NOTIFICATIONS = {
        userId: <?php echo e((int) auth()->id()); ?>,
        feedUrl: <?php echo json_encode(route('accounting.notifications.feed'), 15, 512) ?>,
        readAllUrl: <?php echo json_encode(route('accounting.notifications.read-all'), 15, 512) ?>,
        readUrlTemplate: <?php echo json_encode(route('accounting.notifications.read', ['notification' => '__ID__']), 512) ?>,
        pusherAuthUrl: <?php echo json_encode(route('accounting.notifications.pusher-auth'), 15, 512) ?>,
        pusherEnabled: <?php echo json_encode($pusherEnabled, 15, 512) ?>,
        pusherKey: <?php echo json_encode(config('services.pusher.key'), 15, 512) ?>,
        pusherCluster: <?php echo json_encode(config('services.pusher.cluster'), 15, 512) ?>,
        pollIntervalMs: 60000
    };
</script>
<?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($pusherEnabled): ?>
    <script src="https://js.pusher.com/8.4.0/pusher.min.js"></script>
<?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
<script src="<?php echo e(asset('js/hisebghor-notifications.js')); ?>?v=<?php echo e($notificationAssetVersion); ?>"></script>
<?php
    $sessionAsset = public_path('js/hisebghor-session-timeout.js');
    $sessionAssetVersion = is_file($sessionAsset) ? filemtime($sessionAsset) : time();
    $sessionTimeoutMinutes = (int) config('session.inactive_timeout', env('SESSION_INACTIVE_TIMEOUT', 15));
?>
<script>
    window.HISEBGHOR_SESSION = {
        timeoutMs: <?php echo e(max(1, $sessionTimeoutMinutes) * 60 * 1000); ?>,
        keepAliveUrl: <?php echo json_encode(route('session.keep-alive'), 15, 512) ?>,
        timeoutUrl: <?php echo json_encode(route('session.timeout'), 15, 512) ?>,
        loginUrl: <?php echo json_encode(route('login'), 15, 512) ?>,
        storagePrefix: 'hisebghor.accounting.session'
    };
</script>
<script src="<?php echo e(asset('js/hisebghor-session-timeout.js')); ?>?v=<?php echo e($sessionAssetVersion); ?>"></script>
<?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel/hisebghor/resources/views/layouts/accounting.blade.php ENDPATH**/ ?>