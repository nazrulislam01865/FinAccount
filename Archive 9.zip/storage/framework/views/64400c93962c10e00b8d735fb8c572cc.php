<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['brand' => \App\Support\HisebGhorBrand::data()]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['brand' => \App\Support\HisebGhorBrand::data()]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<footer <?php echo e($attributes->class(['hg-footer'])); ?>>
    <span>&copy; <?php echo e(now()->year); ?> <?php echo e($brand['name'] ?? 'HisebGhor'); ?>. All rights reserved.</span>
    <span>
        System design, development, and intellectual property are owned by
        <a href="<?php echo e($brand['footer_owner_url'] ?? 'https://itqanconsulting.com/'); ?>" target="_blank" rel="noopener noreferrer">
            <strong><?php echo e($brand['footer_owner'] ?? 'ITQAN Consulting'); ?></strong>
        </a>
    </span>
</footer>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel/hisebghor/resources/views/components/accounting/footer.blade.php ENDPATH**/ ?>