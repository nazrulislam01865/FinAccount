<?php
    $systemBrand = \App\Support\HisebGhorBrand::data();
?>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />
<title><?php echo e(filled($title ?? null) ? $title.' - '.($systemBrand['name'] ?? config('app.name')) : ($systemBrand['name'] ?? config('app.name'))); ?></title>
<?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(!empty($systemBrand['favicon_url'])): ?>
<link rel="icon" href="<?php echo e($systemBrand['favicon_url']); ?>">
<link rel="shortcut icon" href="<?php echo e($systemBrand['favicon_url']); ?>">
<link rel="apple-touch-icon" href="<?php echo e($systemBrand['favicon_url']); ?>">
<?php else: ?>
<link rel="icon" href="/favicon.ico" sizes="any">
<link rel="icon" href="/favicon.svg" type="image/svg+xml">
<link rel="apple-touch-icon" href="/apple-touch-icon.png">
<?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
<?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/hisebghor-profile-notifications.css')); ?>?v=<?php echo e(is_file(public_path('css/hisebghor-profile-notifications.css')) ? filemtime(public_path('css/hisebghor-profile-notifications.css')) : '1'); ?>">
<?php echo app('flux')->fluxAppearance(); ?>

<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel/hisebghor/resources/views/partials/head.blade.php ENDPATH**/ ?>