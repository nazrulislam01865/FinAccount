<?php
    $company = \App\Support\PrintedDocumentBrand::company((array) ($company ?? []));
    $resolvedLogoUrl = \App\Support\PrintedDocumentBrand::logoDataUri($company['logo_path'] ?? null)
        ?: ($logoUrl ?? null);

    $documentLines = collect($documentLines ?? []);
    $lineCount = $documentLines->count();
    $densityClass = $lineCount > 10 ? 'ba-u-doc--compact' : ($lineCount > 6 ? 'ba-u-doc--dense' : '');
    $titleLength = function_exists('mb_strlen') ? mb_strlen((string) $documentTitle) : strlen((string) $documentTitle);
    $titleClass = $titleLength > 22 ? 'ba-u-title--xlong' : ($titleLength > 16 ? 'ba-u-title--long' : '');
    $preparedPosition = trim((string) ($preparedByPosition ?? ''));
?>

<?php echo $__env->make('accounting.partials.unified-document-styles', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<section class="ba-u-doc <?php echo e($densityClass); ?>" aria-label="<?php echo e($documentTitle); ?>">
    <header class="ba-u-header">
        <div class="ba-u-company">
            <div class="ba-u-logo">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(!empty($resolvedLogoUrl)): ?>
                    <img src="<?php echo e($resolvedLogoUrl); ?>" alt="<?php echo e($company['name'] ?? 'Company'); ?> logo">
                <?php else: ?>
                    <span><?php echo e(strtoupper(substr((string) ($company['short_name'] ?? $company['name'] ?? 'BA'), 0, 2))); ?></span>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </div>
            <div class="ba-u-company-divider" aria-hidden="true"></div>
            <div class="ba-u-company-copy">
                <h2><?php echo e($company['name'] ?? 'BASHIR AGRO'); ?></h2>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(!empty($company['address'])): ?><p><?php echo e($company['address']); ?></p><?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(!empty($company['phone'])): ?><p>Phone: <?php echo e($company['phone']); ?></p><?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(!empty($company['website'])): ?>
                    <p>
                        <a class="ba-u-website-link"
                           href="<?php echo e($company['website_url'] ?? $company['website']); ?>"
                           target="_blank"
                           rel="noopener noreferrer"><?php echo e($company['website']); ?></a>
                    </p>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </div>
        </div>

        <div class="ba-u-meta">
            <h1 class="<?php echo e($titleClass); ?>"><?php echo e($documentTitle); ?></h1>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $metaRows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $metaRow): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                <div class="ba-u-meta-row">
                    <span><?php echo e($metaRow['label']); ?></span><b>:</b><strong><?php echo e($metaRow['value'] ?: '-'); ?></strong>
                </div>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
        </div>
    </header>

    <div class="ba-u-rule"></div>

    <section class="ba-u-party">
        <div class="ba-u-party-title">
            <span class="ba-u-person" aria-hidden="true">
                <svg viewBox="0 0 24 24" fill="none"><circle cx="12" cy="8" r="3.25"></circle><path d="M6.75 18.2c.8-3.05 2.55-4.55 5.25-4.55s4.45 1.5 5.25 4.55"></path></svg>
            </span>
            <h3><?php echo e($partySectionTitle); ?></h3>
        </div>
        <div class="ba-u-party-grid">
            <span>Name</span><b>:</b><p><?php echo e($party['name'] ?? '-'); ?></p>
            <span>Address</span><b>:</b><p><?php echo e($party['address'] ?? '-'); ?></p>
            <span>Phone / Email</span><b>:</b><p><?php echo e($partyPhoneEmail ?: '-'); ?></p>
            <span>Purpose / Against</span><b>:</b><p><?php echo e($purpose ?: '-'); ?></p>
        </div>
    </section>

    <table class="ba-u-table">
        <thead>
            <tr>
                <th>DESCRIPTION</th>
                <th>REMARKS</th>
                <th>AMOUNT (<?php echo e($currencyLabel); ?>)</th>
            </tr>
        </thead>
        <tbody>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $documentLines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $line): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                <?php
                    $rawRemarkLines = $line['remarks_lines'] ?? null;
                    if (!is_array($rawRemarkLines)) {
                        $remarksText = str_replace(["\r\n", "\r"], "\n", trim((string) ($line['remarks'] ?? '-')));
                        $rawRemarkLines = preg_split('/\n+|\s*\|\s*/', $remarksText) ?: [];
                    }
                    $remarksLines = collect($rawRemarkLines)
                        ->flatten()
                        ->map(static fn ($value) => trim((string) $value))
                        ->filter(static fn ($value) => $value !== '')
                        ->values();
                    if ($remarksLines->isEmpty()) {
                        $remarksLines = collect(['-']);
                    }
                ?>
                <tr>
                    <td><?php echo e($line['description'] ?? '-'); ?></td>
                    <td class="ba-u-remarks">
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $remarksLines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $remarkLine): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                            <div class="ba-u-remark-line"><?php echo e($remarkLine); ?></div>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                    </td>
                    <td class="ba-u-right"><?php echo e(number_format((float) ($line['amount'] ?? 0), 2)); ?></td>
                </tr>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
        </tbody>
    </table>

    <section class="ba-u-lower">
        <div class="ba-u-left">
            <h3>AMOUNT IN WORDS</h3>
            <div class="ba-u-words"><?php echo e($amountInWords); ?></div>

            <h3>NOTES</h3>
            <div class="ba-u-notes"><?php echo e($notes ?? 'Thank you for your business.'); ?></div>
        </div>

        <div class="ba-u-right-stack">
            <table class="ba-u-summary">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $summaryRows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $summaryRow): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                    <tr class="<?php echo e(!empty($summaryRow['total']) ? 'ba-u-total' : ''); ?>">
                        <td><?php echo e($summaryRow['label']); ?></td>
                        <td><?php echo e($summaryRow['display'] ?? number_format((float) ($summaryRow['amount'] ?? 0), 2)); ?></td>
                    </tr>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
            </table>

            <div class="ba-u-prepared">
                <h3>PREPARED BY</h3>
                <div class="ba-u-prep-row"><span>Name</span><b>:</b><p><?php echo e($preparedByName); ?></p></div>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($preparedPosition !== ''): ?>
                    <div class="ba-u-prep-row"><span>Position</span><b>:</b><p><?php echo e($preparedPosition); ?></p></div>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                <div class="ba-u-prep-row"><span>Date</span><b>:</b><p><?php echo e($preparedDate); ?></p></div>
                <div class="ba-u-sign-area">
                    <span class="ba-u-sign-name"><?php echo e($preparedByName); ?></span>
                    <div class="ba-u-sign-line"></div>
                    <strong>DIGITAL SIGNATURE</strong>
                </div>
            </div>
        </div>
    </section>

    <footer class="ba-u-footer">
        <span class="ba-u-check" aria-hidden="true">✓</span>
        <em>This document is electronically generated and may not require a physical signature.</em>
    </footer>
</section>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel/hisebghor/resources/views/accounting/partials/unified-document.blade.php ENDPATH**/ ?>