<?php
    $user = auth()->user();
    $brand = \App\Support\HisebGhorBrand::data();
    $balanceSection = request()->routeIs('balances.*') ? request()->query('section', 'accounts') : null;
    $statementSection = request()->routeIs('basic-statements.*') ? request()->query('section', 'income') : null;
    $isReportRoute = request()->routeIs('reports.*');
    $canAnyConfiguration = $user?->canAnyAccounting([
        'company_setup.view', 'company_setup.manage',
        'business_types.view', 'business_types.manage', 'currencies.view', 'currencies.manage',
        'time_zones.view', 'time_zones.manage', 'financial_years.view', 'financial_years.manage',
        'chart_of_accounts.view', 'chart_of_accounts.manage', 'opening_balances.view', 'opening_balances.manage', 'accounting_rules.view', 'accounting_rules.manage',
        'transaction_heads.view', 'transaction_heads.manage', 'transaction_categories.view', 'transaction_categories.manage',
        'voucher_numbering.view', 'voucher_numbering.manage', 'party_types.view', 'party_types.manage',
        'parties.view', 'parties.manage', 'money_account_types.view', 'money_account_types.manage',
        'money_accounts.view', 'money_accounts.manage', 'master_data.view',
    ]);
    $canOpenOtherMasterData = $user?->canAnyAccounting([
        'master_data.view', 'business_types.view', 'business_types.manage',
        'currencies.view', 'currencies.manage', 'time_zones.view', 'time_zones.manage',
        'financial_years.view', 'financial_years.manage', 'party_types.view', 'party_types.manage',
        'money_account_types.view', 'money_account_types.manage', 'transaction_categories.view',
        'transaction_categories.manage', 'voucher_numbering.view', 'voucher_numbering.manage',
    ]);
    $isOtherMasterDataRoute = request()->routeIs(
        'master.overview',
        'master.business-areas.*',
        'master.index',
        'master.voucher-sequences.*',
        'master.business-types.*',
        'master.currencies.*',
        'master.time-zones.*',
        'master.financial-years.*',
    );
    $canAnySystem = $user?->canAnyAccounting(['users.view', 'users.manage', 'role_matrix.view', 'role_matrix.manage', 'settings.manage']);
    $homeDestination = \App\Support\AccountingRbac::firstAllowedDestination($user);
?>

<aside class="hg-side" id="hgAccountingSidebar" aria-label="Main navigation">
    <div class="hg-side-header">
    <a class="hg-brand" href="<?php echo e(route($homeDestination['route'], $homeDestination['parameters'])); ?>">
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($brand['logo_url']): ?>
            <span class="hg-logo hg-logo-image"><img src="<?php echo e($brand['logo_url']); ?>" alt="<?php echo e($brand['name']); ?> logo"></span>
        <?php else: ?>
            <span class="hg-logo">HG</span>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        <span class="hg-brand-copy"><h2><?php echo e($brand['name']); ?></h2><p>Simple Accounting MVP</p></span>
    </a>
    <button type="button" class="hg-sidebar-close" data-hg-sidebar-close aria-label="Close navigation menu">×</button>
    </div>

    <nav class="hg-nav" aria-label="Accounting navigation">
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($user?->canAccounting('dashboard.view')): ?>
        <a href="<?php echo e(route('dashboard')); ?>" class="<?php echo e(request()->routeIs('dashboard') ? 'active' : ''); ?>"><span class="hg-nav-icon">🏠</span><span class="hg-nav-text">Dashboard</span></a>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($user?->canAnyAccounting(['transactions.view','transactions.manage','journals.view'])): ?>
        <div class="hg-nav-section">Transactions</div>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($user?->canAccounting('transactions.manage')): ?>
        <a href="<?php echo e(route('transactions.create')); ?>" class="<?php echo e(request()->routeIs('transactions.create', 'transactions.edit') ? 'active' : ''); ?>"><span class="hg-nav-icon">🧾</span><span class="hg-nav-text">Transaction Entry</span></a>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($user?->canAccounting('transactions.view')): ?>
        <a href="<?php echo e(route('transactions.index')); ?>" class="<?php echo e(request()->routeIs('transactions.index') ? 'active' : ''); ?>"><span class="hg-nav-icon">📚</span><span class="hg-nav-text">Transaction Register</span></a>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($user?->canAccounting('journals.view')): ?>
        <a href="<?php echo e(route('journal-entries.index')); ?>" class="<?php echo e(request()->routeIs('journal-entries.*') ? 'active' : ''); ?>"><span class="hg-nav-icon">📒</span><span class="hg-nav-text">Journal Entries</span></a>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($user?->canAnyAccounting(['transactions.view','transactions.manage'])): ?>
        <div class="hg-nav-section">Feed Business</div>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($user?->canAccounting('transactions.manage')): ?>

        <a href="<?php echo e(route('feed.purchases.create')); ?>" class="<?php echo e(request()->routeIs('feed.purchases.*') ? 'active' : ''); ?>"><span class="hg-nav-icon">🛒</span><span class="hg-nav-text">Feed Purchase</span></a>
        <a href="<?php echo e(route('feed.sales.create')); ?>" class="<?php echo e(request()->routeIs('feed.sales.*') ? 'active' : ''); ?>"><span class="hg-nav-icon">🧾</span><span class="hg-nav-text">Feed Sale</span></a>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($user?->canAccounting('transactions.view')): ?>
        <a href="<?php echo e(route('feed.inventory.index')); ?>" class="<?php echo e(request()->routeIs('feed.inventory.*') ? 'active' : ''); ?>"><span class="hg-nav-icon">▦</span><span class="hg-nav-text">Feed Inventory</span></a>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($user?->canAccounting('transactions.manage')): ?>
        <a href="<?php echo e(route('feed.setup.index')); ?>" class="<?php echo e(request()->routeIs('feed.setup.*') ? 'active' : ''); ?>"><span class="hg-nav-icon">⚙️</span><span class="hg-nav-text">Feed Setup</span></a>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($user?->canAnyAccounting(['balances.view','statements.view'])): ?>
        <div class="hg-nav-section">Reports</div>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($user?->canAccounting('statements.view')): ?>
        <a href="<?php echo e(route('reports.income-statement')); ?>" class="<?php echo e(request()->routeIs('reports.income-statement') ? 'active' : ''); ?>"><span class="hg-nav-icon">📈</span><span class="hg-nav-text">Income Statement</span></a>
        <a href="<?php echo e(route('reports.balance-sheet')); ?>" class="<?php echo e(request()->routeIs('reports.balance-sheet') ? 'active' : ''); ?>"><span class="hg-nav-icon">⚖️</span><span class="hg-nav-text">Balance Sheet</span></a>
        <a href="<?php echo e(route('reports.trial-balance')); ?>" class="<?php echo e(request()->routeIs('reports.trial-balance') ? 'active' : ''); ?>"><span class="hg-nav-icon">🧮</span><span class="hg-nav-text">Trial Balance</span></a>
        <a href="<?php echo e(route('basic-statements.index', ['section' => 'cash-flow'])); ?>#cash-flow-statement" class="<?php echo e(request()->routeIs('basic-statements.*') && $statementSection === 'cash-flow' ? 'active' : ''); ?>"><span class="hg-nav-icon">💸</span><span class="hg-nav-text">Cash Flow Statement</span></a>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($user?->canAccounting('balances.view')): ?>
        <a href="<?php echo e(route('reports.ledger-report')); ?>" class="<?php echo e(request()->routeIs('reports.ledger-report') ? 'active' : ''); ?>"><span class="hg-nav-icon">📖</span><span class="hg-nav-text">Ledger Report</span></a>
        <a href="<?php echo e(route('reports.due-report')); ?>" class="<?php echo e(request()->routeIs('reports.due-report') ? 'active' : ''); ?>"><span class="hg-nav-icon">📌</span><span class="hg-nav-text">Due Report</span></a>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($user?->canAccounting('transactions.manage')): ?>
        <a href="<?php echo e(route('reports.due-management')); ?>" class="<?php echo e(request()->routeIs('reports.due-management*') ? 'active' : ''); ?>"><span class="hg-nav-icon">✅</span><span class="hg-nav-text">Due Management</span></a>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        <a href="<?php echo e(route('balances.index', ['section' => 'accounts'])); ?>#account-balances" class="<?php echo e(! $isReportRoute && $balanceSection === 'accounts' ? 'active' : ''); ?>"><span class="hg-nav-icon">💰</span><span class="hg-nav-text">Account Balances</span></a>
        <a href="<?php echo e(route('balances.index', ['section' => 'parties'])); ?>#party-balances" class="<?php echo e(! $isReportRoute && $balanceSection === 'parties' ? 'active' : ''); ?>"><span class="hg-nav-icon">👥</span><span class="hg-nav-text">Party Balances</span></a>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($canAnyConfiguration): ?>
        <div class="hg-nav-section">Configuration</div>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($user?->canAnyAccounting(['company_setup.view','company_setup.manage'])): ?><a href="<?php echo e(route('company-setup.edit')); ?>" class="<?php echo e(request()->routeIs('company-setup.*') ? 'active' : ''); ?>"><span class="hg-nav-icon">🏢</span><span class="hg-nav-text">Company Setup</span></a><?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($user?->canAccounting('transactions.manage')): ?><a href="<?php echo e(route('feed.business-tracking.index')); ?>" class="<?php echo e(request()->routeIs('feed.business-tracking.*') ? 'active' : ''); ?>"><span class="hg-nav-icon">◫</span><span class="hg-nav-text">Business Tracking</span></a><?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($user?->canAnyAccounting(['chart_of_accounts.view','chart_of_accounts.manage'])): ?><a href="<?php echo e(route('chart-of-accounts.index', $user?->canAccounting('chart_of_accounts.view') ? [] : ['action' => 'add'])); ?>" class="<?php echo e(request()->routeIs('chart-of-accounts.*') ? 'active' : ''); ?>"><span class="hg-nav-icon">📘</span><span class="hg-nav-text">Chart of Accounts</span></a><?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($user?->canAnyAccounting(['opening_balances.view','opening_balances.manage'])): ?><a href="<?php echo e(route('opening-balances.index', $user?->canAccounting('opening_balances.view') ? [] : ['action' => 'add'])); ?>" class="<?php echo e(request()->routeIs('opening-balances.*') ? 'active' : ''); ?>"><span class="hg-nav-icon">📥</span><span class="hg-nav-text">Opening Balances</span></a><?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($user?->canAnyAccounting(['accounting_rules.view','accounting_rules.manage'])): ?><a href="<?php echo e(route('accounting-rules.index', $user?->canAccounting('accounting_rules.view') ? [] : ['action' => 'add'])); ?>" class="<?php echo e(request()->routeIs('accounting-rules.*') ? 'active' : ''); ?>"><span class="hg-nav-icon">⚙️</span><span class="hg-nav-text">Accounting Rules</span></a><?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($user?->canAnyAccounting(['transaction_heads.view','transaction_heads.manage'])): ?><a href="<?php echo e(route('transaction-heads.index', $user?->canAccounting('transaction_heads.view') ? [] : ['action' => 'add'])); ?>" class="<?php echo e(request()->routeIs('transaction-heads.*') ? 'active' : ''); ?>"><span class="hg-nav-icon">🏷️</span><span class="hg-nav-text">Transaction Heads</span></a><?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($user?->canAnyAccounting(['parties.view','parties.manage'])): ?><a href="<?php echo e(route('parties.index', $user?->canAccounting('parties.view') ? [] : ['action' => 'add'])); ?>" class="<?php echo e(request()->routeIs('parties.*') ? 'active' : ''); ?>"><span class="hg-nav-icon">👤</span><span class="hg-nav-text">Parties</span></a><?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($user?->canAnyAccounting(['money_accounts.view','money_accounts.manage'])): ?><a href="<?php echo e(route('money-accounts.index', $user?->canAccounting('money_accounts.view') ? [] : ['action' => 'add'])); ?>" class="<?php echo e(request()->routeIs('money-accounts.*') ? 'active' : ''); ?>"><span class="hg-nav-icon">🏦</span><span class="hg-nav-text">Money Accounts</span></a><?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($canOpenOtherMasterData): ?>
        <details class="hg-nav-group" data-hg-nav-group="other-master-data" <?php if($isOtherMasterDataRoute): ?> open <?php endif; ?>>
            <summary class="<?php echo e($isOtherMasterDataRoute ? 'active' : ''); ?>" aria-expanded="<?php echo e($isOtherMasterDataRoute ? 'true' : 'false'); ?>">
                <span class="hg-nav-icon">📁</span>
                <span class="hg-nav-text">Other Master Data</span>
                <span class="hg-nav-caret">›</span>
            </summary>
            <div class="hg-nav-submenu">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($user?->canAccounting('master_data.view')): ?>
                <a href="<?php echo e(route('master.overview')); ?>" class="<?php echo e(request()->routeIs('master.overview') ? 'active' : ''); ?>"><span class="hg-nav-icon">▦</span><span class="hg-nav-text">Overview</span></a>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($user?->canAnyAccounting(['business_types.view','business_types.manage', 'currencies.view','currencies.manage', 'time_zones.view','time_zones.manage', 'financial_years.view','financial_years.manage'])): ?>
                <div class="hg-nav-subheading">Company Setup</div>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($user?->canAccounting('transactions.manage')): ?><a href="<?php echo e(route('master.business-areas.index')); ?>" class="<?php echo e(request()->routeIs('master.business-areas.*') ? 'active' : ''); ?>"><span class="hg-nav-icon">🏢</span><span class="hg-nav-text">Business Areas</span></a><?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($user?->canAnyAccounting(['business_types.view','business_types.manage'])): ?><a href="<?php echo e(route('master.business-types.index', $user?->canAccounting('business_types.view') ? [] : ['action' => 'add'])); ?>" class="<?php echo e(request()->routeIs('master.business-types.*') ? 'active' : ''); ?>"><span class="hg-nav-icon">🏢</span><span class="hg-nav-text">Business Types</span></a><?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($user?->canAnyAccounting(['currencies.view','currencies.manage'])): ?><a href="<?php echo e(route('master.currencies.index', $user?->canAccounting('currencies.view') ? [] : ['action' => 'add'])); ?>" class="<?php echo e(request()->routeIs('master.currencies.*') ? 'active' : ''); ?>"><span class="hg-nav-icon">৳</span><span class="hg-nav-text">Currencies</span></a><?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($user?->canAnyAccounting(['time_zones.view','time_zones.manage'])): ?><a href="<?php echo e(route('master.time-zones.index', $user?->canAccounting('time_zones.view') ? [] : ['action' => 'add'])); ?>" class="<?php echo e(request()->routeIs('master.time-zones.*') ? 'active' : ''); ?>"><span class="hg-nav-icon">◷</span><span class="hg-nav-text">Time Zones</span></a><?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($user?->canAnyAccounting(['financial_years.view','financial_years.manage'])): ?><a href="<?php echo e(route('master.financial-years.index', $user?->canAccounting('financial_years.view') ? [] : ['action' => 'add'])); ?>" class="<?php echo e(request()->routeIs('master.financial-years.*') ? 'active' : ''); ?>"><span class="hg-nav-icon">📅</span><span class="hg-nav-text">Financial Years</span></a><?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($user?->canAnyAccounting(['party_types.view','party_types.manage', 'money_account_types.view','money_account_types.manage', 'transaction_categories.view','transaction_categories.manage', 'voucher_numbering.view','voucher_numbering.manage'])): ?>
                <div class="hg-nav-subheading">Accounting Masters</div>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($user?->canAnyAccounting(['party_types.view','party_types.manage'])): ?><a href="<?php echo e(route('master.index', ['section' => 'party-types'] + ($user?->canAccounting('party_types.view') ? [] : ['action' => 'add']))); ?>" class="<?php echo e(request()->routeIs('master.index') && request()->route('section') === 'party-types' ? 'active' : ''); ?>"><span class="hg-nav-icon">🧩</span><span class="hg-nav-text">Party Types</span></a><?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($user?->canAnyAccounting(['money_account_types.view','money_account_types.manage'])): ?><a href="<?php echo e(route('master.index', ['section' => 'money-account-types'] + ($user?->canAccounting('money_account_types.view') ? [] : ['action' => 'add']))); ?>" class="<?php echo e(request()->routeIs('master.index') && request()->route('section') === 'money-account-types' ? 'active' : ''); ?>"><span class="hg-nav-icon">💳</span><span class="hg-nav-text">Money Account Types</span></a><?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($user?->canAnyAccounting(['transaction_categories.view','transaction_categories.manage'])): ?><a href="<?php echo e(route('master.index', ['section' => 'transaction-categories'] + ($user?->canAccounting('transaction_categories.view') ? [] : ['action' => 'add']))); ?>" class="<?php echo e(request()->routeIs('master.index') && request()->route('section') === 'transaction-categories' ? 'active' : ''); ?>"><span class="hg-nav-icon">🗂️</span><span class="hg-nav-text">Transaction Types</span></a><?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($user?->canAnyAccounting(['voucher_numbering.view','voucher_numbering.manage'])): ?><a href="<?php echo e(route('master.voucher-sequences.index', $user?->canAccounting('voucher_numbering.view') ? [] : ['action' => 'add'])); ?>" class="<?php echo e(request()->routeIs('master.voucher-sequences.*') ? 'active' : ''); ?>"><span class="hg-nav-icon">🔢</span><span class="hg-nav-text">Voucher Numbering</span></a><?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </div>
        </details>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($canAnySystem): ?>
        <div class="hg-nav-section">System</div>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($user?->canAnyAccounting(['users.view','users.manage'])): ?><a href="<?php echo e(route('system.users.index', $user?->canAccounting('users.view') ? [] : ['action' => 'add'])); ?>" class="<?php echo e(request()->routeIs('system.users.*') ? 'active' : ''); ?>"><span class="hg-nav-icon">👥</span><span class="hg-nav-text">Users</span></a><?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($user?->canAnyAccounting(['role_matrix.view','role_matrix.manage'])): ?><a href="<?php echo e(route('system.role-matrix.index', $user?->canAccounting('role_matrix.view') ? [] : ['action' => 'add'])); ?>" class="<?php echo e(request()->routeIs('system.role-matrix.*') ? 'active' : ''); ?>"><span class="hg-nav-icon">🛡️</span><span class="hg-nav-text">Role Matrix</span></a><?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($user?->canAccounting('settings.manage')): ?><a href="<?php echo e(route('system.settings.index')); ?>" class="<?php echo e(request()->routeIs('system.settings.*') ? 'active' : ''); ?>"><span class="hg-nav-icon">🎨</span><span class="hg-nav-text">Branding Settings</span></a><?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    </nav>
</aside>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel/hisebghor/resources/views/partials/accounting/sidebar.blade.php ENDPATH**/ ?>