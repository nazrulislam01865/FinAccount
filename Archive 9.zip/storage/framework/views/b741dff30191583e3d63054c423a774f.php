<?php
    $accountUser = auth()->user();
    $profilePhotoPath = trim((string) ($accountUser?->profile_photo_path ?? ''));
    $profilePhotoUrl = $profilePhotoPath !== ''
        ? route('accounting.profile.photo', ['v' => optional($accountUser?->updated_at)->timestamp])
        : null;
?>

<details class="hg-user-menu" id="hgUserMenu">
    <summary class="hg-user-menu-trigger" aria-label="Open account menu">
        <span class="hg-account-avatar" aria-hidden="true">
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($profilePhotoUrl): ?>
                <img src="<?php echo e($profilePhotoUrl); ?>" alt="<?php echo e($accountUser?->name); ?> profile picture">
            <?php else: ?>
                <?php echo e($accountUser?->initials() ?: 'U'); ?>

            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </span>
        <span class="hg-user-menu-copy">
            <strong><?php echo e($accountUser?->name ?? 'User'); ?></strong>
            <small><?php echo e($accountUser?->roleLabel() ?? 'My Account'); ?></small>
        </span>
        <span class="hg-user-menu-arrow" aria-hidden="true">▾</span>
    </summary>

    <div class="hg-user-menu-panel">
        <div class="hg-user-menu-head">
            <span class="hg-account-avatar large" aria-hidden="true">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($profilePhotoUrl): ?>
                    <img src="<?php echo e($profilePhotoUrl); ?>" alt="<?php echo e($accountUser?->name); ?> profile picture">
                <?php else: ?>
                    <?php echo e($accountUser?->initials() ?: 'U'); ?>

                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </span>
            <div>
                <strong><?php echo e($accountUser?->name ?? 'User'); ?></strong>
                <small><?php echo e($accountUser?->email ?? ''); ?></small>
            </div>
        </div>

        <a href="<?php echo e(route('accounting.profile')); ?>" class="hg-user-menu-link">
            <span aria-hidden="true">👤</span>
            <span>My Profile</span>
        </a>
        <a href="<?php echo e(route('accounting.profile')); ?>#change-password" class="hg-user-menu-link">
            <span aria-hidden="true">🔐</span>
            <span>Change Password</span>
        </a>

        <form method="POST" action="<?php echo e(route('logout')); ?>" class="hg-user-menu-logout">
            <?php echo csrf_field(); ?>
            <button type="submit">
                <span aria-hidden="true">↪</span>
                <span>Logout</span>
            </button>
        </form>
    </div>
</details>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel/hisebghor/resources/views/components/accounting/user-menu.blade.php ENDPATH**/ ?>