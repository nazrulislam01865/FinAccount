const config = window.HISEBGHOR_BUSINESS_TRACKING;

if (config) {
    const unitForm = document.getElementById('businessTrackingUnitForm');
    const businessSelect = document.getElementById('trackingBusiness');
    const unitTypeField = document.getElementById('trackingUnitType');
    const unitLocation = document.getElementById('trackingUnitLocation');
    const unitNameField = document.getElementById('trackingUnitName');

    const responsiblePerson = document.getElementById('trackingResponsiblePerson');
    const startDate = document.getElementById('trackingStartDate');
    const statusSelect = document.getElementById('trackingStatus');
    const description = document.getElementById('trackingDescription');
    const methodField = unitForm?.querySelector('[data-form-method]');
    const itemsContainer = document.getElementById('trackingUnitItemsContainer');
    const addItemBtn = document.getElementById('addTrackingUnitItemBtn');
    const submitLabel = unitForm?.querySelector('[data-unit-submit-label]');

    const defaultBusinessArea = config.defaultBusinessArea || Object.keys(config.config || {})[0] || '';

    const getBusiness = (key) => config.config[key] || config.config[defaultBusinessArea] || { unitLabel: 'Unit', unitTypes: ['Unit'], parents: [] };

    const fillOptions = (select, options, selected = '') => {
        if (!select) return;
        select.innerHTML = options.map((option) => {
            const value = String(option.value ?? option.id ?? '');
            const label = option.label ?? option.name ?? value;
            const isSelected = String(selected ?? '') === value;

            return `<option value="${escapeHtml(value)}" ${isSelected ? 'selected' : ''}>${escapeHtml(label)}</option>`;
        }).join('');
    };

    const updateGeneratedUnitFields = (selectedType = '', selectedName = '') => {
        if (!businessSelect) return;

        const businessKey = businessSelect.value || defaultBusinessArea;
        const business = getBusiness(businessKey);
        const unitTypes = business.unitTypes || [];
        const defaultType = unitTypes[0] || business.unitLabel || 'Unit';

        if (unitTypeField) {
            unitTypeField.value = selectedType || unitTypeField.dataset.oldValue || defaultType;
        }

        if (unitNameField) {
            unitNameField.value = '';
        }
    };

    const createItemRow = (value = '') => {
        const input = document.createElement('input');
        input.type = 'text';
        input.className = 'feed-control';
        input.name = 'items[]';
        input.placeholder = 'Enter item name';
        input.style.marginBottom = '8px';
        input.value = value;
        return input;
    };

    document.body.addEventListener('click', (e) => {
        if (e.target && e.target.id === 'addTrackingUnitItemBtn') {
            const container = document.getElementById('trackingUnitItemsContainer');
            if (container) {
                container.appendChild(createItemRow());
            }
        }
    });

    const resetUnitForm = () => {
        if (!unitForm) return;

        unitForm.action = config.storeUrl;
        methodField.value = 'POST';
        businessSelect.value = defaultBusinessArea;
        updateGeneratedUnitFields('');
        if (unitLocation) unitLocation.value = '';
        if (unitNameField) unitNameField.value = '';
        responsiblePerson.value = '';
        startDate.value = new Date().toISOString().slice(0, 10);
        statusSelect.value = '1';
        description.value = '';
        if (itemsContainer) {
            itemsContainer.innerHTML = '';
            itemsContainer.appendChild(createItemRow());
        }
        submitLabel.textContent = 'Save Tracking Unit';
    };

    const applyUnitEdit = (button) => {
        if (!unitForm || !button) return;

        unitForm.action = button.dataset.updateUrl;
        methodField.value = 'PUT';
        businessSelect.value = button.dataset.businessArea || defaultBusinessArea;
        updateGeneratedUnitFields(button.dataset.unitType || '');
        if (unitLocation) unitLocation.value = button.dataset.location || '';
        if (unitNameField) unitNameField.value = '';
        responsiblePerson.value = button.dataset.responsiblePerson || '';
        startDate.value = button.dataset.startDate || '';
        statusSelect.value = button.dataset.isActive === '0' ? '0' : '1';
        description.value = button.dataset.description || '';
        
        if (itemsContainer) {
            itemsContainer.innerHTML = '';
            let items = [];
            try {
                items = JSON.parse(button.dataset.items || '[]');
            } catch (e) {}
            if (!items.length) {
                itemsContainer.appendChild(createItemRow());
            } else {
                items.forEach(item => itemsContainer.appendChild(createItemRow(item)));
            }
        }
        
        submitLabel.textContent = 'Update Tracking Unit';
        unitLocation?.focus();
    };

    businessSelect?.addEventListener('change', () => updateGeneratedUnitFields(''));
    document.querySelectorAll('[data-clear-unit-form]').forEach((button) => button.addEventListener('click', resetUnitForm));
    document.querySelectorAll('[data-edit-unit]').forEach((button) => button.addEventListener('click', () => applyUnitEdit(button)));
    document.querySelectorAll('[data-tracking-focus]').forEach((button) => button.addEventListener('click', () => unitLocation?.focus()));
    document.querySelectorAll('[data-prepare-tracking-unit]').forEach((button) => {
        button.addEventListener('click', () => {
            resetUnitForm();
            businessSelect.value = button.dataset.prepareTrackingUnit || defaultBusinessArea;
            updateGeneratedUnitFields('');
            unitLocation?.focus();
        });
    });

    if (businessSelect && config.oldBusinessArea) {
        businessSelect.value = config.oldBusinessArea;
    }
    updateGeneratedUnitFields(config.oldUnitType || '');

    const assignmentForm = document.querySelector('[data-default-assignment-form]');
    const sourceType = document.getElementById('assignmentSourceType');
    const sourceId = document.getElementById('assignmentSourceId');
    const sourceSelectWrap = document.querySelector('[data-source-select-wrap]');
    const sourceManualWrap = document.querySelector('[data-source-manual-wrap]');
    const assignmentBusiness = document.getElementById('assignmentBusinessArea');
    const assignmentUnit = document.getElementById('assignmentUnit');

    const refreshSourceOptions = () => {
        if (!sourceType || !sourceId) return;

        const activeSourceType = sourceType.value;
        const isManual = activeSourceType === 'manual';
        if (sourceSelectWrap) sourceSelectWrap.hidden = isManual;
        if (sourceManualWrap) sourceManualWrap.hidden = !isManual;
        sourceId.required = !isManual;

        [...sourceId.options].forEach((option) => {
            option.hidden = option.dataset.sourceType !== activeSourceType;
        });

        const firstVisible = [...sourceId.options].find((option) => !option.hidden);
        sourceId.value = firstVisible ? firstVisible.value : '';
    };

    const refreshAssignmentUnits = () => {
        if (!assignmentBusiness || !assignmentUnit) return;

        const business = getBusiness(assignmentBusiness.value || defaultBusinessArea);
        const options = [{ value: '', label: 'Ask during entry' }].concat((business.parents || []).map((parent) => ({ value: parent.id, label: parent.name })));
        fillOptions(assignmentUnit, options, assignmentUnit.value || '');
    };

    document.querySelectorAll('[data-toggle-default-assignment]').forEach((button) => {
        button.addEventListener('click', () => {
            if (!assignmentForm) return;
            assignmentForm.hidden = !assignmentForm.hidden;
            if (!assignmentForm.hidden) {
                refreshSourceOptions();
                refreshAssignmentUnits();
                assignmentForm.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
            }
        });
    });

    sourceType?.addEventListener('change', refreshSourceOptions);
    assignmentBusiness?.addEventListener('change', refreshAssignmentUnits);
    if (assignmentBusiness && config.oldAssignmentBusinessArea) {
        assignmentBusiness.value = config.oldAssignmentBusinessArea;
    }
    refreshSourceOptions();
    refreshAssignmentUnits();
}

function escapeHtml(value) {
    return String(value ?? '')
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#039;');
}
