<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        $this->call([
            MasterDataSeeder::class,
            RolePermissionSeeder::class,
            AdminUserSeeder::class,
            LandingAdminUserSeeder::class,
            ChartOfAccountSeeder::class,
            SettlementTypeSeeder::class,
            TransactionHeadSeeder::class,
            CashBankAccountSeeder::class,
            LedgerMappingRuleSeeder::class,
            AdvanceAccountingRuleSeeder::class,
            VoucherNumberingRuleSeeder::class,
            AccountingRegisterBackfillSeeder::class,
        ]);
    }
}
