@extends('layouts.app')

@section('title', 'Supplier Payable')

@push('styles')
    @include('accounting_reports.partials.financial-report-styles')
@endpush

@section('content')
@php
    $money = fn ($amount) => ($currency ?? 'BDT') . ' ' . number_format((float) $amount, 2);
    $moneyOrDash = fn ($amount) => abs((float) $amount) >= 0.01 ? $money($amount) : '—';
    $formatDate = function ($date) { try { return \Illuminate\Support\Carbon::parse($date)->format('d M Y'); } catch (\Throwable) { return (string) $date; } };
@endphp

<div class="financial-report-page">
    <x-report.page-header title="Supplier Payable" subtitle="Supplier-wise payable opening, movement, and closing balance from party-control journal lines.">
        <x-slot:actions>
            <a class="button btn-outline" href="{{ route('accounting-reports.supplier-payables.export', array_merge(request()->query(), ['format' => 'xlsx'])) }}">⇩ Export XLSX</a>
            <a class="button btn-outline" href="{{ route('accounting-reports.supplier-payables.export', array_merge(request()->query(), ['format' => 'pdf'])) }}">⇩ Export PDF</a>
            <button class="btn-ghost" type="button" onclick="window.print()">Print</button>
            <a class="button btn-primary" href="{{ route('accounting-reports.supplier-payables.index', request()->query()) }}">↻ Refresh</a>
        </x-slot:actions>
    </x-report.page-header>

    <div class="report-summary-grid report-summary-grid-six">
        <x-report.stat-card label="Opening Payable" :value="$money($report['total_opening'])" tone="primary" />
        <x-report.stat-card label="Debit Movement" :value="$money($report['total_debit_movement'])" tone="warning" />
        <x-report.stat-card label="Credit Movement" :value="$money($report['total_credit_movement'])" tone="primary" />
        <x-report.stat-card label="Closing Payable" :value="$money($report['total_closing'])" :tone="$report['total_closing'] >= 0 ? 'success' : 'danger'" />
        <x-report.stat-card label="Supplier Count" :value="$report['rows']->pluck('party_id')->unique()->count()" tone="muted" />
        <x-report.stat-card label="Ledger Lines" :value="$report['rows']->count()" tone="muted" />
    </div>

    <form method="GET" action="{{ route('accounting-reports.supplier-payables.index') }}" class="card report-toolbar report-toolbar-seven accounting-filter-sequence">
        <div class="date-range-field"><label>Date Range</label><div class="date-range-inputs"><input type="date" name="from_date" value="{{ $filters['from_date'] ?? $report['from_date'] }}"><input type="date" name="to_date" value="{{ $filters['to_date'] ?? $report['to_date'] }}"></div></div>
        <div><label>Supplier</label><select name="party_id"><option value="">All Suppliers</option>@foreach($report['parties'] as $party)<option value="{{ $party->id }}" @selected((string)($filters['party_id'] ?? '') === (string)$party->id)>{{ $party->party_code }} - {{ $party->party_name }}</option>@endforeach</select></div>
        <div class="field search-field"><label>Search</label><span>⌕</span><input type="text" name="q" value="{{ $filters['q'] ?? '' }}" placeholder="Supplier or ledger..."></div>
        <label class="checkbox-inline"><input type="checkbox" name="include_zero_balances" value="1" @checked($filters['include_zero_balances'] ?? false)> Include zero balances</label>
        <x-report.filter-actions :reset-route="route('accounting-reports.supplier-payables.index')" />
    </form>

    <x-report.table-card title="Payable Ledger" :subtitle="$formatDate($report['from_date']) . ' to ' . $formatDate($report['to_date'])" footer-left="Supplier payable comes from party-control credit minus debit movements." footer-right="Header amount is not used.">
        <div class="table-wrap"><table class="financial-table"><thead><tr><th>Supplier Code</th><th>Supplier</th><th>Ledger</th><th class="amount">Opening</th><th class="amount">Payment/Debit</th><th class="amount">Purchase/Credit</th><th class="amount">Closing</th><th class="amount">0-30</th><th class="amount">31-60</th><th class="amount">61-90</th><th class="amount">90+</th></tr></thead><tbody>
            @forelse($report['rows'] as $row)
                <tr><td class="code">{{ $row->party_code }}</td><td class="strong">{{ $row->party_name }}</td><td>{{ trim(($row->account_code ? $row->account_code . ' - ' : '') . $row->account_name) }}</td><td class="amount">{{ $moneyOrDash($row->opening_balance) }}</td><td class="amount">{{ $moneyOrDash($row->debit_movement) }}</td><td class="amount">{{ $moneyOrDash($row->credit_movement) }}</td><td class="amount">{{ $money($row->closing_balance) }}</td><td class="amount">{{ $moneyOrDash($row->aging_0_30 ?? 0) }}</td><td class="amount">{{ $moneyOrDash($row->aging_31_60 ?? 0) }}</td><td class="amount">{{ $moneyOrDash($row->aging_61_90 ?? 0) }}</td><td class="amount">{{ $moneyOrDash($row->aging_90_plus ?? 0) }}</td></tr>
            @empty
                <tr data-empty="true"><td colspan="11" class="empty-state">No supplier payable balance found.</td></tr>
            @endforelse
            <tr class="grand-row"><td colspan="3">Grand Total</td><td class="amount">{{ $money($report['total_opening']) }}</td><td class="amount">{{ $money($report['total_debit_movement']) }}</td><td class="amount">{{ $money($report['total_credit_movement']) }}</td><td class="amount">{{ $money($report['total_closing']) }}</td><td class="amount">{{ $money($report['aging_totals']['0_30'] ?? 0) }}</td><td class="amount">{{ $money($report['aging_totals']['31_60'] ?? 0) }}</td><td class="amount">{{ $money($report['aging_totals']['61_90'] ?? 0) }}</td><td class="amount">{{ $money($report['aging_totals']['90_plus'] ?? 0) }}</td></tr>
        </tbody></table></div>
    </x-report.table-card>
</div>
@endsection
