<form method="GET" action="<?php echo e($action); ?>" class="hg-report-toolbar">
    <?php echo e($slot); ?>

    <div class="hg-report-toolbar-actions">
        <button type="submit" class="hg-btn hg-btn-primary">Generate</button>
        <a class="hg-btn" href="<?php echo e($action); ?>">Reset</a>
        <a class="hg-btn" href="<?php echo e($exportUrl); ?>">Export CSV</a>
        <button type="button" class="hg-btn" onclick="window.print()">Print</button>
    </div>
</form>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel/hisebghor/resources/views/components/reports/partials/filter-toolbar.blade.php ENDPATH**/ ?>