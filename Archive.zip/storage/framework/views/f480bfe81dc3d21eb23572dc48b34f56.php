<?php if (isset($component)) { $__componentOriginal9bfc79a588c44096104b78e73dee62a6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9bfc79a588c44096104b78e73dee62a6 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'f4ac99e09542ff494432bc959d4fee61::accounting','data' => ['title' => 'Trial Balance']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layouts::accounting'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Trial Balance']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

    <div class="hg-report-page">
        <div class="hg-page-header hg-report-page-header">
            <div>
                <h1>Trial Balance</h1>
                <p>Checks debit and credit balances from opening values and posted journal lines for the selected period.</p>
            </div>
        </div>

        <?php if (isset($component)) { $__componentOriginal74cc1c13d0f4b30c215f90a3e80a6e0f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal74cc1c13d0f4b30c215f90a3e80a6e0f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.reports.partials.filter-toolbar','data' => ['action' => route('reports.trial-balance'),'exportUrl' => route('reports.trial-balance', request()->query() + ['export' => 'csv'])]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('reports.partials.filter-toolbar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['action' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('reports.trial-balance')),'export-url' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('reports.trial-balance', request()->query() + ['export' => 'csv']))]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

            <label>
                <span>From date</span>
                <input type="date" name="from_date" value="<?php echo e($report['from_date']); ?>">
            </label>
            <label>
                <span>To date</span>
                <input type="date" name="to_date" value="<?php echo e($report['to_date']); ?>">
            </label>
            <label>
                <span>Account type</span>
                <select name="account_type">
                    <option value="all" <?php if($report['account_type'] === 'all'): echo 'selected'; endif; ?>>All types</option>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $report['account_types']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                        <option value="<?php echo e($type); ?>" <?php if($report['account_type'] === $type): echo 'selected'; endif; ?>><?php echo e($type); ?></option>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                </select>
            </label>
            <label>
                <span>Balance type</span>
                <select name="balance_type">
                    <option value="all" <?php if($report['balance_type'] === 'all'): echo 'selected'; endif; ?>>All balances</option>
                    <option value="debit" <?php if($report['balance_type'] === 'debit'): echo 'selected'; endif; ?>>Debit only</option>
                    <option value="credit" <?php if($report['balance_type'] === 'credit'): echo 'selected'; endif; ?>>Credit only</option>
                    <option value="zero" <?php if($report['balance_type'] === 'zero'): echo 'selected'; endif; ?>>Zero only</option>
                </select>
            </label>
            <label>
                <span>Search account</span>
                <input type="search" name="search" value="<?php echo e(request('search')); ?>" placeholder="Code or account name">
            </label>
            <label class="hg-report-check">
                <input type="checkbox" name="include_zero_balances" value="1" <?php if($report['include_zero_balances']): echo 'checked'; endif; ?>>
                <span>Show zero balances</span>
            </label>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal74cc1c13d0f4b30c215f90a3e80a6e0f)): ?>
<?php $attributes = $__attributesOriginal74cc1c13d0f4b30c215f90a3e80a6e0f; ?>
<?php unset($__attributesOriginal74cc1c13d0f4b30c215f90a3e80a6e0f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal74cc1c13d0f4b30c215f90a3e80a6e0f)): ?>
<?php $component = $__componentOriginal74cc1c13d0f4b30c215f90a3e80a6e0f; ?>
<?php unset($__componentOriginal74cc1c13d0f4b30c215f90a3e80a6e0f); ?>
<?php endif; ?>

        <div class="hg-grid hg-grid-3 hg-report-summary">
            <section class="hg-card hg-metric"><span class="label">Closing Debit</span><div class="value"><?php echo e(\App\Support\CompanyContext::money($report['total_closing_debit'])); ?></div></section>
            <section class="hg-card hg-metric"><span class="label">Closing Credit</span><div class="value"><?php echo e(\App\Support\CompanyContext::money($report['total_closing_credit'])); ?></div></section>
            <section class="hg-card hg-metric"><span class="label">Difference</span><div class="value"><?php echo e(\App\Support\CompanyContext::money($report['difference'])); ?></div><small><?php echo e($report['is_balanced'] ? 'Balanced' : 'Needs review'); ?></small></section>
        </div>

        <section class="hg-card">
            <h2 class="hg-card-title">Trial Balance Details</h2>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($report['rows']->isEmpty()): ?>
                <div class="hg-empty">No records found.</div>
            <?php else: ?>
                <div class="hg-table-wrap">
                    <table class="hg-table hg-report-table hg-trial-balance-table">
                        <thead>
                            <tr>
                                <th>Account</th>
                                <th>Type</th>
                                <th class="right">Opening Dr</th>
                                <th class="right">Opening Cr</th>
                                <th class="right">Period Dr</th>
                                <th class="right">Period Cr</th>
                                <th class="right">Closing Dr</th>
                                <th class="right">Closing Cr</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $report['rows']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                                <tr>
                                    <td>
                                        <strong><?php echo e($row['code']); ?></strong> — <?php echo e($row['name']); ?>

                                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(! $row['is_active']): ?><br><span class="hg-muted">Inactive</span><?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                    </td>
                                    <td><span class="hg-badge <?php echo e(strtolower($row['type'])); ?>"><?php echo e($row['type']); ?></span></td>
                                    <td class="right"><?php echo e(\App\Support\CompanyContext::money($row['opening_debit'])); ?></td>
                                    <td class="right"><?php echo e(\App\Support\CompanyContext::money($row['opening_credit'])); ?></td>
                                    <td class="right"><?php echo e(\App\Support\CompanyContext::money($row['period_debit'])); ?></td>
                                    <td class="right"><?php echo e(\App\Support\CompanyContext::money($row['period_credit'])); ?></td>
                                    <td class="right"><strong><?php echo e(\App\Support\CompanyContext::money($row['closing_debit'])); ?></strong></td>
                                    <td class="right"><strong><?php echo e(\App\Support\CompanyContext::money($row['closing_credit'])); ?></strong></td>
                                </tr>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                        </tbody>
                        <tfoot>
                            <tr>
                                <th colspan="2">Total</th>
                                <th class="right"><?php echo e(\App\Support\CompanyContext::money($report['total_opening_debit'])); ?></th>
                                <th class="right"><?php echo e(\App\Support\CompanyContext::money($report['total_opening_credit'])); ?></th>
                                <th class="right"><?php echo e(\App\Support\CompanyContext::money($report['total_period_debit'])); ?></th>
                                <th class="right"><?php echo e(\App\Support\CompanyContext::money($report['total_period_credit'])); ?></th>
                                <th class="right"><?php echo e(\App\Support\CompanyContext::money($report['total_closing_debit'])); ?></th>
                                <th class="right"><?php echo e(\App\Support\CompanyContext::money($report['total_closing_credit'])); ?></th>
                            </tr>
                        </tfoot>
                    </table>
                </div>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </section>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9bfc79a588c44096104b78e73dee62a6)): ?>
<?php $attributes = $__attributesOriginal9bfc79a588c44096104b78e73dee62a6; ?>
<?php unset($__attributesOriginal9bfc79a588c44096104b78e73dee62a6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9bfc79a588c44096104b78e73dee62a6)): ?>
<?php $component = $__componentOriginal9bfc79a588c44096104b78e73dee62a6; ?>
<?php unset($__componentOriginal9bfc79a588c44096104b78e73dee62a6); ?>
<?php endif; ?>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel/hisebghor/resources/views/reports/trial-balance.blade.php ENDPATH**/ ?>