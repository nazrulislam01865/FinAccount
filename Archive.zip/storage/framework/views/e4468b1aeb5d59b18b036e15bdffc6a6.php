<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'submitLabel' => 'Save',
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'submitLabel' => 'Save',
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<div <?php echo e($attributes->class(['hg-form-actions'])); ?>>
    <div class="hg-actions">
        <?php echo e($slot); ?>

        <button type="button" class="hg-btn hg-btn-draft" data-draft-save>
            <span aria-hidden="true">📝</span>
            Save Draft
        </button>
        <button type="submit" class="hg-btn hg-btn-primary">
            <?php echo e($submitLabel); ?>

        </button>
    </div>
    <div class="hg-draft-feedback" data-draft-feedback role="status" aria-live="polite" hidden>
        <span data-draft-message></span>
        <button type="button" class="hg-draft-discard" data-draft-discard hidden>Discard draft</button>
    </div>
</div>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel/hisebghor/resources/views/components/accounting/form-actions.blade.php ENDPATH**/ ?>