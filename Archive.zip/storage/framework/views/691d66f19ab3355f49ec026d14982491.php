<?php
    $alertRows = $rows->whereIn('status', ['low', 'out'])->values();
    $recentMovementCards = $recentMovements->take(8);
?>

<?php if (isset($component)) { $__componentOriginal9bfc79a588c44096104b78e73dee62a6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9bfc79a588c44096104b78e73dee62a6 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'f4ac99e09542ff494432bc959d4fee61::accounting','data' => ['title' => 'Feed Inventory']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layouts::accounting'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Feed Inventory']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

    <div class="feed-ui">
        <div class="feed-page-heading">
            <div>
                <h1>Feed Inventory</h1>
                <p>Monitor purchased quantity, sold quantity, stock value, reorder needs, and recent movements.</p>
            </div>
            <div class="feed-heading-actions">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(auth()->user()?->canAccounting('transactions.manage')): ?>
                    <a class="feed-btn" href="<?php echo e(route('feed.sales.create')); ?>">New Feed Sale</a>
                    <a class="feed-btn feed-btn-primary" href="<?php echo e(route('feed.purchases.create')); ?>">＋ New Feed Purchase</a>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </div>
        </div>

        <?php echo $__env->make('feed.partials.tabs', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(session('feed_receipt_url')): ?>
            <div class="feed-info-banner feed-info-blue feed-section-gap">
                <strong>Feed purchase receipt is ready.</strong>
                <a class="feed-btn feed-btn-primary" href="<?php echo e(session('feed_receipt_url')); ?>" target="_blank" rel="noopener">Print Receipt</a>
            </div>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

        <div class="feed-metric-grid">
            <div class="feed-metric">
                <div class="feed-metric-icon">▦</div>
                <div class="feed-metric-label">Stocked Feed Items</div>
                <div class="feed-metric-value"><?php echo e($metrics['items']); ?></div>
                <div class="feed-metric-foot">Across <?php echo e($warehouses->count()); ?> active warehouse<?php echo e($warehouses->count() === 1 ? '' : 's'); ?></div>
            </div>
            <div class="feed-metric">
                <div class="feed-metric-icon">৳</div>
                <div class="feed-metric-label">Current Stock Value</div>
                <div class="feed-metric-value"><?php echo e(\App\Support\CompanyContext::money($metrics['stock_value'])); ?></div>
                <div class="feed-metric-foot">Weighted-average valuation</div>
            </div>
            <div class="feed-metric">
                <div class="feed-metric-icon">＋</div>
                <div class="feed-metric-label">Total Purchased</div>
                <div class="feed-metric-value"><?php echo e(number_format($metrics['purchased'], 2)); ?> KG</div>
                <div class="feed-metric-foot">All posted feed purchases</div>
            </div>
            <div class="feed-metric">
                <div class="feed-metric-icon">−</div>
                <div class="feed-metric-label">Total Sold</div>
                <div class="feed-metric-value"><?php echo e(number_format($metrics['sold'], 2)); ?> KG</div>
                <div class="feed-metric-foot"><?php echo e($metrics['low']); ?> low and <?php echo e($metrics['out']); ?> out of stock</div>
            </div>
        </div>

        <section class="feed-card">
            <div class="feed-card-header feed-card-header-responsive">
                <div>
                    <div class="feed-card-title">Stock Position</div>
                    <div class="feed-card-sub">Quantity is shown in kilograms and equivalent bags. Purchased and sold totals come from posted stock movements.</div>
                </div>
                <form method="GET" class="feed-toolbar">
                    <div class="feed-search-box">
                        <span class="feed-search-icon">⌕</span>
                        <input class="feed-control" type="search" name="search" value="<?php echo e($search); ?>" placeholder="Search item, code or brand">
                    </div>
                    <select class="feed-control" name="tracking_unit_id" data-hg-searchable-ignore>
                        <option value="">All warehouses</option>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $warehouses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $warehouse): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                            <option value="<?php echo e($warehouse->id); ?>" <?php if($warehouseId === $warehouse->id): echo 'selected'; endif; ?>><?php echo e($warehouse->name); ?></option>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                    </select>
                    <select class="feed-control" name="status" data-hg-searchable-ignore>
                        <option value="">All stock status</option>
                        <option value="in" <?php if($status === 'in'): echo 'selected'; endif; ?>>In Stock</option>
                        <option value="low" <?php if($status === 'low'): echo 'selected'; endif; ?>>Low Stock</option>
                        <option value="out" <?php if($status === 'out'): echo 'selected'; endif; ?>>Out of Stock</option>
                    </select>
                    <button class="feed-btn feed-btn-primary" type="submit">Apply</button>
                    <a class="feed-btn" href="<?php echo e(route('feed.inventory.index')); ?>">Clear</a>
                </form>
            </div>

            <div class="feed-card-body">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($rows->isEmpty()): ?>
                    <div class="feed-empty-note">No feed stock is available yet. Post a Feed Purchase to create the first stock movement.</div>
                <?php else: ?>
                    <div class="feed-table-wrap">
                        <table class="feed-table feed-inventory-table">
                            <thead>
                                <tr>
                                    <th>Feed Item</th>
                                    <th>Category</th>
                                    <th>Warehouse</th>
                                    <th>Purchased</th>
                                    <th>Sold</th>
                                    <th>On Hand</th>
                                    <th>Average Cost</th>
                                    <th>Stock Value</th>
                                    <th>Reorder Level</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                                    <?php
                                        $balance = $row['balance'];
                                        $item = $balance->item;
                                        $packSize = (float) $item->pack_size;
                                        $bags = $packSize > 0 ? (float) $balance->quantity / $packSize : 0;
                                        $purchasedBags = $packSize > 0 ? $row['purchased'] / $packSize : 0;
                                        $soldBags = $packSize > 0 ? $row['sold'] / $packSize : 0;
                                        $reorderKg = (float) $item->reorder_level * $packSize;
                                    ?>
                                    <tr>
                                        <td>
                                            <div class="feed-stock-name"><?php echo e($item->name); ?></div>
                                            <div class="feed-stock-code"><?php echo e($item->code); ?><?php echo e($item->brand ? ' · '.$item->brand : ''); ?></div>
                                        </td>
                                        <td><?php echo e($item->category ?: '—'); ?></td>
                                        <td><strong><?php echo e($balance->warehouse->name); ?></strong><div class="feed-small"><?php echo e($balance->warehouse->code); ?></div></td>
                                        <td><strong class="feed-positive"><?php echo e(number_format($row['purchased'], 2)); ?> KG</strong><div class="feed-small"><?php echo e(number_format($purchasedBags, 2)); ?> bags</div></td>
                                        <td><strong class="feed-negative"><?php echo e(number_format($row['sold'], 2)); ?> KG</strong><div class="feed-small"><?php echo e(number_format($soldBags, 2)); ?> bags</div></td>
                                        <td><span class="feed-stock-qty"><?php echo e(number_format((float) $balance->quantity, 2)); ?> KG</span><div class="feed-small"><?php echo e(number_format($bags, 2)); ?> bags</div></td>
                                        <td><?php echo e(\App\Support\CompanyContext::money((float) $balance->average_cost)); ?><div class="feed-small">per KG</div></td>
                                        <td><strong><?php echo e(\App\Support\CompanyContext::money($row['stock_value'])); ?></strong></td>
                                        <td><?php echo e(number_format($reorderKg, 2)); ?> KG<div class="feed-small"><?php echo e(number_format((float) $item->reorder_level, 2)); ?> bags</div></td>
                                        <td>
                                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($row['status'] === 'out'): ?>
                                                <span class="feed-status feed-status-red">Out of Stock</span>
                                            <?php elseif($row['status'] === 'low'): ?>
                                                <span class="feed-status feed-status-amber">Low Stock</span>
                                            <?php else: ?>
                                                <span class="feed-status feed-status-green">In Stock</span>
                                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                        </td>
                                    </tr>
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </div>
        </section>

        <div class="feed-split-panels">
            <section class="feed-card">
                <div class="feed-card-header">
                    <div>
                        <div class="feed-card-title">Recent Stock Movements</div>
                        <div class="feed-card-sub">Latest posted purchase and sale entries.</div>
                    </div>
                </div>
                <div class="feed-card-body">
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($recentMovementCards->isEmpty()): ?>
                        <div class="feed-empty-note">No feed stock movements found.</div>
                    <?php else: ?>
                        <div class="feed-movement-list">
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $recentMovementCards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $movement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                                <div class="feed-movement-item">
                                    <div>
                                        <strong><?php echo e($movement->item->name); ?></strong>
                                        <span><?php echo e($movement->movement_date->format('Y-m-d')); ?> · <?php echo e($movement->transaction->voucher_no); ?> · <?php echo e($movement->warehouse->name); ?></span>
                                    </div>
                                    <div class="<?php echo e($movement->movement_type === 'PURCHASE' ? 'feed-positive' : 'feed-negative'); ?>">
                                        <?php echo e($movement->movement_type === 'PURCHASE' ? '+' : '−'); ?><?php echo e(number_format((float) ($movement->movement_type === 'PURCHASE' ? $movement->quantity_in : $movement->quantity_out), 2)); ?> KG
                                    </div>
                                </div>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                        </div>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </div>
            </section>

            <section class="feed-card">
                <div class="feed-card-header">
                    <div>
                        <div class="feed-card-title">Stock Alerts</div>
                        <div class="feed-card-sub">Items needing attention.</div>
                    </div>
                </div>
                <div class="feed-card-body">
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($alertRows->isEmpty()): ?>
                        <div class="feed-info-banner feed-info-green">All visible feed stock is above its reorder level.</div>
                    <?php else: ?>
                        <div class="feed-alert-list">
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $alertRows->take(8); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                                <?php ($balance = $row['balance']); ?>
                                <div class="feed-alert-item">
                                    <div>
                                        <strong><?php echo e($balance->item->name); ?></strong>
                                        <span><?php echo e($balance->warehouse->name); ?> · <?php echo e(number_format((float) $balance->quantity, 2)); ?> KG remaining</span>
                                    </div>
                                    <span class="feed-status <?php echo e($row['status'] === 'out' ? 'feed-status-red' : 'feed-status-amber'); ?>"><?php echo e($row['status'] === 'out' ? 'Out' : 'Low'); ?></span>
                                </div>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                        </div>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </div>
            </section>
        </div>

        <section class="feed-card feed-section-gap">
            <div class="feed-card-header">
                <div>
                    <div class="feed-card-title">Stock Ledger</div>
                    <div class="feed-card-sub">The voucher is the same voucher stored in Transaction Register and Journal Entries.</div>
                </div>
            </div>
            <div class="feed-card-body">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($recentMovements->isEmpty()): ?>
                    <div class="feed-empty-note">No feed stock movements found.</div>
                <?php else: ?>
                    <div class="feed-table-wrap">
                        <table class="feed-table">
                            <thead>
                                <tr>
                                    <th>Date</th>
                                    <th>Voucher</th>
                                    <th>Movement</th>
                                    <th>Item</th>
                                    <th>Warehouse</th>
                                    <th>Party</th>
                                    <th>Quantity In</th>
                                    <th>Quantity Out</th>
                                    <th>Running Balance</th>
                                    <th>Cost Value</th>
                                    <th>Receipt</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $recentMovements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $movement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                                    <tr>
                                        <td><?php echo e($movement->movement_date->format('Y-m-d')); ?></td>
                                        <td><strong><?php echo e($movement->transaction->voucher_no); ?></strong></td>
                                        <td><span class="feed-status <?php echo e($movement->movement_type === 'PURCHASE' ? 'feed-status-blue' : 'feed-status-green'); ?>"><?php echo e($movement->movement_type === 'PURCHASE' ? 'Feed Purchase' : 'Feed Sale'); ?></span></td>
                                        <td><strong><?php echo e($movement->item->name); ?></strong><div class="feed-small"><?php echo e($movement->item->code); ?></div></td>
                                        <td><?php echo e($movement->warehouse->name); ?></td>
                                        <td><?php echo e($movement->transaction->party?->name ?? '—'); ?></td>
                                        <td><?php echo e((float) $movement->quantity_in > 0 ? number_format((float) $movement->quantity_in, 2).' KG' : '—'); ?></td>
                                        <td><?php echo e((float) $movement->quantity_out > 0 ? number_format((float) $movement->quantity_out, 2).' KG' : '—'); ?></td>
                                        <td><strong><?php echo e(number_format((float) $movement->quantity_after, 2)); ?> KG</strong></td>
                                        <td><?php echo e(\App\Support\CompanyContext::money((float) $movement->total_value)); ?></td>
                                        <td>
                                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($movement->movement_type === \App\Models\Feed\FeedStockMovement::TYPE_PURCHASE && $movement->document): ?>
                                                <a class="feed-btn feed-btn-sm" href="<?php echo e(route('feed.purchases.receipt', $movement->document)); ?>" target="_blank" rel="noopener">Print</a>
                                            <?php else: ?>
                                                —
                                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                        </td>
                                    </tr>
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </div>
        </section>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9bfc79a588c44096104b78e73dee62a6)): ?>
<?php $attributes = $__attributesOriginal9bfc79a588c44096104b78e73dee62a6; ?>
<?php unset($__attributesOriginal9bfc79a588c44096104b78e73dee62a6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9bfc79a588c44096104b78e73dee62a6)): ?>
<?php $component = $__componentOriginal9bfc79a588c44096104b78e73dee62a6; ?>
<?php unset($__componentOriginal9bfc79a588c44096104b78e73dee62a6); ?>
<?php endif; ?>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel/hisebghor/resources/views/feed/inventory/index.blade.php ENDPATH**/ ?>