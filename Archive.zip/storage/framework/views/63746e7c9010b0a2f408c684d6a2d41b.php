<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'context',
    'value' => null,
    'variant' => 'accounting',
    'backdated' => false,
    'inputId' => 'transaction_date',
    'label' => 'Date',
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'context',
    'value' => null,
    'variant' => 'accounting',
    'backdated' => false,
    'inputId' => 'transaction_date',
    'label' => 'Date',
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php
    $isFeed = $variant === 'feed';
    $fieldClass = $isFeed ? 'feed-field' : 'hg-field';
    $controlClass = $isFeed ? 'feed-control' : '';
    $requiredClass = $isFeed ? 'feed-req' : 'hg-required';
    $helpClass = $isFeed ? 'feed-help' : 'hg-field-help';
    $errorClass = $isFeed ? 'feed-warning-text' : 'hg-field-error';
    $today = (string) ($context['today'] ?? now()->toDateString());
    $normalDate = (string) ($context['default'] ?? $today);
    $selectedDate = (string) old('transaction_date', $value ?? $normalDate);
    $selectedIsPast = $selectedDate !== '' && $selectedDate < $today;
    $backdatedChecked = (bool) old('is_backdated', $backdated || $selectedIsPast);
    $ranges = $context['ranges'] ?? [];
    $rangeSummary = collect($ranges)
        ->map(fn (array $range): string => ($range['name'] ?? 'Open period').' ('.$range['start'].' to '.$range['end'].')')
        ->implode(', ');
    $toggleId = $inputId.'_backdated';
    $openMin = (string) ($context['min'] ?? '');
    $openMax = (string) ($context['max'] ?? '');
    $backdatedMax = $openMax !== '' && $today !== ''
        ? min($openMax, $today)
        : ($openMax !== '' ? $openMax : $today);
    $initialMin = $backdatedChecked ? $openMin : $normalDate;
    $initialMax = $backdatedChecked ? $backdatedMax : $normalDate;
?>

<div class="<?php echo e($fieldClass); ?> hg-backdated-date-field <?php echo e($backdatedChecked ? 'is-backdated' : 'is-date-locked'); ?>" data-backdated-entry>
    <div class="hg-backdated-date-header">
        <label for="<?php echo e($inputId); ?>"><?php echo e($label); ?> <span class="<?php echo e($requiredClass); ?>">*</span></label>
        <label class="hg-checkbox-label hg-backdated-toggle" for="<?php echo e($toggleId); ?>">
            <input type="hidden" name="is_backdated" value="0">
            <input
                id="<?php echo e($toggleId); ?>"
                name="is_backdated"
                type="checkbox"
                value="1"
                data-backdated-toggle
                <?php if($backdatedChecked): echo 'checked'; endif; ?>
                <?php if(! ($context['backdated_enabled'] ?? false) && ! $selectedIsPast): echo 'disabled'; endif; ?>
            >
            <span>Backdated Entry</span>
        </label>
    </div>

    <input
        class="<?php echo e($controlClass); ?>"
        id="<?php echo e($inputId); ?>"
        name="transaction_date"
        type="date"
        value="<?php echo e($selectedDate); ?>"
        <?php if($initialMin !== ''): ?> min="<?php echo e($initialMin); ?>" <?php endif; ?>
        <?php if($initialMax !== ''): ?> max="<?php echo e($initialMax); ?>" <?php endif; ?>
        data-backdated-date
        data-today="<?php echo e($today); ?>"
        data-normal-date="<?php echo e($normalDate); ?>"
        data-open-period-min="<?php echo e($openMin); ?>"
        data-open-period-max="<?php echo e($openMax); ?>"
        data-backdated-max="<?php echo e($backdatedMax); ?>"
        data-open-period-ranges="<?php echo e(json_encode($ranges, JSON_HEX_APOS | JSON_HEX_QUOT | JSON_UNESCAPED_UNICODE)); ?>"
        aria-readonly="<?php echo e($backdatedChecked ? 'false' : 'true'); ?>"
        <?php if(! $backdatedChecked): echo 'readonly'; endif; ?>
        required
    >

    <div class="<?php echo e($helpClass); ?>" data-backdated-help>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($rangeSummary !== ''): ?>
            Available open periods: <?php echo e($rangeSummary); ?>.
        <?php else: ?>
            No active open financial year is available for posting.
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    </div>
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['transaction_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="<?php echo e($errorClass); ?>"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['is_backdated'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="<?php echo e($errorClass); ?>"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
</div>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel/hisebghor/resources/views/components/accounting/backdated-date-field.blade.php ENDPATH**/ ?>