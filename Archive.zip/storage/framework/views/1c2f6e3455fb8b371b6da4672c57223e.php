<?php if (isset($component)) { $__componentOriginal9bfc79a588c44096104b78e73dee62a6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9bfc79a588c44096104b78e73dee62a6 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'f4ac99e09542ff494432bc959d4fee61::accounting','data' => ['title' => 'Ledger Report']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layouts::accounting'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Ledger Report']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

    <div class="hg-report-page">
        <div class="hg-page-header hg-report-page-header">
            <div>
                <h1>Ledger Report</h1>
                <p>Shows account-wise posted journal movement with opening and running balance.</p>
            </div>
        </div>

        <?php if (isset($component)) { $__componentOriginal74cc1c13d0f4b30c215f90a3e80a6e0f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal74cc1c13d0f4b30c215f90a3e80a6e0f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.reports.partials.filter-toolbar','data' => ['action' => route('reports.ledger-report'),'exportUrl' => route('reports.ledger-report', request()->query() + ['export' => 'csv'])]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('reports.partials.filter-toolbar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['action' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('reports.ledger-report')),'export-url' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('reports.ledger-report', request()->query() + ['export' => 'csv']))]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

            <label>
                <span>From date</span>
                <input type="date" name="from_date" value="<?php echo e($report['from_date']); ?>">
            </label>
            <label>
                <span>To date</span>
                <input type="date" name="to_date" value="<?php echo e($report['to_date']); ?>">
            </label>
            <label>
                <span>Account</span>
                <select name="account_id" required>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $report['accounts']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $account): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                        <option value="<?php echo e($account->id); ?>" <?php if((int) $report['account_id'] === (int) $account->id): echo 'selected'; endif; ?>>
                            <?php echo e($account->code); ?> — <?php echo e($account->name); ?>

                        </option>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                </select>
            </label>
            <label>
                <span>Party</span>
                <select name="party_id">
                    <option value="">All parties</option>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $report['parties']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $party): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                        <option value="<?php echo e($party->id); ?>" <?php if((int) ($report['party_id'] ?? 0) === (int) $party->id): echo 'selected'; endif; ?>>
                            <?php echo e($party->code); ?> — <?php echo e($party->name); ?>

                        </option>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                </select>
            </label>
            <label>
                <span>Search</span>
                <input type="search" name="search" value="<?php echo e(request('search')); ?>" placeholder="Voucher or description">
            </label>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal74cc1c13d0f4b30c215f90a3e80a6e0f)): ?>
<?php $attributes = $__attributesOriginal74cc1c13d0f4b30c215f90a3e80a6e0f; ?>
<?php unset($__attributesOriginal74cc1c13d0f4b30c215f90a3e80a6e0f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal74cc1c13d0f4b30c215f90a3e80a6e0f)): ?>
<?php $component = $__componentOriginal74cc1c13d0f4b30c215f90a3e80a6e0f; ?>
<?php unset($__componentOriginal74cc1c13d0f4b30c215f90a3e80a6e0f); ?>
<?php endif; ?>

        <div class="hg-grid hg-grid-4 hg-report-summary">
            <section class="hg-card hg-metric"><span class="label">Opening Debit</span><div class="value"><?php echo e(\App\Support\CompanyContext::money($report['opening_debit'])); ?></div></section>
            <section class="hg-card hg-metric"><span class="label">Opening Credit</span><div class="value"><?php echo e(\App\Support\CompanyContext::money($report['opening_credit'])); ?></div></section>
            <section class="hg-card hg-metric"><span class="label">Period Debit</span><div class="value"><?php echo e(\App\Support\CompanyContext::money($report['period_debit'])); ?></div></section>
            <section class="hg-card hg-metric"><span class="label">Period Credit</span><div class="value"><?php echo e(\App\Support\CompanyContext::money($report['period_credit'])); ?></div></section>
        </div>

        <section class="hg-card">
            <h2 class="hg-card-title">
                Ledger Details
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($report['account']): ?>
                    <span class="hg-muted">— <?php echo e($report['account']->code); ?> <?php echo e($report['account']->name); ?></span>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </h2>

            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(! $report['account']): ?>
                <div class="hg-empty">No account found.</div>
            <?php else: ?>
                <div class="hg-table-wrap">
                    <table class="hg-table hg-report-table">
                        <thead>
                            <tr>
                                <th>Date</th>
                                <th>Voucher</th>
                                <th>Description</th>
                                <th>Party</th>
                                <th class="right">Debit</th>
                                <th class="right">Credit</th>
                                <th class="right">Balance</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr class="hg-ledger-opening-row">
                                <td><?php echo e($report['from_date']); ?></td>
                                <td>Opening</td>
                                <td>Opening balance before selected period</td>
                                <td><?php echo e($report['party'] ? $report['party']->code.' — '.$report['party']->name : 'All'); ?></td>
                                <td class="right"><?php echo e(\App\Support\CompanyContext::money($report['opening_debit'])); ?></td>
                                <td class="right"><?php echo e(\App\Support\CompanyContext::money($report['opening_credit'])); ?></td>
                                <td class="right"><?php echo e(\App\Support\CompanyContext::money(max($report['opening_debit'], $report['opening_credit']))); ?> <?php echo e($report['opening_debit'] >= $report['opening_credit'] ? 'Dr' : 'Cr'); ?></td>
                            </tr>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $report['rows']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                                <tr>
                                    <td><?php echo e($row['date']); ?></td>
                                    <td><strong><?php echo e($row['voucher_no']); ?></strong><br><span class="hg-muted"><?php echo e($row['transaction_head']); ?></span></td>
                                    <td><?php echo e($row['description']); ?></td>
                                    <td><?php echo e($row['party'] ?? '—'); ?></td>
                                    <td class="right"><?php echo e(\App\Support\CompanyContext::money($row['debit'])); ?></td>
                                    <td class="right"><?php echo e(\App\Support\CompanyContext::money($row['credit'])); ?></td>
                                    <td class="right"><strong><?php echo e(\App\Support\CompanyContext::money($row['balance'])); ?> <?php echo e($row['balance_type']); ?></strong></td>
                                </tr>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                                <tr><td colspan="7"><div class="hg-empty">No posted ledger movement found for this period.</div></td></tr>
                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </tbody>
                        <tfoot>
                            <tr>
                                <th colspan="4">Period Total</th>
                                <th class="right"><?php echo e(\App\Support\CompanyContext::money($report['period_debit'])); ?></th>
                                <th class="right"><?php echo e(\App\Support\CompanyContext::money($report['period_credit'])); ?></th>
                                <th></th>
                            </tr>
                            <tr>
                                <th colspan="4">Closing Balance</th>
                                <th class="right"><?php echo e(\App\Support\CompanyContext::money($report['closing_debit'])); ?></th>
                                <th class="right"><?php echo e(\App\Support\CompanyContext::money($report['closing_credit'])); ?></th>
                                <th></th>
                            </tr>
                        </tfoot>
                    </table>
                </div>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </section>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9bfc79a588c44096104b78e73dee62a6)): ?>
<?php $attributes = $__attributesOriginal9bfc79a588c44096104b78e73dee62a6; ?>
<?php unset($__attributesOriginal9bfc79a588c44096104b78e73dee62a6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9bfc79a588c44096104b78e73dee62a6)): ?>
<?php $component = $__componentOriginal9bfc79a588c44096104b78e73dee62a6; ?>
<?php unset($__componentOriginal9bfc79a588c44096104b78e73dee62a6); ?>
<?php endif; ?>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel/hisebghor/resources/views/reports/ledger-report.blade.php ENDPATH**/ ?>