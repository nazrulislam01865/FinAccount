<?php
    $transaction = $transaction ?? null;
    $isEditing = $transaction !== null;
    $dueSettlementContext = $dueSettlementContext ?? ['active' => false];
    $isDueSettlement = (bool) ($dueSettlementContext['active'] ?? false);
    $formAction = $isEditing ? route('transactions.update', $transaction) : route('transactions.store');
    $categoryRepairRequired = $categoryRepairRequired ?? false;
    $transactionDateContext = $transactionDateContext ?? ['min' => null, 'max' => null, 'default' => now()->toDateString(), 'label' => null, 'today' => now()->toDateString(), 'backdated_enabled' => false, 'ranges' => []];
    $backdatedEntryRequested = $backdatedEntryRequested ?? request()->boolean('backdated');
    $selectedHeadId = old('transaction_head_id', $isEditing ? $transaction->transaction_head_id : ($dueSettlementContext['transaction_head_id'] ?? ''));
    $selectedSettlement = old('settlement_type', $isEditing ? ($transaction->settlement_type ?: \App\Support\TransactionTypes::CASH) : \App\Support\TransactionTypes::CASH);
    $selectedAmount = old('amount', $isEditing ? $transaction->amount : ($dueSettlementContext['amount'] ?? ''));
    $selectedPaidAmount = old('paid_amount', $isEditing ? $transaction->paid_amount : ($isDueSettlement ? ($dueSettlementContext['amount'] ?? '') : ''));
    $transactionCategories = $transactionCategories ?? collect();
    $filteredTransactionCategories = $filteredTransactionCategories ?? $transactionCategories;
    $transactionDirectionOptions = $transactionDirectionOptions ?? \App\Support\TransactionTypes::flowLabels();
    $transactionCategoryDirections = $transactionCategoryDirections ?? $transactionCategories
        ->mapWithKeys(fn ($option) => [$option->value => \App\Support\TransactionTypes::flow((string) $option->value, is_array($option->metadata) ? $option->metadata : [])])
        ->all();
    $activeTransactionDirection = $activeTransactionDirection
        ?? ($transactionCategoryDirections[$category] ?? null);
    $transactionTypeLabel = $transactionTypeDefinition['label'] ?? ($categoryOption?->label ?? $category ?: 'Transaction');
    $isTransferTransaction = ($transactionTypeDefinition['flow'] ?? null) === \App\Support\TransactionTypes::FLOW_TRANSFER;
    $pageTransactionLabel = filled($category)
        ? ($category === \App\Support\TransactionTypes::SALE ? 'Sales' : $transactionTypeLabel)
        : 'Transaction';
    $moneyLabel = $isTransferTransaction ? 'From account' : ($transactionTypeDefinition['money_label'] ?? 'Cash / Bank / Mobile Account');
    $partyLabel = $transactionTypeDefinition['party_label'] ?? 'Party';
    $showTransactionTypeSelection = $showTransactionTypeSelection ?? ($isEditing || $isDueSettlement || request()->filled('direction') || request()->filled('category'));
    $hasSelectedTransactionDirection = $isEditing || $isDueSettlement || filled($activeTransactionDirection);
    $hasTransactionTypeForDirection = $hasSelectedTransactionDirection && $filteredTransactionCategories->isNotEmpty();
    $highlightTransactionDirection = $showTransactionTypeSelection && $hasSelectedTransactionDirection;
    $transactionHeadsAreUnfiltered = $transactionHeadsAreUnfiltered ?? false;
    $transactionHeadsAreDirectionFiltered = $transactionHeadsAreDirectionFiltered ?? false;
    $transactionTypeLabels = $transactionTypeLabels ?? $transactionCategories->mapWithKeys(fn ($option) => [$option->value => $option->label])->all();
    $saleSellingTypeOptions = $saleSellingTypeOptions ?? \App\Support\SaleSellingTypes::labels();
    $saleTrackingUnits = $saleTrackingUnits ?? collect();
    $defaultSaleTrackingUnitId = $defaultSaleTrackingUnitId ?? null;
    $isSalesTransaction = \App\Support\SaleSellingTypes::isSaleCategory($category);
    $saleBusinessAreas = $saleBusinessAreas ?? collect();
    $saleBusinessItemsForJs = $saleBusinessItemsForJs ?? collect();
    $saleBusinessLocations = $saleBusinessLocations ?? collect();
    $defaultSellingType = $saleBusinessAreas->first()?->code ?: \App\Support\SaleSellingTypes::OTHERS;
    $selectedSellingType = \App\Support\SaleSellingTypes::normalize(old('selling_type', $isEditing ? ($transaction->selling_type ?: $defaultSellingType) : $defaultSellingType));
    $defaultBusinessLocationId = $saleBusinessLocations->firstWhere('business_area', $selectedSellingType)?->id;
    $selectedTrackingUnitId = old('tracking_unit_id', $isEditing ? $transaction->tracking_unit_id : $defaultBusinessLocationId);
    $showSaleWarehouse = false;
    $saleFeedModeSelected = $isSalesTransaction && ! \App\Support\SaleSellingTypes::isOthers($selectedSellingType);

    $saleCustomers = $saleCustomers ?? collect();
    $saleFeedItems = $saleFeedItems ?? collect();
    $saleStockBalances = $saleStockBalances ?? collect();
    $selectedSalePartyId = old('party_id', $isEditing ? $transaction->party_id : ($dueSettlementContext['party_id'] ?? ''));
    $selectedTransferToMoneyAccountId = old('transfer_to_money_account_id', $isEditing ? $transaction->transfer_to_money_account_id : '');
    $selectedSaleOtherCharges = old('other_charges', 0);
    $defaultSaleBusinessItem = $saleBusinessItemsForJs
        ->first(fn ($item) => ($item['businessArea'] ?? null) === $selectedSellingType)
        ?? $saleBusinessItemsForJs->first();
    $saleInitialLines = old('lines', [[
        'item_name' => data_get($defaultSaleBusinessItem, 'name', ''),
        'unit' => 'Unit',
        'quantity' => 1,
        'rate' => data_get($defaultSaleBusinessItem, 'salePrice', 0),
        'discount' => 0,
    ]]);
    $saleFeedItemsForJs = $saleBusinessItemsForJs;
?>

<?php if (isset($component)) { $__componentOriginal9bfc79a588c44096104b78e73dee62a6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9bfc79a588c44096104b78e73dee62a6 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'f4ac99e09542ff494432bc959d4fee61::accounting','data' => ['title' => 'Transaction Entry']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layouts::accounting'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Transaction Entry']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

    <div class="hg-page-header">
        <div>
            <h1><?php echo e($isEditing ? 'Edit '.$pageTransactionLabel.' Transaction' : (filled($category) ? 'Record '.$pageTransactionLabel.' Transaction' : 'Record Transaction')); ?></h1>
            <p class="hg-muted"><?php echo e($isDueSettlement ? 'Settle the selected due. Party, due ledger, and transaction head are filled automatically.' : 'Enter the transaction details. Payment status and the journal are calculated automatically.'); ?></p>
        </div>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(! $isEditing && ! $isDueSettlement && auth()->user()?->canAccounting('transactions.manage')): ?>
            <div class="hg-actions">
                <a class="hg-btn" href="<?php echo e(route('feed.purchases.create', ['backdated' => $backdatedEntryRequested ? 1 : null])); ?>">🛒 Feed Purchase</a>
                <a class="hg-btn" href="<?php echo e(route('feed.sales.create', ['backdated' => $backdatedEntryRequested ? 1 : null])); ?>">🧾 Feed Sale</a>
            </div>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    </div>

    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(! $isDueSettlement && (! $isEditing || $categoryRepairRequired)): ?>
        <div class="hg-entry-filter-panel">
            <div class="hg-page-kicker">Transaction Direction</div>
            <div class="hg-tabs hg-transaction-direction-tabs" aria-label="Transaction Direction">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $transactionDirectionOptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $directionValue => $directionLabel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                    <a
                        href="<?php echo e($isEditing ? route('transactions.edit', [$transaction, 'direction' => $directionValue]) : route('transactions.create', ['direction' => $directionValue, 'backdated' => $backdatedEntryRequested ? 1 : null])); ?>"
                        class="<?php echo e($highlightTransactionDirection && $activeTransactionDirection === $directionValue ? 'active' : ''); ?>"
                        data-transaction-direction-tab
                        data-direction="<?php echo e($directionValue); ?>"
                        <?php if($highlightTransactionDirection && $activeTransactionDirection === $directionValue): ?> aria-current="page" <?php endif; ?>
                    >
                        <?php echo e($directionLabel); ?>

                    </a>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
            </div>

            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($showTransactionTypeSelection && $hasSelectedTransactionDirection): ?>
                <div class="hg-page-kicker">Transaction Type</div>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($filteredTransactionCategories->isEmpty()): ?>
                    <div class="hg-notice" style="margin-bottom:14px">
                        No active transaction type is set up under <?php echo e($transactionDirectionOptions[$activeTransactionDirection] ?? \App\Support\TransactionTypes::flowLabel((string) $activeTransactionDirection)); ?>.
                        Add or edit a Transaction Type and select this Transaction Direction from Master Data.
                    </div>
                <?php else: ?>
                    <div class="hg-tabs hg-transaction-type-tabs" aria-label="Filtered Transaction Types">
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $filteredTransactionCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoryTab): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                            <?php
                                $definition = \App\Support\TransactionTypes::definition($categoryTab->value);
                            ?>
                            <a
                                href="<?php echo e($isEditing ? route('transactions.edit', [$transaction, 'category' => $categoryTab->value]) : route('transactions.create', ['direction' => $activeTransactionDirection, 'category' => $categoryTab->value, 'backdated' => $backdatedEntryRequested ? 1 : null])); ?>"
                                class="<?php echo e(strcasecmp((string) $category, (string) $categoryTab->value) === 0 ? 'active' : ''); ?>"
                                data-transaction-category-tab
                                data-direction="<?php echo e($transactionCategoryDirections[$categoryTab->value] ?? $activeTransactionDirection); ?>"
                                data-category="<?php echo e($categoryTab->value); ?>"
                                <?php if(strcasecmp((string) $category, (string) $categoryTab->value) === 0): ?> aria-current="page" <?php endif; ?>
                            >
                                <?php echo e($definition['label'] ?? $categoryTab->label); ?>

                            </a>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                    </div>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </div>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($isEditing && $transaction->status === 'incomplete'): ?>
        <div class="hg-notice" style="margin-bottom:14px"><strong>This transaction is incomplete.</strong> Select valid active setup records and update it to rebuild the journal.</div>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(! $categoryOption && ! $isDueSettlement): ?>
        <section class="hg-card">
            <h2 class="hg-card-title">No Transaction Type Available</h2>
            <p class="hg-muted">Create or activate a Transaction Type before recording a transaction.</p>
        </section>
    <?php else: ?>
    <div class="hg-grid hg-grid-2 hg-entry-grid" data-transaction-entry>
        <section class="hg-card">
            <form method="POST" action="<?php echo e($formAction); ?>" enctype="multipart/form-data" class="hg-form-grid hg-transaction-entry-form" data-transaction-form data-default-allowed-settlements='<?php echo json_encode($isDueSettlement ? [\App\Support\TransactionTypes::CASH] : ($transactionTypeDefinition['allowed_settlements'] ?? \App\Support\TransactionTypes::ALL_SETTLEMENTS), 15, 512) ?>' data-transaction-flow="<?php echo e($transactionTypeDefinition['flow'] ?? ''); ?>" data-auto-sync-paid="<?php echo e((! $isEditing && old('paid_amount') === null && ! $isDueSettlement) ? '1' : '0'); ?>" data-due-settlement="<?php echo e($isDueSettlement ? '1' : '0'); ?>" data-draft-form data-draft-key="<?php echo e($isEditing ? 'transactions.edit.'.$transaction->id : 'transactions.create.'.\Illuminate\Support\Str::slug((string) $category, '_')); ?>" data-draft-title="<?php echo e($isEditing ? 'Edit Transaction' : 'New '.($categoryOption?->label ?? $category).' Transaction'); ?>">
                <?php echo csrf_field(); ?>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($isEditing): ?> <?php echo method_field('PUT'); ?> <?php else: ?> <input type="hidden" name="request_token" value="<?php echo e($requestToken); ?>"> <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                <input type="hidden" name="category" value="<?php echo e($category); ?>" data-transaction-category-input>
                <input type="hidden" id="settlement_type" name="settlement_type" value="<?php echo e($isDueSettlement ? \App\Support\TransactionTypes::CASH : $selectedSettlement); ?>">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($isDueSettlement): ?>
                    <input type="hidden" name="due_settlement" value="1">
                    <input type="hidden" name="due_type" value="<?php echo e($dueSettlementContext['due_type'] ?? ''); ?>">
                    <input type="hidden" name="due_party_id" value="<?php echo e($dueSettlementContext['party_id'] ?? ''); ?>">
                    <input type="hidden" name="due_account_id" value="<?php echo e($dueSettlementContext['account_id'] ?? ''); ?>">
                    <input type="hidden" name="due_as_of_date" value="<?php echo e($dueSettlementContext['as_of_date'] ?? ''); ?>">
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($isDueSettlement): ?>
                    <div class="hg-field full hg-due-settlement-entry-card">
                        <div>
                            <span class="hg-overline">Due Settlement</span>
                            <strong><?php echo e(($dueSettlementContext['due_type'] ?? '') === 'Receivable' ? 'Customer Due Collection' : 'Supplier Due Payment'); ?></strong>
                            <small><?php echo e($dueSettlementContext['party_label'] ?? 'Party not selected'); ?></small>
                        </div>
                        <div>
                            <span>Due Ledger</span>
                            <strong><?php echo e($dueSettlementContext['account_label'] ?? 'Not available'); ?></strong>
                        </div>
                        <div>
                            <span>Total Outstanding</span>
                            <strong><?php echo e(\App\Support\CompanyContext::money((float) ($dueSettlementContext['amount'] ?? 0))); ?></strong>
                        </div>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($dueSettlementContext['message'] ?? null): ?>
                            <p class="hg-field-error full"><?php echo e($dueSettlementContext['message']); ?></p>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </div>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                <?php if (isset($component)) { $__componentOriginal33184e926771d74b634dc9f72a6b4f10 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal33184e926771d74b634dc9f72a6b4f10 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.accounting.backdated-date-field','data' => ['context' => $transactionDateContext,'value' => $isEditing ? $transaction->transaction_date->format('Y-m-d') : ($dueSettlementContext['as_of_date'] ?? $transactionDateContext['default']),'backdated' => $backdatedEntryRequested ?? false]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('accounting.backdated-date-field'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['context' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($transactionDateContext),'value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($isEditing ? $transaction->transaction_date->format('Y-m-d') : ($dueSettlementContext['as_of_date'] ?? $transactionDateContext['default'])),'backdated' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($backdatedEntryRequested ?? false)]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal33184e926771d74b634dc9f72a6b4f10)): ?>
<?php $attributes = $__attributesOriginal33184e926771d74b634dc9f72a6b4f10; ?>
<?php unset($__attributesOriginal33184e926771d74b634dc9f72a6b4f10); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal33184e926771d74b634dc9f72a6b4f10)): ?>
<?php $component = $__componentOriginal33184e926771d74b634dc9f72a6b4f10; ?>
<?php unset($__componentOriginal33184e926771d74b634dc9f72a6b4f10); ?>
<?php endif; ?>

                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($isSalesTransaction && ! $isDueSettlement): ?>
                    <div class="hg-field full">
                        <label for="selling_type">What are you selling? <span class="hg-required">*</span></label>
                        <select id="selling_type" name="selling_type" required data-sale-selling-type>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $saleSellingTypeOptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sellingTypeValue => $sellingTypeLabel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                                <?php
                                    $isOtherSellingType = \App\Support\SaleSellingTypes::isOthers($sellingTypeValue);
                                ?>
                                <option
                                    value="<?php echo e($sellingTypeValue); ?>"
                                    data-business-area="<?php echo e($isOtherSellingType ? '' : $sellingTypeValue); ?>"
                                    data-requires-warehouse="0"
                                    data-feed-sale-mode="<?php echo e($isOtherSellingType ? '0' : '1'); ?>"
                                    <?php if((string) $selectedSellingType === (string) $sellingTypeValue): echo 'selected'; endif; ?>
                                ><?php echo e($sellingTypeLabel); ?></option>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                        </select>
                        <small class="hg-field-help">Business areas come from Business Tracking Setup. Select Others for a normal sale without item lines.</small>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['selling_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small class="hg-field-error"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </div>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(! $isTransferTransaction): ?>
                    <div class="hg-field <?php echo e($isDueSettlement ? 'hidden' : ''); ?>">
                        <label for="transaction_head_id">Transaction Head <span class="hg-required">*</span></label>
                        <select
                            id="transaction_head_id"
                            name="transaction_head_id"
                            required
                            data-hg-searchable
                            data-hg-search-placeholder="Search transaction head by name, code or ledger..."
                            data-hg-search-empty="No matching transaction head found"
                        >
                            <option value=""><?php echo e($transactionHeads->isEmpty() ? 'No active transaction head available' : ($transactionHeadsAreUnfiltered ? 'Select transaction head from all types' : ($transactionHeadsAreDirectionFiltered ? 'Select transaction head for this direction' : 'Select transaction head'))); ?></option>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $transactionHeads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $head): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                                <?php
                                    $headCategory = (string) $head->category;
                                    $headCategoryMetadata = is_array($transactionCategories->firstWhere('value', $headCategory)?->metadata ?? null)
                                        ? $transactionCategories->firstWhere('value', $headCategory)->metadata
                                        : [];
                                    $headDefinition = \App\Support\TransactionTypes::configuredDefinition(
                                        $headCategory,
                                        $headCategoryMetadata,
                                        $transactionTypeLabels[$headCategory] ?? $headCategory
                                    );
                                ?>
                                <option
                                    value="<?php echo e($head->id); ?>"
                                    data-title="<?php echo e($transactionHeadsAreUnfiltered ? (($transactionTypeLabels[$headCategory] ?? $headCategory).' — ') : ''); ?><?php echo e($head->name); ?>"
                                    data-meta="<?php echo e($head->code); ?><?php echo e($head->postingAccount ? ' — '.$head->postingAccount->code.' '.$head->postingAccount->name : ''); ?>"
                                    data-search-keywords="<?php echo e($headCategory); ?> <?php echo e($transactionTypeLabels[$headCategory] ?? ''); ?> <?php echo e(implode(' ', $head->allowedSettlementCodes())); ?>"
                                    data-allowed-settlements="<?php echo e(json_encode($head->allowedSettlementCodes())); ?>"
                                    data-category="<?php echo e($headCategory); ?>"
                                    data-direction="<?php echo e($transactionCategoryDirections[$headCategory] ?? ($headDefinition['flow'] ?? '')); ?>"
                                    data-party-type="<?php echo e($head->party_type ?: ($headDefinition['party_type'] ?? ($transactionTypeDefinition['party_type'] ?? 'Any'))); ?>"
                                    <?php if((string) $selectedHeadId === (string) $head->id): echo 'selected'; endif; ?>
                                ><?php echo e($transactionHeadsAreUnfiltered ? (($transactionTypeLabels[$headCategory] ?? $headCategory).' — ') : ''); ?><?php echo e($head->name); ?></option>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                        </select>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['transaction_head_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small class="hg-field-error"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($transactionHeads->isEmpty() && ! $isDueSettlement): ?>
                            <small class="hg-field-error"><?php echo e($transactionHeadsAreUnfiltered ? 'No active Transaction Head is available. Activate or create at least one head with an active posting account.' : 'No active Transaction Head is linked to '.$transactionTypeLabel.'. Activate or create a matching head with an active posting account.'); ?></small>
                        <?php elseif($transactionHeadsAreUnfiltered): ?>
                            <small class="hg-field-help">No transaction direction is selected, so all active transaction heads are shown. Selecting a direction or transaction type above will filter this list.</small>
                        <?php elseif($transactionHeadsAreDirectionFiltered): ?>
                            <small class="hg-field-help">This list is filtered by the selected transaction direction. Choose a transaction type above to narrow it further.</small>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </div>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($isSalesTransaction && ! $isDueSettlement): ?>
                    <div class="hg-field <?php echo e($saleFeedModeSelected ? '' : 'hidden'); ?>" data-sale-warehouse-field>
                        <label for="tracking_unit_id">Location <span class="hg-required">*</span></label>
                        <select
                            id="tracking_unit_id"
                            name="tracking_unit_id"
                            data-sale-warehouse
                            data-hg-searchable
                            data-hg-search-placeholder="Search location by name or area..."
                            data-hg-search-empty="No location found for this business area"
                        >
                            <option value="">Select location</option>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $saleBusinessLocations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $location): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                                <?php
                                    $locationLabel = trim((string) ($location->location ?: $location->name));
                                    $locationMeta = trim((string) ($location->name.($location->location ? ' — '.$location->location : '')));
                                ?>
                                <option
                                    value="<?php echo e($location->id); ?>"
                                    data-business-area="<?php echo e($location->business_area); ?>"
                                    data-title="<?php echo e($locationLabel); ?>"
                                    data-meta="<?php echo e($locationMeta); ?>"
                                    data-search-keywords="<?php echo e($location->business_area); ?> <?php echo e($location->name); ?> <?php echo e($location->location); ?>"
                                    <?php if((string) $selectedTrackingUnitId === (string) $location->id): echo 'selected'; endif; ?>
                                ><?php echo e($locationLabel); ?> <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($location->name && $location->location): ?> — <?php echo e($location->name); ?> <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?></option>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                        </select>
                        <small class="hg-field-help">Locations come from Business Tracking Setup for the selected business area.</small>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($saleBusinessLocations->isEmpty()): ?>
                            <small class="hg-field-error">Add an active location/unit in Business Tracking Setup before posting business-area sales.</small>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['tracking_unit_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small class="hg-field-error"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </div>

                    <div class="hg-field <?php echo e($saleFeedModeSelected ? '' : 'hidden'); ?>" id="party-field" data-sale-customer-field>
                        <label for="party_id"><span id="party-label">Customer</span> <span class="hg-required">*</span></label>
                        <select
                            id="party_id"
                            name="party_id"
                            data-sale-customer
                            data-hg-searchable
                            data-hg-search-placeholder="Search customer by name or code..."
                            data-hg-search-empty="No matching customer found"
                        >
                            <option value=""><?php echo e($saleCustomers->isEmpty() ? 'No active customer available' : 'Select customer'); ?></option>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $saleCustomers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                                <option
                                    value="<?php echo e($customer->id); ?>"
                                    data-title="<?php echo e($customer->name); ?>"
                                    data-meta="<?php echo e($customer->code); ?>"
                                    data-status="Customer"
                                    data-search-keywords="Customer"
                                    data-party-type="Customer"
                                    <?php if((string) $selectedSalePartyId === (string) $customer->id): echo 'selected'; endif; ?>
                                ><?php echo e($customer->code); ?> — <?php echo e($customer->name); ?></option>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                        </select>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($saleCustomers->isEmpty()): ?>
                            <small class="hg-field-error">Add an active Customer from Party Setup before posting sales.</small>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['party_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small class="hg-field-error"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </div>

                    <div class="hg-field full hg-transaction-sale-feed-section <?php echo e($saleFeedModeSelected ? '' : 'hidden'); ?>" data-transaction-sale-feed data-sale-feed-only>
                        <label>Items <span class="hg-required">*</span></label>
                        <div class="hg-sale-feed-lines-wrap">
                            <div class="hg-table-wrap hg-feed-lines-wrap">
                                <table class="hg-table hg-feed-lines-table hg-sale-feed-lines-table">
                                    <thead>
                                        <tr>
                                            <th>Item</th>
                                            <th>Unit</th>
                                            <th>Quantity</th>
                                            <th>Sale Rate</th>
                                            <th>Line Total</th>
                                            <th></th>
                                        </tr>
                                    </thead>
                                    <tbody data-transaction-sale-feed-lines></tbody>
                                </table>
                            </div>
                            <div class="hg-feed-line-actions">
                                <button class="hg-btn hg-btn-small" type="button" data-transaction-sale-feed-add>+ Add Another Item</button>
                                <span class="hg-muted">Items are loaded from the selected Business Area.</span>
                            </div>
                        </div>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($saleBusinessItemsForJs->isEmpty()): ?>
                            <small class="hg-field-error">Add active items in Business Tracking Setup before using business-area sales.</small>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['lines'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small class="hg-field-error"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </div>

                    <div class="hg-field <?php echo e($saleFeedModeSelected ? '' : 'hidden'); ?>" data-sale-feed-only>
                        <label for="sale_items_total">Total Amount (<?php echo e(\App\Support\CompanyContext::currencyCode()); ?>)</label>
                        <input id="sale_items_total" type="number" step="<?php echo e(\App\Support\CompanyContext::amountStep()); ?>" value="0" readonly data-sale-items-total class="hg-readonly-input">
                        <small class="hg-field-help">This is calculated from the Items section only.</small>
                    </div>

                    <div class="hg-field <?php echo e($saleFeedModeSelected ? '' : 'hidden'); ?>" data-sale-feed-only>
                        <label for="other_charges">Other Charges (<?php echo e(\App\Support\CompanyContext::currencyCode()); ?>)</label>
                        <input id="other_charges" name="other_charges" type="number" min="0" step="<?php echo e(\App\Support\CompanyContext::amountStep()); ?>" value="<?php echo e($selectedSaleOtherCharges); ?>" data-sale-other-charges>
                    </div>

                    <div class="hg-field">
                        <label for="amount"><span data-sale-total-bill-label><?php echo e($saleFeedModeSelected ? 'Total Bill' : 'Amount'); ?></span> (<?php echo e(\App\Support\CompanyContext::currencyCode()); ?>) <span class="hg-required">*</span></label>
                        <input id="amount" name="amount" type="number" min="<?php echo e(\App\Support\CompanyContext::amountStep()); ?>" step="<?php echo e(\App\Support\CompanyContext::amountStep()); ?>" value="<?php echo e($selectedAmount); ?>" required data-sale-total-bill <?php if($saleFeedModeSelected): echo 'readonly'; endif; ?> class="<?php echo e($saleFeedModeSelected ? 'hg-readonly-input' : ''); ?>">
                        <small class="hg-field-help" data-sale-total-bill-help><?php echo e($saleFeedModeSelected ? 'Total Bill = Total Amount + Other Charges.' : 'Enter the total sale amount for all other sales.'); ?></small>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small class="hg-field-error"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </div>
                <?php else: ?>
                    <div class="hg-field">
                        <label for="amount"><?php echo e($isDueSettlement ? (($dueSettlementContext['due_type'] ?? '') === 'Receivable' ? 'Received Amount' : 'Payment Amount') : 'Amount'); ?> (<?php echo e(\App\Support\CompanyContext::currencyCode()); ?>) <span class="hg-required">*</span></label>
                        <input id="amount" name="amount" type="number" min="<?php echo e(\App\Support\CompanyContext::amountStep()); ?>" step="<?php echo e(\App\Support\CompanyContext::amountStep()); ?>" value="<?php echo e($selectedAmount); ?>" <?php if($isDueSettlement && filled($dueSettlementContext['amount'] ?? null)): ?> max="<?php echo e($dueSettlementContext['amount']); ?>" <?php endif; ?> required>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($isDueSettlement): ?><small class="hg-field-help">Enter the amount being <?php echo e(($dueSettlementContext['due_type'] ?? '') === 'Receivable' ? 'received from the customer' : 'paid to the supplier'); ?>. It cannot be more than the outstanding due.</small><?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small class="hg-field-error"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </div>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                <div class="hg-field <?php echo e($isDueSettlement ? 'hidden' : ''); ?>" id="paid-amount-field">
                    <label for="paid_amount"><span id="paid-amount-label">Paid/Received Now</span> (<?php echo e(\App\Support\CompanyContext::currencyCode()); ?>) <span class="hg-required">*</span></label>
                    <input id="paid_amount" name="paid_amount" type="number" min="0" step="<?php echo e(\App\Support\CompanyContext::amountStep()); ?>" value="<?php echo e($selectedPaidAmount); ?>">
                    <small class="hg-field-help" id="paid-amount-help">Enter 0 when the full amount will remain due.</small>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['paid_amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small class="hg-field-error"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['settlement_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small class="hg-field-error"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </div>

                <div class="hg-field hidden" id="money-field">
                    <label for="money_account_id"><span id="money-label"><?php echo e($moneyLabel); ?></span> <span class="hg-required">*</span></label>
                    <select
                        id="money_account_id"
                        name="money_account_id"
                        data-hg-searchable
                        data-hg-search-placeholder="Search cash, bank or mobile account..."
                        data-hg-search-empty="No matching money account found"
                    >
                        <option value=""><?php echo e($moneyAccounts->isEmpty() ? 'No active money account available' : 'Select account'); ?></option>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $moneyAccounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $moneyAccount): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                            <option
                                value="<?php echo e($moneyAccount->id); ?>"
                                data-title="<?php echo e($moneyAccount->name); ?>"
                                data-meta="<?php echo e($moneyAccount->chartOfAccount?->code); ?><?php echo e($moneyAccount->chartOfAccount ? ' — '.$moneyAccount->chartOfAccount->name : ''); ?>"
                                data-status="<?php echo e($moneyKindLabels[$moneyAccount->kind] ?? $moneyAccount->kind); ?>"
                                data-search-keywords="<?php echo e($moneyAccount->kind); ?>"
                                <?php if((string) old('money_account_id', $isEditing ? $transaction->money_account_id : '') === (string) $moneyAccount->id): echo 'selected'; endif; ?>
                            ><?php echo e($moneyAccount->name); ?> — <?php echo e($moneyKindLabels[$moneyAccount->kind] ?? $moneyAccount->kind); ?></option>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                    </select>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['money_account_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small class="hg-field-error"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </div>

                <div class="hg-field hidden" id="transfer-to-field">
                    <label for="transfer_to_money_account_id"><span id="transfer-to-label">To account</span> <span class="hg-required">*</span></label>
                    <select
                        id="transfer_to_money_account_id"
                        name="transfer_to_money_account_id"
                        data-hg-searchable
                        data-hg-search-placeholder="Search destination cash, bank or mobile account..."
                        data-hg-search-empty="No matching destination account found"
                    >
                        <option value=""><?php echo e($moneyAccounts->isEmpty() ? 'No active money account available' : 'Select destination account'); ?></option>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $moneyAccounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $moneyAccount): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                            <option
                                value="<?php echo e($moneyAccount->id); ?>"
                                data-title="<?php echo e($moneyAccount->name); ?>"
                                data-meta="<?php echo e($moneyAccount->chartOfAccount?->code); ?><?php echo e($moneyAccount->chartOfAccount ? ' — '.$moneyAccount->chartOfAccount->name : ''); ?>"
                                data-status="<?php echo e($moneyKindLabels[$moneyAccount->kind] ?? $moneyAccount->kind); ?>"
                                data-search-keywords="<?php echo e($moneyAccount->kind); ?>"
                                <?php if((string) $selectedTransferToMoneyAccountId === (string) $moneyAccount->id): echo 'selected'; endif; ?>
                            ><?php echo e($moneyAccount->name); ?> — <?php echo e($moneyKindLabels[$moneyAccount->kind] ?? $moneyAccount->kind); ?></option>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                    </select>
                    <small class="hg-field-help">Transfer entry will debit To account and credit From account.</small>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['transfer_to_money_account_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small class="hg-field-error"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </div>


                <div class="hg-field hidden" id="due-amount-field">
                    <label for="due_amount_preview">Remaining Due (auto)</label>
                    <input id="due_amount_preview" type="number" step="<?php echo e(\App\Support\CompanyContext::amountStep()); ?>" value="<?php echo e(old('due_amount', $isEditing ? $transaction->due_amount : '')); ?>" readonly>
                </div>

                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if (! ($isSalesTransaction && ! $isDueSettlement)): ?>
                <div class="hg-field hidden" id="party-field">
                    <label for="party_id"><span id="party-label"><?php echo e($partyLabel); ?></span> <span class="hg-required">*</span></label>
                    <select
                        id="party_id"
                        name="party_id"
                        data-hg-searchable
                        data-hg-search-placeholder="Search party by name, code or type..."
                        data-hg-search-empty="No matching party found"
                    >
                        <option value="">Select <?php echo e(strtolower($partyLabel)); ?></option>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $parties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $party): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                            <option
                                value="<?php echo e($party->id); ?>"
                                data-title="<?php echo e($party->name); ?>"
                                data-meta="<?php echo e($party->code); ?>"
                                data-status="<?php echo e($partyTypeLabels[$party->type] ?? $party->type); ?>"
                                data-search-keywords="<?php echo e($party->type); ?> <?php echo e($partyTypeLabels[$party->type] ?? $party->type); ?>"
                                data-party-type="<?php echo e($party->type); ?>"
                                <?php if((string) old('party_id', $isEditing ? $transaction->party_id : ($dueSettlementContext['party_id'] ?? '')) === (string) $party->id): echo 'selected'; endif; ?>
                            ><?php echo e($party->code); ?> — <?php echo e($party->name); ?> (<?php echo e($partyTypeLabels[$party->type] ?? $party->type); ?>)</option>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                    </select>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['party_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small class="hg-field-error"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </div>

                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                <div class="hg-field hidden" id="auto-party-notice" aria-live="polite">
                    <div class="hg-notice" style="margin:0">
                        <strong id="auto-party-label">Party selected automatically</strong>
                        <div class="hg-muted" id="auto-party-name"></div>
                    </div>
                </div>

                <div class="hg-field">
                    <label for="reference">Reference</label>
                    <input id="reference" name="reference" value="<?php echo e(old('reference', $isEditing ? $transaction->reference : '')); ?>" placeholder="Invoice, bill or receipt number">
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['reference'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small class="hg-field-error"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </div>

                <div class="hg-field full">
                    <label for="description">Description</label>
                    <textarea id="description" name="description" placeholder="Short business description"><?php echo e(old('description', $isEditing ? $transaction->description : ($isDueSettlement ? ((($dueSettlementContext['due_type'] ?? '') === 'Receivable' ? 'Customer due collected from ' : 'Supplier due paid to ').($dueSettlementContext['party_label'] ?? '')) : ''))); ?></textarea>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small class="hg-field-error"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </div>

                <div class="hg-field full hg-transaction-attachment-field">
                    <label>Attachment</label>
                    <div class="hg-attachment-box hg-attachment-desktop">
                        <div>
                            <strong>Upload receipt or reference file</strong>
                            <small>Images, PDF, Word, Excel, CSV or text files. Maximum 10 MB each.</small>
                        </div>
                        <label class="hg-btn hg-btn-small" for="transaction_attachments_desktop">Choose Files</label>
                        <input
                            id="transaction_attachments_desktop"
                            class="hg-file-input"
                            type="file"
                            name="transaction_attachments[]"
                            multiple
                            accept=".jpg,.jpeg,.png,.webp,.pdf,.doc,.docx,.xls,.xlsx,.csv,.txt,image/*,application/pdf"
                            data-attachment-input
                        >
                    </div>

                    <div class="hg-attachment-box hg-attachment-mobile" data-camera-widget>
                        <div class="hg-attachment-camera-copy">
                            <strong>Take receipt photo</strong>
                            <small>On phone or tablet this section opens the camera directly. The normal file-upload option stays hidden on mobile/tablet.</small>
                        </div>

                        <div class="hg-camera-actions">
                            <button class="hg-btn hg-btn-small hg-btn-camera-primary" type="button" data-camera-start>Open Camera</button>
                            <label class="hg-btn hg-btn-small hg-btn-soft hg-camera-fallback" for="transaction_attachments_mobile" data-camera-fallback hidden>Choose from Gallery</label>
                        </div>

                        <input
                            id="transaction_attachments_mobile"
                            class="hg-file-input"
                            type="file"
                            name="transaction_attachments[]"
                            accept="image/*"
                            capture="environment"
                            data-attachment-input
                            data-camera-file-input
                        >

                        <div class="hg-camera-panel" data-camera-panel hidden>
                            <video class="hg-camera-video" data-camera-video playsinline autoplay muted></video>
                            <canvas data-camera-canvas hidden></canvas>
                            <div class="hg-camera-preview" data-camera-preview hidden></div>
                            <div class="hg-camera-controls">
                                <button class="hg-btn hg-btn-small" type="button" data-camera-capture>Use This Photo</button>
                                <button class="hg-btn hg-btn-small hg-btn-soft" type="button" data-camera-retake hidden>Retake</button>
                                <button class="hg-btn hg-btn-small hg-btn-danger" type="button" data-camera-close>Close Camera</button>
                            </div>
                        </div>

                        <div class="hg-camera-message" data-camera-message hidden></div>
                    </div>

                    <div class="hg-attachment-selected" data-attachment-selected hidden></div>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['transaction_attachments'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small class="hg-field-error"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['transaction_attachments.*'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small class="hg-field-error"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($isEditing && $transaction->attachments->isNotEmpty()): ?>
                        <div class="hg-existing-attachments">
                            <strong>Existing attachments</strong>
                            <div class="hg-attachment-list">
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $transaction->attachments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attachment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                                    <div class="hg-attachment-pill">
                                        <a href="<?php echo e(route('transactions.attachments.show', [$transaction, $attachment])); ?>" target="_blank" rel="noopener">
                                            <?php echo e($attachment->display_name); ?>

                                        </a>
                                        <span><?php echo e(number_format(($attachment->size_bytes ?: 0) / 1024, 1)); ?> KB</span>
                                        <form method="POST" action="<?php echo e(route('transactions.attachments.destroy', [$transaction, $attachment])); ?>">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="hg-btn-link-danger">Remove</button>
                                        </form>
                                    </div>
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                            </div>
                        </div>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </div>


                <div class="hg-field full">
                    <?php if (isset($component)) { $__componentOriginald1c7f7635d3820a6bc93cf377c2420f2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald1c7f7635d3820a6bc93cf377c2420f2 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.accounting.form-actions','data' => ['submitLabel' => $isDueSettlement ? (($dueSettlementContext['due_type'] ?? '') === 'Receivable' ? 'Post Collection' : 'Post Payment') : ($isEditing ? 'Update Transaction' : 'Post Transaction')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('accounting.form-actions'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['submit-label' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($isDueSettlement ? (($dueSettlementContext['due_type'] ?? '') === 'Receivable' ? 'Post Collection' : 'Post Payment') : ($isEditing ? 'Update Transaction' : 'Post Transaction'))]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

                        <button type="button" class="hg-btn" data-draft-clear data-draft-clear-url="<?php echo e($isDueSettlement ? route('reports.due-management', ['as_of_date' => $dueSettlementContext['as_of_date'] ?? null, 'due_type' => strtolower((string) ($dueSettlementContext['due_type'] ?? 'all'))]) : route('transactions.create', ['category' => $category, 'backdated' => $backdatedEntryRequested ? 1 : null])); ?>">Clear</button>
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald1c7f7635d3820a6bc93cf377c2420f2)): ?>
<?php $attributes = $__attributesOriginald1c7f7635d3820a6bc93cf377c2420f2; ?>
<?php unset($__attributesOriginald1c7f7635d3820a6bc93cf377c2420f2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald1c7f7635d3820a6bc93cf377c2420f2)): ?>
<?php $component = $__componentOriginald1c7f7635d3820a6bc93cf377c2420f2; ?>
<?php unset($__componentOriginald1c7f7635d3820a6bc93cf377c2420f2); ?>
<?php endif; ?>
                </div>
            </form>
        </section>

        <section class="hg-card">
            <h2 class="hg-card-title">Transaction Summary</h2>
            <div id="journal-preview" data-preview-url="<?php echo e(route('transactions.preview')); ?>"><?php echo $__env->make('transactions.partials.preview-empty', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?></div>
        </section>
    </div>

    <template id="journal-preview-empty-template"><?php echo $__env->make('transactions.partials.preview-empty', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?></template>
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($isSalesTransaction && ! $isDueSettlement): ?>
        <?php $__env->startPush('scripts'); ?>
            <script>
                window.HISEBGHOR_TRANSACTION_SALE = {
                    currencyCode: <?php echo json_encode(\App\Support\CompanyContext::currencyCode(), 15, 512) ?>,
                    decimalPlaces: <?php echo e(\App\Support\CompanyContext::decimalPlaces()); ?>,
                    items: <?php echo json_encode($saleFeedItemsForJs, 15, 512) ?>,
                    initialLines: <?php echo json_encode(array_values($saleInitialLines), 15, 512) ?>,
                    stock: <?php echo json_encode($saleStockBalances, 15, 512) ?>,
                };
            </script>
        <?php $__env->stopPush(); ?>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9bfc79a588c44096104b78e73dee62a6)): ?>
<?php $attributes = $__attributesOriginal9bfc79a588c44096104b78e73dee62a6; ?>
<?php unset($__attributesOriginal9bfc79a588c44096104b78e73dee62a6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9bfc79a588c44096104b78e73dee62a6)): ?>
<?php $component = $__componentOriginal9bfc79a588c44096104b78e73dee62a6; ?>
<?php unset($__componentOriginal9bfc79a588c44096104b78e73dee62a6); ?>
<?php endif; ?>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel/hisebghor/resources/views/transactions/create.blade.php ENDPATH**/ ?>