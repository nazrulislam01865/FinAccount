<div class="section-title">
  <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(!empty($mini)): ?>
    <div class="mini" data-bn="<?php echo e($txt($mini, 'bn')); ?>" data-en="<?php echo e($txt($mini, 'en')); ?>"><?php echo e($txt($mini, $defaultLang)); ?></div>
  <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
  <h2 data-bn="<?php echo e($txt($title ?? '', 'bn')); ?>" data-en="<?php echo e($txt($title ?? '', 'en')); ?>"><?php echo e($txt($title ?? '', $defaultLang)); ?></h2>
  <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(!empty($subtitle)): ?>
    <p data-bn="<?php echo e($txt($subtitle, 'bn')); ?>" data-en="<?php echo e($txt($subtitle, 'en')); ?>"><?php echo e($txt($subtitle, $defaultLang)); ?></p>
  <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
</div>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel/hisebghor/resources/views/landing/components/section-title.blade.php ENDPATH**/ ?>