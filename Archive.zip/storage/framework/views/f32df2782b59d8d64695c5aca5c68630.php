<?php
    $defaultTransactionHeadId = old('transaction_head_id', $settings->purchase_transaction_head_id ?: $transactionHeads->first()?->id);
    $defaultTransactionHead = $transactionHeads->firstWhere('id', (int) $defaultTransactionHeadId) ?: $transactionHeads->first();
    $defaultPostingAccountName = $defaultTransactionHead?->postingAccount?->name ?? 'Account not configured';
    $defaultWarehouseId = old('tracking_unit_id', $settings->default_tracking_unit_id ?: $warehouses->first()?->id);
    $initialLines = old('lines', [[
        'item_id' => $items->first()?->id,
        'unit' => 'BAG',
        'quantity' => 1,
        'rate' => $items->first()?->default_purchase_price ?? 0,
        'batch_no' => '',
        'expiry_date' => '',
    ]]);
    $initialPayments = old('payments');
    if (! is_array($initialPayments) || $initialPayments === []) {
        $initialPayments = [[
            'money_account_id' => old('money_account_id', ''),
            'amount' => old('paid_amount', ''),
        ]];
    }

    $feedItemsForJs = $items->map(static fn ($item): array => [
        'id' => $item->id,
        'code' => $item->code,
        'name' => $item->name,
        'category' => $item->category,
        'brand' => $item->brand,
        'packSize' => (float) $item->pack_size,
        'purchasePrice' => (float) $item->default_purchase_price,
        'salePrice' => (float) $item->default_sale_price,
        'trackBatch' => (bool) $item->track_batch,
        'trackExpiry' => (bool) $item->track_expiry,
    ])->values();
    $moneyAccountsForJs = $moneyAccounts->map(fn ($account): array => [
        'id' => $account->id,
        'name' => $account->name,
        'kind' => $moneyKindLabels[$account->kind] ?? $account->kind,
        'accountCode' => $account->chartOfAccount?->code,
        'accountName' => $account->chartOfAccount?->name,
        'meta' => trim(($account->chartOfAccount?->code ? $account->chartOfAccount->code.' — ' : '').$account->name),
    ])->values();
?>

<?php if (isset($component)) { $__componentOriginal9bfc79a588c44096104b78e73dee62a6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9bfc79a588c44096104b78e73dee62a6 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'f4ac99e09542ff494432bc959d4fee61::accounting','data' => ['title' => 'Feed Purchase']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layouts::accounting'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Feed Purchase']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

    <div class="feed-ui" data-feed-form="purchase">
        <div class="feed-page-heading">
            <div>
                <h1>Record Feed Purchase</h1>
                <p>Record supplier purchase, update feed stock, and create the accounting journal automatically.</p>
            </div>
            <div class="feed-heading-actions">
                <a class="feed-btn" href="<?php echo e(route('transactions.index', ['category' => \App\Support\TransactionTypes::PURCHASE])); ?>">Purchase Register</a>
                <a class="feed-btn" href="<?php echo e(route('feed.inventory.index')); ?>">View Stock Ledger</a>
            </div>
        </div>

        <?php echo $__env->make('feed.partials.tabs', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        <div class="feed-layout-2">
            <section class="feed-card">
                <div class="feed-card-header">
                    <div>
                        <div class="feed-card-title">Purchase Details</div>
                        <div class="feed-card-sub">Fields marked with * are required.</div>
                    </div>
                    <span class="feed-status feed-status-blue">Direct Ledger Posting</span>
                </div>

                <form class="feed-card-body" method="POST" action="<?php echo e(route('feed.purchases.store')); ?>" enctype="multipart/form-data" data-feed-post-form>
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="request_token" value="<?php echo e($requestToken); ?>">

                    <div class="feed-grid-1">
                        <div class="feed-field">
                            <label for="transaction_head_id">Transaction Head <span class="feed-req">*</span></label>
                            <select class="feed-control" id="transaction_head_id" name="transaction_head_id" required data-feed-transaction-head data-hg-searchable-ignore>
                                <option value="">Select transaction head</option>
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $transactionHeads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $head): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                                    <option value="<?php echo e($head->id); ?>" <?php if((string) $defaultTransactionHeadId === (string) $head->id): echo 'selected'; endif; ?> data-account-name="<?php echo e($head->postingAccount?->name); ?>" data-account-code="<?php echo e($head->postingAccount?->code); ?>"><?php echo e($head->code); ?> — <?php echo e($head->name); ?> <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($head->postingAccount): ?> (<?php echo e($head->postingAccount->code); ?> — <?php echo e($head->postingAccount->name); ?>) <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?></option>
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                            </select>
                            <div class="feed-help">This head decides the accounting rule and inventory account for this feed purchase.</div>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($transactionHeads->isEmpty()): ?><div class="feed-warning-text">Add an active Purchase transaction head linked with a level-3 Asset account before posting.</div><?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </div>
                        <?php if (isset($component)) { $__componentOriginal33184e926771d74b634dc9f72a6b4f10 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal33184e926771d74b634dc9f72a6b4f10 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.accounting.backdated-date-field','data' => ['context' => $transactionDateContext,'value' => $transactionDateContext['default'],'variant' => 'feed','backdated' => request()->boolean('backdated')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('accounting.backdated-date-field'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['context' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($transactionDateContext),'value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($transactionDateContext['default']),'variant' => 'feed','backdated' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(request()->boolean('backdated'))]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal33184e926771d74b634dc9f72a6b4f10)): ?>
<?php $attributes = $__attributesOriginal33184e926771d74b634dc9f72a6b4f10; ?>
<?php unset($__attributesOriginal33184e926771d74b634dc9f72a6b4f10); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal33184e926771d74b634dc9f72a6b4f10)): ?>
<?php $component = $__componentOriginal33184e926771d74b634dc9f72a6b4f10; ?>
<?php unset($__componentOriginal33184e926771d74b634dc9f72a6b4f10); ?>
<?php endif; ?>
                        <div class="feed-field">
                            <label for="party_id">Supplier <span class="feed-req">*</span></label>
                            <select class="feed-control" id="party_id" name="party_id" required data-hg-searchable-ignore>
                                <option value="">Select supplier</option>
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $suppliers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $supplier): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                                    <option value="<?php echo e($supplier->id); ?>" <?php if((string) old('party_id') === (string) $supplier->id): echo 'selected'; endif; ?> data-title="<?php echo e($supplier->name); ?>" data-meta="<?php echo e($supplier->code); ?>"><?php echo e($supplier->code); ?> — <?php echo e($supplier->name); ?></option>
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                            </select>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($suppliers->isEmpty()): ?><div class="feed-warning-text">Add an active Supplier in Parties before posting.</div><?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </div>
                        <div class="feed-field">
                            <label for="tracking_unit_id">Warehouse <span class="feed-req">*</span></label>
                            <select class="feed-control" id="tracking_unit_id" name="tracking_unit_id" required data-feed-warehouse data-hg-searchable-ignore>
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $warehouses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $warehouse): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                                    <option value="<?php echo e($warehouse->id); ?>" <?php if((string) $defaultWarehouseId === (string) $warehouse->id): echo 'selected'; endif; ?>><?php echo e($warehouse->code); ?> — <?php echo e($warehouse->name); ?></option>
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                            </select>
                        </div>
                    </div>



                    <div class="feed-divider"></div>
                    <div class="feed-section-title">Feed Items</div>
                    <div class="feed-table-wrap">
                        <table class="feed-table feed-lines-table">
                            <thead>
                                <tr>
                                    <th style="width:30%">Feed Item</th>
                                    <th>Unit</th>
                                    <th>Quantity</th>
                                    <th>Rate (<?php echo e(\App\Support\CompanyContext::currencyCode()); ?>)</th>
                                    <th>Line Total</th>
                                    <th>Batch / Expiry</th>
                                    <th></th>
                                </tr>
                            </thead>
                            <tbody data-feed-lines></tbody>
                        </table>
                    </div>
                    <div class="feed-line-actions">
                        <button class="feed-btn feed-btn-soft feed-btn-sm" type="button" data-feed-add-line>＋ Add Another Item</button>
                        <div class="feed-inline-note">Stock is increased only after the transaction and journal are posted successfully.</div>
                    </div>

                    <div class="feed-divider"></div>
                    <div class="feed-grid-2">
                        <div class="feed-field">
                            <label for="overall_discount">Overall Commission (%)</label>
                            <input class="feed-control" id="overall_discount" name="overall_discount" type="text" inputmode="decimal" value="<?php echo e(old('overall_discount', 0)); ?>" placeholder="0 or 0%" data-feed-money-input>
                            <div class="feed-help">Enter percentage with or without %. It is calculated from items subtotal.</div>
                        </div>
                        <div class="feed-field">
                            <label for="commission_amount_purchase">Commission Amount (<?php echo e(\App\Support\CompanyContext::currencyCode()); ?>)</label>
                            <input class="feed-control feed-readonly" id="commission_amount_purchase" data-feed-commission-output readonly>
                        </div>
                    </div>
                    <div class="feed-grid-1">
                        <div class="feed-field">
                            <label for="transport_cost">Transportation Cost <span class="feed-negative">(-)</span></label>
                            <input class="feed-control" id="transport_cost" name="transport_cost" type="number" min="0" step="<?php echo e(\App\Support\CompanyContext::amountStep()); ?>" value="<?php echo e(old('transport_cost', 0)); ?>" data-feed-money-input>
                            <div class="feed-help">This amount is deducted from the purchase total.</div>
                        </div>
                        <div class="feed-field">
                            <label for="other_cost">Other Cost</label>
                            <input class="feed-control" id="other_cost" name="other_cost" type="number" min="0" step="<?php echo e(\App\Support\CompanyContext::amountStep()); ?>" value="<?php echo e(old('other_cost', 0)); ?>" data-feed-money-input>
                        </div>
                        <div class="feed-field">
                            <label for="calculated_total_cost">Total Purchase</label>
                            <input class="feed-control feed-readonly" id="calculated_total_cost" data-feed-calculated-total readonly>
                        </div>
                    </div>

                    <div class="feed-divider"></div>
                    <input id="paid_amount" name="paid_amount" type="hidden" value="<?php echo e(old('paid_amount', 0)); ?>">
                    <input id="money_account_id" name="money_account_id" type="hidden" value="<?php echo e(old('money_account_id')); ?>">
                    <div class="feed-payment-panel">
                        <div class="feed-payment-table">
                            <div class="feed-payment-table-head">
                                <span>Payment Account</span>
                                <span>Reference</span>
                                <span>Amount</span>
                                <span></span>
                            </div>
                            <div class="feed-payment-list" data-feed-payments>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = array_values($initialPayments); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $paymentIndex => $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                                <?php
                                    $selectedMoneyAccountId = data_get($payment, 'money_account_id', '');
                                    $selectedMoneyAccount = $moneyAccounts->firstWhere('id', (int) $selectedMoneyAccountId);
                                    $selectedMoneyAccountMeta = $selectedMoneyAccount
                                        ? trim(($selectedMoneyAccount->chartOfAccount?->code ? $selectedMoneyAccount->chartOfAccount->code.' — ' : '').$selectedMoneyAccount->name)
                                        : '';
                                ?>
                                <div class="feed-payment-row" data-feed-payment-row>
                                    <div class="feed-field">
                                        <label>Payment Account</label>
                                        <select name="payments[<?php echo e($paymentIndex); ?>][money_account_id]" data-feed-payment-account data-hg-searchable-ignore>
                                            <option value="">Select payment account</option>
                                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $moneyAccounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $moneyAccount): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                                                <option value="<?php echo e($moneyAccount->id); ?>" <?php if((string) $moneyAccount->id === (string) $selectedMoneyAccountId): echo 'selected'; endif; ?>>
                                                    <?php echo e($moneyAccount->name); ?> — <?php echo e($moneyKindLabels[$moneyAccount->kind] ?? $moneyAccount->kind); ?>

                                                </option>
                                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                                        </select>
                                        <small data-feed-payment-account-meta><?php echo e($selectedMoneyAccountMeta); ?></small>
                                    </div>
                                    <div class="feed-field">
                                        <label>Reference</label>
                                        <input name="payments[<?php echo e($paymentIndex); ?>][reference]" data-feed-payment-reference maxlength="100" value="<?php echo e(data_get($payment, 'reference', '')); ?>" placeholder="CHQ / TXN / note">
                                    </div>
                                    <div class="feed-field">
                                        <label>Amount (<?php echo e(\App\Support\CompanyContext::currencyCode()); ?>)</label>
                                        <input name="payments[<?php echo e($paymentIndex); ?>][amount]" data-feed-payment-amount type="number" min="0" step="<?php echo e(\App\Support\CompanyContext::amountStep()); ?>" value="<?php echo e(data_get($payment, 'amount', '')); ?>" placeholder="0.00">
                                    </div>
                                    <button class="feed-icon-btn" type="button" data-feed-remove-payment aria-label="Remove payment method">×</button>
                                </div>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                            </div>
                        </div>
                        <div class="feed-payment-footer">
                            <button class="feed-payment-add-row" type="button" data-feed-add-payment>＋ Add another bank/cash/mobile row</button>
                            <span>Total paid can be full, partial, or zero due.</span>
                        </div>
                        <div class="feed-payment-total"><span>Total paid now</span><strong data-feed-payment-total><?php echo e(\App\Support\CompanyContext::money(0)); ?></strong></div>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($errors->has('payments') || $errors->has('payments.*.money_account_id') || $errors->has('payments.*.amount')): ?>
                            <div class="feed-warning-text"><?php echo e($errors->first('payments') ?: ($errors->first('payments.*.money_account_id') ?: $errors->first('payments.*.amount'))); ?></div>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['paid_amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="feed-warning-text"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['money_account_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="feed-warning-text"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </div>
                    <div class="feed-grid-1 feed-section-gap">
                        <div class="feed-field">
                            <label for="description">Description</label>
                            <textarea class="feed-control" id="description" name="description" placeholder="Purchase purpose or note"><?php echo e(old('description')); ?></textarea>
                        </div>
                    </div>

                    <div class="feed-grid-1 feed-section-gap">
                        <div class="feed-field">
                            <label for="transaction_attachments">Attachment</label>
                            <div class="feed-upload">
                                <div><strong>Upload invoice or challan</strong><div class="feed-help">Images, PDF, Word or Excel; maximum 10 MB each.</div></div>
                                <input id="transaction_attachments" type="file" name="transaction_attachments[]" multiple accept=".jpg,.jpeg,.png,.webp,.pdf,.doc,.docx,.xls,.xlsx,.csv,.txt,image/*,application/pdf">
                            </div>
                        </div>
                        <div class="feed-info-banner feed-info-blue">
                            <strong>Posting behavior</strong><br>
                            The feed purchase posts directly to the accounting ledger: Debit Feed Inventory, then Credit the selected money account and/or Supplier Payable. Stock and journal posting succeed or fail together.
                        </div>
                    </div>

                    <div class="feed-action-bar">
                        <div class="feed-left-actions">
                            <a class="feed-btn" href="<?php echo e(route('feed.purchases.create')); ?>">Clear</a>
                        </div>
                        <div class="feed-right-actions">
                            <button class="feed-btn feed-btn-primary" type="submit" <?php if($suppliers->isEmpty() || $transactionHeads->isEmpty()): echo 'disabled'; endif; ?>>Post Purchase</button>
                        </div>
                    </div>
                </form>
            </section>

            <aside class="feed-card feed-summary-card">
                <div class="feed-card-header"><div class="feed-card-title">Transaction Summary</div></div>
                <div class="feed-card-body">
                    <div class="feed-info-banner">This purchase increases feed stock. The paid portion and supplier payable are calculated automatically.</div>

                    <div class="feed-summary-group">
                        <div class="feed-summary-label">Purchase Value</div>
                        <div class="feed-summary-row"><span>Items subtotal</span><b data-feed-summary="subtotal"><?php echo e(\App\Support\CompanyContext::money(0)); ?></b></div>
                        <div class="feed-summary-row"><span>Commission amount</span><b class="feed-negative" data-feed-summary="commission">(-) <?php echo e(\App\Support\CompanyContext::money(0)); ?></b></div>
                        <div class="feed-summary-row"><span>Transportation cost</span><b class="feed-negative" data-feed-summary="transport">(-) <?php echo e(\App\Support\CompanyContext::money(0)); ?></b></div>
                        <div class="feed-summary-row"><span>Other cost</span><b data-feed-summary="other"><?php echo e(\App\Support\CompanyContext::money(0)); ?></b></div>
                        <div class="feed-summary-row feed-grand"><span>Total purchase</span><b data-feed-summary="total"><?php echo e(\App\Support\CompanyContext::money(0)); ?></b></div>
                    </div>

                    <div class="feed-summary-group">
                        <div class="feed-summary-label">Payment Status</div>
                        <div class="feed-summary-row"><span>Paid now</span><b data-feed-summary="paid"><?php echo e(\App\Support\CompanyContext::money(0)); ?></b></div>
                        <div class="feed-summary-row"><span>Supplier payable</span><b data-feed-summary="due"><?php echo e(\App\Support\CompanyContext::money(0)); ?></b></div>
                        <div class="feed-summary-row"><span>Status</span><span class="feed-status feed-status-amber" data-feed-summary="status" data-feed-status>Fully due</span></div>
                    </div>

                    <div class="feed-summary-group">
                        <div class="feed-summary-label">Inventory Impact</div>
                        <div class="feed-summary-row"><span>Quantity added</span><b data-feed-summary="quantity">0.0000 KG</b></div>
                        <div class="feed-summary-row"><span>Valuation method</span><b>Weighted average</b></div>
                    </div>

                    <div class="feed-summary-group">
                        <div class="feed-summary-label">Journal Preview</div>
                        <div class="feed-journal">
                            <div class="feed-journal-row feed-journal-head"><span>Account</span><span>Debit</span><span>Credit</span></div>
                            <div class="feed-journal-row"><span data-feed-summary="posting-account"><?php echo e($defaultPostingAccountName); ?></span><span data-feed-summary="total"><?php echo e(\App\Support\CompanyContext::money(0)); ?></span><span></span></div>
                            <div data-feed-payment-journal></div>
                            <div class="feed-journal-row"><span>Supplier Payable</span><span></span><span data-feed-summary="due"><?php echo e(\App\Support\CompanyContext::money(0)); ?></span></div>
                        </div>
                    </div>
                </div>
            </aside>
        </div>
    </div>

    <?php
        $transactionHeadsForJs = $transactionHeads->map(function ($head) {
            return [
                'id' => $head->id,
                'name' => $head->name,
                'code' => $head->code,
                'accountName' => $head->postingAccount?->name,
                'accountCode' => $head->postingAccount?->code,
            ];
        })->values();
    ?>

    <?php $__env->startPush('scripts'); ?>
        <script>
            window.HISEBGHOR_FEED_PAGE = {
                type: 'purchase',
                currencyCode: <?php echo json_encode(\App\Support\CompanyContext::currencyCode(), 15, 512) ?>,
                decimalPlaces: <?php echo e(\App\Support\CompanyContext::decimalPlaces()); ?>,
                items: <?php echo json_encode($feedItemsForJs, 15, 512) ?>,
                initialLines: <?php echo json_encode(array_values($initialLines), 15, 512) ?>,
                moneyAccounts: <?php echo json_encode($moneyAccountsForJs, 15, 512) ?>,
                initialPayments: <?php echo json_encode(array_values($initialPayments), 15, 512) ?>,
                transactionHeads: <?php echo json_encode($transactionHeadsForJs, 15, 512) ?>,
                stock: {}
            };
        </script>
    <?php $__env->stopPush(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9bfc79a588c44096104b78e73dee62a6)): ?>
<?php $attributes = $__attributesOriginal9bfc79a588c44096104b78e73dee62a6; ?>
<?php unset($__attributesOriginal9bfc79a588c44096104b78e73dee62a6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9bfc79a588c44096104b78e73dee62a6)): ?>
<?php $component = $__componentOriginal9bfc79a588c44096104b78e73dee62a6; ?>
<?php unset($__componentOriginal9bfc79a588c44096104b78e73dee62a6); ?>
<?php endif; ?>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel/hisebghor/resources/views/feed/purchases/create.blade.php ENDPATH**/ ?>