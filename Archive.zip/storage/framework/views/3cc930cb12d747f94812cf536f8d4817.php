<?php if (isset($component)) { $__componentOriginal9bfc79a588c44096104b78e73dee62a6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9bfc79a588c44096104b78e73dee62a6 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'f4ac99e09542ff494432bc959d4fee61::accounting','data' => ['title' => 'Balance Sheet']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layouts::accounting'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Balance Sheet']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

    <?php
        $sectionGroups = $report['section_groups'];
        $assetSections = $sectionGroups->get('Asset', collect());
        $liabilitySections = $sectionGroups->get('Liability', collect());
        $equitySections = $sectionGroups->get('Equity', collect());
    ?>

    <div class="hg-report-page">
        <div class="hg-page-header hg-report-page-header">
            <div>
                <h1>Balance Sheet</h1>
                <p>Shows assets, liabilities, equity, and retained profit from posted journals up to the selected date.</p>
            </div>
        </div>

        <?php if (isset($component)) { $__componentOriginal74cc1c13d0f4b30c215f90a3e80a6e0f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal74cc1c13d0f4b30c215f90a3e80a6e0f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.reports.partials.filter-toolbar','data' => ['action' => route('reports.balance-sheet'),'exportUrl' => route('reports.balance-sheet', request()->query() + ['export' => 'csv'])]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('reports.partials.filter-toolbar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['action' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('reports.balance-sheet')),'export-url' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('reports.balance-sheet', request()->query() + ['export' => 'csv']))]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

            <label>
                <span>As of date</span>
                <input type="date" name="as_of_date" value="<?php echo e($report['as_of_date']); ?>">
            </label>
            <label>
                <span>Search account</span>
                <input type="search" name="search" value="<?php echo e(request('search')); ?>" placeholder="Code or account name">
            </label>
            <label class="hg-report-check">
                <input type="checkbox" name="include_zero_balances" value="1" <?php if($report['include_zero_balances']): echo 'checked'; endif; ?>>
                <span>Show zero balances</span>
            </label>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal74cc1c13d0f4b30c215f90a3e80a6e0f)): ?>
<?php $attributes = $__attributesOriginal74cc1c13d0f4b30c215f90a3e80a6e0f; ?>
<?php unset($__attributesOriginal74cc1c13d0f4b30c215f90a3e80a6e0f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal74cc1c13d0f4b30c215f90a3e80a6e0f)): ?>
<?php $component = $__componentOriginal74cc1c13d0f4b30c215f90a3e80a6e0f; ?>
<?php unset($__componentOriginal74cc1c13d0f4b30c215f90a3e80a6e0f); ?>
<?php endif; ?>

        <div class="hg-grid hg-grid-4 hg-report-summary">
            <section class="hg-card hg-metric"><span class="label">Total Assets</span><div class="value"><?php echo e(\App\Support\CompanyContext::money($report['assets'])); ?></div></section>
            <section class="hg-card hg-metric"><span class="label">Total Liabilities</span><div class="value"><?php echo e(\App\Support\CompanyContext::money($report['liabilities'])); ?></div></section>
            <section class="hg-card hg-metric"><span class="label">Equity + Profit</span><div class="value"><?php echo e(\App\Support\CompanyContext::money($report['equity'] + $report['retained_profit'])); ?></div></section>
            <section class="hg-card hg-metric"><span class="label">Difference</span><div class="value"><?php echo e(\App\Support\CompanyContext::money($report['difference'])); ?></div><small class="hint"><?php echo e($report['is_balanced'] ? 'Balanced' : 'Review setup/journals'); ?></small></section>
        </div>

        <div class="hg-grid hg-grid-2 hg-report-sections">
            <section class="hg-card">
                <h2 class="hg-card-title">Assets</h2>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $assetSections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section => $rows): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                    <h3 class="hg-report-subtitle"><?php echo e($section); ?></h3>
                    <?php echo $__env->make('reports.partials.financial-rows', ['rows' => $rows, 'amountKey' => 'balance'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    <div class="hg-report-line"><span>Total <?php echo e($section); ?></span><strong><?php echo e(\App\Support\CompanyContext::money($rows->sum('balance'))); ?></strong></div>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                    <div class="hg-empty">No asset records found.</div>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                <div class="hg-report-total"><span>Total Assets</span><strong><?php echo e(\App\Support\CompanyContext::money($report['assets'])); ?></strong></div>
            </section>

            <section class="hg-card">
                <h2 class="hg-card-title">Liabilities & Equity</h2>

                <h3 class="hg-report-subtitle">Liabilities</h3>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $liabilitySections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section => $rows): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                    <h4 class="hg-report-subtitle"><?php echo e($section); ?></h4>
                    <?php echo $__env->make('reports.partials.financial-rows', ['rows' => $rows, 'amountKey' => 'balance'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    <div class="hg-report-line"><span>Total <?php echo e($section); ?></span><strong><?php echo e(\App\Support\CompanyContext::money($rows->sum('balance'))); ?></strong></div>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                    <div class="hg-empty">No liability records found.</div>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                <div class="hg-report-total"><span>Total Liabilities</span><strong><?php echo e(\App\Support\CompanyContext::money($report['liabilities'])); ?></strong></div>

                <h3 class="hg-report-subtitle">Equity</h3>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $equitySections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section => $rows): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                    <h4 class="hg-report-subtitle"><?php echo e($section); ?></h4>
                    <?php echo $__env->make('reports.partials.financial-rows', ['rows' => $rows, 'amountKey' => 'balance'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    <div class="hg-report-line"><span>Total <?php echo e($section); ?></span><strong><?php echo e(\App\Support\CompanyContext::money($rows->sum('balance'))); ?></strong></div>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                    <div class="hg-empty">No equity records found.</div>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                <div class="hg-report-line"><span>Retained Profit / Loss</span><strong><?php echo e(\App\Support\CompanyContext::money($report['retained_profit'])); ?></strong></div>
                <div class="hg-report-total"><span>Total Liabilities + Equity</span><strong><?php echo e(\App\Support\CompanyContext::money($report['liabilities_and_equity'])); ?></strong></div>
            </section>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9bfc79a588c44096104b78e73dee62a6)): ?>
<?php $attributes = $__attributesOriginal9bfc79a588c44096104b78e73dee62a6; ?>
<?php unset($__attributesOriginal9bfc79a588c44096104b78e73dee62a6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9bfc79a588c44096104b78e73dee62a6)): ?>
<?php $component = $__componentOriginal9bfc79a588c44096104b78e73dee62a6; ?>
<?php unset($__componentOriginal9bfc79a588c44096104b78e73dee62a6); ?>
<?php endif; ?>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel/hisebghor/resources/views/reports/balance-sheet.blade.php ENDPATH**/ ?>