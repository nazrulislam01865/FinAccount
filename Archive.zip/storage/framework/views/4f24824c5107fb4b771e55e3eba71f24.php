<?php if (isset($component)) { $__componentOriginal9bfc79a588c44096104b78e73dee62a6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9bfc79a588c44096104b78e73dee62a6 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'f4ac99e09542ff494432bc959d4fee61::accounting','data' => ['title' => 'Statements']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layouts::accounting'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Statements']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

    <div class="hg-page-header">
        <div>
            <h1>Statements View</h1>
        </div>
    </div>

    <div class="hg-grid hg-grid-3">
        <section class="hg-card" id="income-statement">
            <h2 class="hg-card-title">Income Statement</h2>
            <div class="hg-kpi-row"><span>Income</span><strong><?php echo e(\App\Support\CompanyContext::money($statement['income'])); ?></strong></div>
            <div class="hg-kpi-row"><span>Expenses</span><strong><?php echo e(\App\Support\CompanyContext::money($statement['expense'])); ?></strong></div>
            <div class="hg-kpi-row"><span>Net Profit / Loss</span><strong><?php echo e(\App\Support\CompanyContext::money($statement['net'])); ?></strong></div>
            <p class="hg-report-note">Income and expenses come from COA type.</p>
        </section>

        <section class="hg-card" id="balance-sheet">
            <h2 class="hg-card-title">Balance Sheet</h2>
            <div class="hg-kpi-row"><span>Assets</span><strong><?php echo e(\App\Support\CompanyContext::money($statement['asset'])); ?></strong></div>
            <div class="hg-kpi-row"><span>Liabilities</span><strong><?php echo e(\App\Support\CompanyContext::money($statement['liability'])); ?></strong></div>
            <div class="hg-kpi-row"><span>Owner Equity</span><strong><?php echo e(\App\Support\CompanyContext::money($statement['equity_with_profit'])); ?></strong></div>
            <p class="hg-report-note">Net profit is added to equity for this simple view.</p>
        </section>

        <section class="hg-card" id="cash-flow-statement">
            <h2 class="hg-card-title">Cash Flow Statement</h2>
            <div class="hg-kpi-row"><span>Current Money Balance</span><strong><?php echo e(\App\Support\CompanyContext::money($statement['cash'])); ?></strong></div>
            <div class="hg-kpi-row"><span>Sales Collected</span><strong><?php echo e(\App\Support\CompanyContext::money($statement['sales_collected'])); ?></strong></div>
            <div class="hg-kpi-row"><span>Payments Made</span><strong><?php echo e(\App\Support\CompanyContext::money($statement['payments_made'])); ?></strong></div>
            <p class="hg-report-note">This is a simple cash flow view calculated from money-account movements.</p>
        </section>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9bfc79a588c44096104b78e73dee62a6)): ?>
<?php $attributes = $__attributesOriginal9bfc79a588c44096104b78e73dee62a6; ?>
<?php unset($__attributesOriginal9bfc79a588c44096104b78e73dee62a6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9bfc79a588c44096104b78e73dee62a6)): ?>
<?php $component = $__componentOriginal9bfc79a588c44096104b78e73dee62a6; ?>
<?php unset($__componentOriginal9bfc79a588c44096104b78e73dee62a6); ?>
<?php endif; ?>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel/hisebghor/resources/views/basic-statements/index.blade.php ENDPATH**/ ?>