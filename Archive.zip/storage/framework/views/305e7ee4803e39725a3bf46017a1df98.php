<?php
    $draftRows = \App\Support\VisibleFormDrafts::forBase('transactions');
    $visibleDraftRows = $search === '' && $category === '' && $transactions->currentPage() === 1
        ? $draftRows
        : collect();
    $canManageTransactions = auth()->user()?->canAccounting('transactions.manage') ?? false;
?>

<?php if (isset($component)) { $__componentOriginal9bfc79a588c44096104b78e73dee62a6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9bfc79a588c44096104b78e73dee62a6 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'f4ac99e09542ff494432bc959d4fee61::accounting','data' => ['title' => 'Transaction Register']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layouts::accounting'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Transaction Register']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

    <div class="hg-page-header">
        <div>
            <h1>Transaction Register</h1>
        </div>
        <div class="hg-actions">
            <a class="hg-btn" href="<?php echo e(route('transactions.export', array_filter(['search' => $search, 'category' => $category]))); ?>">Export CSV</a>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($canManageTransactions): ?>
                <a class="hg-btn" href="<?php echo e(route('transactions.create', ['backdated' => 1])); ?>">+ Backdated Entry</a>
                <a class="hg-btn hg-btn-primary" href="<?php echo e(route('transactions.create')); ?>">+ Add Transaction</a>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </div>
    </div>



    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(session('invoice_download_url')): ?>
        <div class="hg-notice hg-notice-success">
            Invoice download should start automatically.
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(session('invoice_show_url')): ?>
                <a href="<?php echo e(session('invoice_show_url')); ?>">Open invoice</a>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </div>
        <iframe src="<?php echo e(session('invoice_download_url')); ?>" style="display:none" title="Invoice download"></iframe>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(session('receipt_download_url')): ?>
        <div class="hg-notice hg-notice-success">
            Receipt download should start automatically.
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(session('receipt_show_url')): ?>
                <a href="<?php echo e(session('receipt_show_url')); ?>">Open receipt</a>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </div>
        <iframe src="<?php echo e(session('receipt_download_url')); ?>" style="display:none" title="Receipt download"></iframe>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

    <form method="GET" action="<?php echo e(route('transactions.index')); ?>" class="hg-toolbar" id="transaction-filter-form">
        <input
            class="hg-search"
            type="search"
            name="search"
            value="<?php echo e($search); ?>"
            placeholder="Search voucher, head, party or description..."
            aria-label="Search transactions"
        >

        <select name="category" class="hg-filter-select" aria-label="Filter transaction category" onchange="this.form.submit()">
            <option value="">All categories</option>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $transactionCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoryOption): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                <option value="<?php echo e($categoryOption->value); ?>" <?php if($category === $categoryOption->value): echo 'selected'; endif; ?>><?php echo e($categoryOption->label); ?></option>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
        </select>

        <button class="hg-btn hg-btn-primary" type="submit">Search</button>

        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($search !== '' || $category !== ''): ?>
            <a class="hg-btn" href="<?php echo e(route('transactions.index')); ?>">Clear</a>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    </form>

    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($transactions->isEmpty() && $visibleDraftRows->isEmpty()): ?>
        <div class="hg-empty">No records found.</div>
    <?php else: ?>
        <div class="hg-table-wrap">
            <table class="hg-table">
                <thead>
                    <tr>
                        <th>Voucher</th>
                        <th>Type</th>
                        <th>Head</th>
                        <th>Money</th>
                        <th>Party</th>
                        <th>Ref</th>
                        <th>Attachment</th>
                        <th class="right">Amount</th>
                        <th>Status</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                        <?php
                            $rowCategoryOption = $transactionCategories->firstWhere('value', $transaction->category);
                            $rowCategoryMetadata = is_array($rowCategoryOption?->metadata ?? null) ? $rowCategoryOption->metadata : [];
                            $isTransferRow = \App\Support\TransactionTypes::flow((string) $transaction->category, $rowCategoryMetadata) === \App\Support\TransactionTypes::FLOW_TRANSFER;
                        ?>
                        <tr>
                            <td>
                                <strong><?php echo e($transaction->voucher_no); ?></strong><br>
                                <span class="hg-muted"><?php echo e($transaction->transaction_date->format('Y-m-d')); ?></span>
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($transaction->created_at && $transaction->transaction_date->toDateString() < $transaction->created_at->toDateString()): ?>
                                    <br><span class="hg-badge hg-badge-backdated">Backdated</span>
                                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                            </td>
                            <td>
                                <span class="hg-badge <?php echo e(strtolower($transaction->category ?? '')); ?>">
                                    <?php echo e($transaction->category ? ($categoryLabels[$transaction->category] ?? $transaction->category) : 'Relationship removed'); ?>

                                </span>
                                <br><small class="hg-muted"><?php echo e($settlementLabels[$transaction->settlement_type] ?? $transaction->settlement_type); ?></small>
                            </td>
                            <td><?php echo e($transaction->displayHeadName($isTransferRow ? 'Money Transfer' : '-')); ?></td>
                            <td>
                                <?php echo e($transaction->moneyAccount?->name ?? '-'); ?>

                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($transaction->transferToMoneyAccount): ?>
                                    <br><small class="hg-muted">To: <?php echo e($transaction->transferToMoneyAccount?->name); ?></small>
                                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                            </td>
                            <td><?php echo e($transaction->party?->name ?? '-'); ?></td>
                            <td><?php echo e($transaction->reference ?: '-'); ?></td>
                            <td>
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($transaction->attachments->isNotEmpty()): ?>
                                    <div class="hg-attachment-list compact">
                                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $transaction->attachments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attachment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                                            <a class="hg-attachment-link" href="<?php echo e(route('transactions.attachments.show', [$transaction, $attachment])); ?>" target="_blank" rel="noopener">
                                                <?php echo e($attachment->is_image ? 'Image' : 'File'); ?> <?php echo e($loop->iteration); ?>

                                            </a>
                                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                                    </div>
                                <?php else: ?>
                                    <span class="hg-muted">-</span>
                                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                            </td>
                            <td class="right">
                                <?php echo e(\App\Support\CompanyContext::money((float) $transaction->amount)); ?>

                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(($transaction->settlement_type ?? \App\Support\TransactionTypes::CASH) === \App\Support\TransactionTypes::PARTIAL): ?>
                                    <br>
                                    <small class="hg-muted">
                                        Paid: <?php echo e(\App\Support\CompanyContext::money((float) $transaction->paid_amount)); ?><br>
                                        Initial due: <?php echo e(\App\Support\CompanyContext::money((float) $transaction->due_amount)); ?>

                                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($transaction->due_date): ?><br>Due date: <?php echo e($transaction->due_date->format('Y-m-d')); ?><?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                    </small>
                                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                            </td>
                            <td>
                                <span class="hg-badge <?php echo e($transaction->status === 'posted' ? 'on' : 'incomplete'); ?>"><?php echo e(ucfirst($transaction->status)); ?></span>
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($transaction->salesInvoice): ?>
                                    <br><small class="hg-muted">Invoice: <?php echo e(ucfirst($transaction->salesInvoice->status)); ?></small>
                                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($transaction->paymentReceipt): ?>
                                    <br><small class="hg-muted">Receipt: <?php echo e($transaction->paymentReceipt->receipt_no); ?></small>
                                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                            </td>
                            <td>
                                <div class="hg-actions">
                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($transaction->salesInvoice): ?>
                                        <a class="hg-btn hg-btn-small hg-btn-soft" href="<?php echo e(route('sales-invoices.show', $transaction->salesInvoice)); ?>">Invoice</a>
                                        <a class="hg-btn hg-btn-small" href="<?php echo e(route('sales-invoices.download', $transaction->salesInvoice)); ?>">Download</a>
                                    <?php elseif($canManageTransactions && in_array($transaction->category, [\App\Support\TransactionTypes::SALE, \App\Support\TransactionTypes::PURCHASE, \App\Support\TransactionTypes::ASSET_PURCHASE], true)): ?>
                                        <form method="POST" action="<?php echo e(route('transactions.invoice.generate', $transaction)); ?>">
                                            <?php echo csrf_field(); ?>
                                            <button class="hg-btn hg-btn-small hg-btn-soft" type="submit">Generate Invoice</button>
                                        </form>
                                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($transaction->paymentReceipt): ?>
                                        <a class="hg-btn hg-btn-small hg-btn-soft" href="<?php echo e(route('payment-receipts.show', $transaction->paymentReceipt)); ?>">Receipt</a>
                                        <a class="hg-btn hg-btn-small" href="<?php echo e(route('payment-receipts.download', $transaction->paymentReceipt)); ?>">Receipt PDF</a>
                                    <?php elseif($canManageTransactions && in_array($transaction->category, [\App\Support\TransactionTypes::CUSTOMER_COLLECTION, \App\Support\TransactionTypes::SUPPLIER_PAYMENT], true)): ?>
                                        <form method="POST" action="<?php echo e(route('transactions.receipt.generate', $transaction)); ?>">
                                            <?php echo csrf_field(); ?>
                                            <button class="hg-btn hg-btn-small hg-btn-soft" type="submit">Generate Receipt</button>
                                        </form>
                                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($canManageTransactions): ?>
                                        <a class="hg-btn hg-btn-small" data-draft-edit-key="transactions.edit.<?php echo e($transaction->id); ?>" href="<?php echo e(route('transactions.edit', $transaction)); ?>">Edit</a>
                                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($canManageTransactions && auth()->user()?->canDeleteAccountingRecords()): ?>
                                        <form method="POST" action="<?php echo e(route('transactions.destroy', $transaction)); ?>" data-safe-delete-form>
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button class="hg-btn hg-btn-small hg-btn-danger" type="submit">Delete</button>
                                        </form>
                                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(! $canManageTransactions): ?><span class="hg-muted">View only</span><?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                </div>
                            </td>
                        </tr>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>

                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $visibleDraftRows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $draft): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                        <?php
                            $fields = \App\Support\VisibleFormDrafts::fields($draft);
                            $isEditDraft = \App\Support\VisibleFormDrafts::isEdit($draft);
                            $draftRecordId = \App\Support\VisibleFormDrafts::recordId($draft);
                            $draftCategory = \App\Support\VisibleFormDrafts::transactionCategory($draft);
                        ?>
                        <tr class="hg-table-draft-row">
                            <td><strong>Draft</strong><br><span class="hg-muted"><?php echo e($fields['transaction_date'] ?? 'No date selected'); ?></span></td>
                            <td><span class="hg-badge <?php echo e(strtolower($draftCategory)); ?>"><?php echo e($categoryLabels[$draftCategory] ?? ($draftCategory ?: 'Draft')); ?></span></td>
                            <td><?php echo e(filled($fields['transaction_head_id'] ?? null) ? 'Head ID #'.$fields['transaction_head_id'] : (($fields['transfer_to_money_account_id'] ?? null) ? 'Money Transfer' : 'Not selected')); ?></td>
                            <td>
                                <?php echo e(filled($fields['money_account_id'] ?? null) ? 'Money ID #'.$fields['money_account_id'] : '-'); ?>

                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(filled($fields['transfer_to_money_account_id'] ?? null)): ?>
                                    <br><small class="hg-muted">To ID #<?php echo e($fields['transfer_to_money_account_id']); ?></small>
                                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                            </td>
                            <td><?php echo e(filled($fields['party_id'] ?? null) ? 'Party ID #'.$fields['party_id'] : '-'); ?></td>
                            <td><?php echo e($fields['reference'] ?? '-'); ?></td>
                            <td><span class="hg-muted">Attach after final save</span></td>
                            <td class="right">
                                <?php echo e(\App\Support\CompanyContext::money((float) ($fields['amount'] ?? 0))); ?>

                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(($fields['settlement_type'] ?? \App\Support\TransactionTypes::CASH) === \App\Support\TransactionTypes::PARTIAL): ?>
                                    <br><small class="hg-muted">Partial draft</small>
                                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                            </td>
                            <td><span class="hg-badge draft">Draft</span><br><small><?php echo e($draft->updated_at?->diffForHumans()); ?></small></td>
                            <td>
                                <div class="hg-actions">
                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($canManageTransactions): ?>
                                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($isEditDraft && $draftRecordId): ?>
                                            <a class="hg-btn hg-btn-small" href="<?php echo e(route('transactions.edit', ['transaction' => $draftRecordId])); ?>">Continue</a>
                                        <?php else: ?>
                                            <a class="hg-btn hg-btn-small" href="<?php echo e(route('transactions.create', array_filter(['category' => $draftCategory]))); ?>">Continue</a>
                                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                    <form method="POST" action="<?php echo e(route('accounting.form-drafts.destroy', $draft->draft_key)); ?>">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button class="hg-btn hg-btn-small hg-btn-danger" type="submit">Discard</button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                </tbody>
            </table>
        </div>

        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($transactions->hasPages()): ?>
            <div class="hg-page-header">
                <div class="hg-muted">
                    Showing <?php echo e($transactions->firstItem()); ?> to <?php echo e($transactions->lastItem()); ?> of <?php echo e($transactions->total()); ?> transactions
                </div>
                <?php echo e($transactions->onEachSide(1)->links()); ?>

            </div>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9bfc79a588c44096104b78e73dee62a6)): ?>
<?php $attributes = $__attributesOriginal9bfc79a588c44096104b78e73dee62a6; ?>
<?php unset($__attributesOriginal9bfc79a588c44096104b78e73dee62a6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9bfc79a588c44096104b78e73dee62a6)): ?>
<?php $component = $__componentOriginal9bfc79a588c44096104b78e73dee62a6; ?>
<?php unset($__componentOriginal9bfc79a588c44096104b78e73dee62a6); ?>
<?php endif; ?>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel/hisebghor/resources/views/transactions/index.blade.php ENDPATH**/ ?>