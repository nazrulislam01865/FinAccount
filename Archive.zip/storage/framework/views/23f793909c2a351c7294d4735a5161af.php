<section class="section audience-section" id="for">
  <div class="container">
    <div class="audience-heading">
      <div class="audience-heading-icon" aria-hidden="true"><?php echo e(data_get($landing, 'audience.icon', '🏪')); ?></div>
      <div>
        <h2 data-bn="<?php echo e($txt(data_get($landing, 'audience.title'), 'bn')); ?>" data-en="<?php echo e($txt(data_get($landing, 'audience.title'), 'en')); ?>"><?php echo e($txt(data_get($landing, 'audience.title'), $defaultLang)); ?></h2>
        <p data-bn="<?php echo e($txt(data_get($landing, 'audience.body'), 'bn')); ?>" data-en="<?php echo e($txt(data_get($landing, 'audience.body'), 'en')); ?>"><?php echo e($txt(data_get($landing, 'audience.body'), $defaultLang)); ?></p>
      </div>
    </div>

    <div class="audience-list">
      <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = data_get($landing, 'audiences', []); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $audience): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
        <article class="audience">
          <span class="audience-tick" aria-hidden="true">✓</span>
          <div class="audience-copy">
            <h3 data-bn="<?php echo e($txt(data_get($audience, 'title'), 'bn')); ?>" data-en="<?php echo e($txt(data_get($audience, 'title'), 'en')); ?>"><?php echo e($txt(data_get($audience, 'title'), $defaultLang)); ?></h3>
            <p data-bn="<?php echo e($txt(data_get($audience, 'body'), 'bn')); ?>" data-en="<?php echo e($txt(data_get($audience, 'body'), 'en')); ?>"><?php echo e($txt(data_get($audience, 'body'), $defaultLang)); ?></p>
          </div>
        </article>
      <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
    </div>
  </div>
</section>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel/hisebghor/resources/views/landing/components/audience.blade.php ENDPATH**/ ?>