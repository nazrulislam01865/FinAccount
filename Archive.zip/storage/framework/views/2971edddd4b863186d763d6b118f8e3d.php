<?php if (isset($component)) { $__componentOriginal9bfc79a588c44096104b78e73dee62a6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9bfc79a588c44096104b78e73dee62a6 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'f4ac99e09542ff494432bc959d4fee61::accounting','data' => ['title' => 'Income Statement']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layouts::accounting'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Income Statement']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

    <?php
        $sections = $report['sections'];
        $sectionRows = fn (string $section) => $sections->get($section, collect());
    ?>

    <div class="hg-report-page">
        <div class="hg-page-header hg-report-page-header">
            <div>
                <h1>Income Statement</h1>
                <p>Shows revenue, cost, expenses, and net profit from posted journals within the selected period.</p>
            </div>
        </div>

        <?php if (isset($component)) { $__componentOriginal74cc1c13d0f4b30c215f90a3e80a6e0f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal74cc1c13d0f4b30c215f90a3e80a6e0f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.reports.partials.filter-toolbar','data' => ['action' => route('reports.income-statement'),'exportUrl' => route('reports.income-statement', request()->query() + ['export' => 'csv'])]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('reports.partials.filter-toolbar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['action' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('reports.income-statement')),'export-url' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('reports.income-statement', request()->query() + ['export' => 'csv']))]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

            <label>
                <span>From date</span>
                <input type="date" name="from_date" value="<?php echo e($report['from_date']); ?>">
            </label>
            <label>
                <span>To date</span>
                <input type="date" name="to_date" value="<?php echo e($report['to_date']); ?>">
            </label>
            <label>
                <span>Search account</span>
                <input type="search" name="search" value="<?php echo e(request('search')); ?>" placeholder="Code or account name">
            </label>
            <label class="hg-report-check">
                <input type="checkbox" name="include_zero_balances" value="1" <?php if($report['include_zero_balances']): echo 'checked'; endif; ?>>
                <span>Show zero balances</span>
            </label>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal74cc1c13d0f4b30c215f90a3e80a6e0f)): ?>
<?php $attributes = $__attributesOriginal74cc1c13d0f4b30c215f90a3e80a6e0f; ?>
<?php unset($__attributesOriginal74cc1c13d0f4b30c215f90a3e80a6e0f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal74cc1c13d0f4b30c215f90a3e80a6e0f)): ?>
<?php $component = $__componentOriginal74cc1c13d0f4b30c215f90a3e80a6e0f; ?>
<?php unset($__componentOriginal74cc1c13d0f4b30c215f90a3e80a6e0f); ?>
<?php endif; ?>

        <div class="hg-grid hg-grid-4 hg-report-summary">
            <section class="hg-card hg-metric"><span class="label">Revenue</span><div class="value"><?php echo e(\App\Support\CompanyContext::money($report['revenue'])); ?></div></section>
            <section class="hg-card hg-metric"><span class="label">Gross Profit</span><div class="value"><?php echo e(\App\Support\CompanyContext::money($report['gross_profit'])); ?></div></section>
            <section class="hg-card hg-metric"><span class="label">Operating Profit</span><div class="value"><?php echo e(\App\Support\CompanyContext::money($report['operating_profit'])); ?></div></section>
            <section class="hg-card hg-metric"><span class="label">Net Profit / Loss</span><div class="value"><?php echo e(\App\Support\CompanyContext::money($report['net_profit'])); ?></div></section>
        </div>

        <div class="hg-grid hg-grid-2 hg-report-sections">
            <section class="hg-card">
                <h2 class="hg-card-title">Revenue</h2>
                <?php echo $__env->make('reports.partials.financial-rows', ['rows' => $sectionRows('Revenue'), 'amountKey' => 'amount'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                <div class="hg-report-total"><span>Total Revenue</span><strong><?php echo e(\App\Support\CompanyContext::money($report['revenue'])); ?></strong></div>

                <h3 class="hg-report-subtitle">Less: Cost of Sales</h3>
                <?php echo $__env->make('reports.partials.financial-rows', ['rows' => $sectionRows('Cost of Sales'), 'amountKey' => 'amount'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                <div class="hg-report-total"><span>Gross Profit</span><strong><?php echo e(\App\Support\CompanyContext::money($report['gross_profit'])); ?></strong></div>
            </section>

            <section class="hg-card">
                <h2 class="hg-card-title">Operating Expenses</h2>

                <h3 class="hg-report-subtitle">Operating Expense</h3>
                <?php echo $__env->make('reports.partials.financial-rows', ['rows' => $sectionRows('Operating Expense'), 'amountKey' => 'amount'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

                <h3 class="hg-report-subtitle">Administrative Expense</h3>
                <?php echo $__env->make('reports.partials.financial-rows', ['rows' => $sectionRows('Administrative Expense'), 'amountKey' => 'amount'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

                <h3 class="hg-report-subtitle">Selling Expense</h3>
                <?php echo $__env->make('reports.partials.financial-rows', ['rows' => $sectionRows('Selling Expense'), 'amountKey' => 'amount'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

                <div class="hg-report-total"><span>Total Operating Expenses</span><strong><?php echo e(\App\Support\CompanyContext::money($report['operating_expenses'])); ?></strong></div>
                <div class="hg-report-total"><span>Operating Profit</span><strong><?php echo e(\App\Support\CompanyContext::money($report['operating_profit'])); ?></strong></div>
            </section>
        </div>

        <div class="hg-grid hg-grid-2 hg-report-sections">
            <section class="hg-card">
                <h2 class="hg-card-title">Other Income</h2>
                <?php echo $__env->make('reports.partials.financial-rows', ['rows' => $sectionRows('Other Income'), 'amountKey' => 'amount'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                <div class="hg-report-total"><span>Total Other Income</span><strong><?php echo e(\App\Support\CompanyContext::money($report['other_income'])); ?></strong></div>
            </section>

            <section class="hg-card">
                <h2 class="hg-card-title">Other Expenses</h2>

                <h3 class="hg-report-subtitle">Financial Expense</h3>
                <?php echo $__env->make('reports.partials.financial-rows', ['rows' => $sectionRows('Financial Expense'), 'amountKey' => 'amount'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

                <h3 class="hg-report-subtitle">Tax Expense</h3>
                <?php echo $__env->make('reports.partials.financial-rows', ['rows' => $sectionRows('Tax Expense'), 'amountKey' => 'amount'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

                <div class="hg-report-total"><span>Net Profit Before Tax</span><strong><?php echo e(\App\Support\CompanyContext::money($report['net_profit_before_tax'])); ?></strong></div>
            </section>
        </div>

        <section class="hg-card hg-report-net-card">
            <div class="hg-report-total hg-report-total-large">
                <span>Net Profit / Loss</span>
                <strong><?php echo e(\App\Support\CompanyContext::money($report['net_profit'])); ?></strong>
            </div>
        </section>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9bfc79a588c44096104b78e73dee62a6)): ?>
<?php $attributes = $__attributesOriginal9bfc79a588c44096104b78e73dee62a6; ?>
<?php unset($__attributesOriginal9bfc79a588c44096104b78e73dee62a6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9bfc79a588c44096104b78e73dee62a6)): ?>
<?php $component = $__componentOriginal9bfc79a588c44096104b78e73dee62a6; ?>
<?php unset($__componentOriginal9bfc79a588c44096104b78e73dee62a6); ?>
<?php endif; ?>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel/hisebghor/resources/views/reports/income-statement.blade.php ENDPATH**/ ?>