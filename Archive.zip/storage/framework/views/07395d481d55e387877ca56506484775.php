<nav class="feed-module-nav" aria-label="Feed module navigation">
    <div class="feed-module-nav-inner">
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(auth()->user()?->canAccounting('transactions.manage')): ?>
            <a href="<?php echo e(route('feed.purchases.create')); ?>" class="<?php echo e(request()->routeIs('feed.purchases.*') ? 'active' : ''); ?>">🛒 Feed Purchase</a>
            <a href="<?php echo e(route('feed.sales.create')); ?>" class="<?php echo e(request()->routeIs('feed.sales.*') ? 'active' : ''); ?>">🧾 Feed Sale</a>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(auth()->user()?->canAccounting('transactions.view')): ?>
            <a href="<?php echo e(route('feed.inventory.index')); ?>" class="<?php echo e(request()->routeIs('feed.inventory.*') ? 'active' : ''); ?>">▦ Inventory</a>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(auth()->user()?->canAccounting('transactions.manage')): ?>
            <a href="<?php echo e(route('feed.setup.index')); ?>" class="<?php echo e(request()->routeIs('feed.setup.*') ? 'active' : ''); ?>">⚙ Feed Setup</a>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    </div>
</nav>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel/hisebghor/resources/views/feed/partials/tabs.blade.php ENDPATH**/ ?>