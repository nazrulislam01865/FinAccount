<?php if (isset($component)) { $__componentOriginal9bfc79a588c44096104b78e73dee62a6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9bfc79a588c44096104b78e73dee62a6 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'f4ac99e09542ff494432bc959d4fee61::accounting','data' => ['title' => 'Dashboard']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layouts::accounting'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Dashboard']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

     <?php $__env->slot('topbar', null, []); ?> 
        <div class="hg-topbar-title">Dashboard</div>
     <?php $__env->endSlot(); ?>

    <section class="hg-dashboard">
        <div class="hg-dashboard-hero">
            <div>
                <h1>Business Health Dashboard</h1>
            </div>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(auth()->user()?->canAccounting('transactions.manage')): ?>
            <div class="hg-dashboard-actions">
                <a class="hg-dashboard-btn blue" href="<?php echo e(route('transactions.create', ['category' => \App\Support\TransactionTypes::SALE])); ?>">+ New Sale</a>
                <a class="hg-dashboard-btn green" href="<?php echo e(route('transactions.create', ['category' => \App\Support\TransactionTypes::CUSTOMER_COLLECTION])); ?>">+ Receive Money</a>
                <a class="hg-dashboard-btn red" href="<?php echo e(route('transactions.create', ['category' => \App\Support\TransactionTypes::SUPPLIER_PAYMENT])); ?>">+ Make Payment</a>
                <a class="hg-dashboard-btn light" href="<?php echo e(route('transactions.create', ['category' => \App\Support\TransactionTypes::SALE])); ?>">Generate Invoice</a>
            </div>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </div>

        <div class="hg-dashboard-grid hg-dashboard-kpis">
            <article class="hg-dashboard-card hg-dashboard-kpi">
                <div class="hg-dashboard-kpi-title">
                    <span>Available Money</span>
                    <span class="hg-dashboard-kpi-icon soft-blue">💵</span>
                </div>
                <div class="hg-dashboard-value"><?php echo e(\App\Support\CompanyContext::money($metrics['available_money'])); ?></div>
                <div class="hg-dashboard-sub">Cash + Bank + digital account balance. <span class="hg-dashboard-up">Live</span></div>
            </article>

            <article class="hg-dashboard-card hg-dashboard-kpi">
                <div class="hg-dashboard-kpi-title">
                    <span>Sales — <?php echo e($periodLabel); ?></span>
                    <span class="hg-dashboard-kpi-icon soft-green">🛒</span>
                </div>
                <div class="hg-dashboard-value"><?php echo e(\App\Support\CompanyContext::money($metrics['sales'])); ?></div>
                <div class="hg-dashboard-sub">
                    Posted sales transactions.
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($metrics['sales_has_comparison']): ?>
                        <span class="<?php echo e($metrics['sales_change'] >= 0 ? 'hg-dashboard-up' : 'hg-dashboard-down'); ?>">
                            <?php echo e($metrics['sales_change'] >= 0 ? '+' : ''); ?><?php echo e(number_format($metrics['sales_change'], 1)); ?>%
                        </span>
                        vs previous period
                    <?php else: ?>
                        <span class="hg-dashboard-up">Current period</span>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </div>
            </article>

            <article class="hg-dashboard-card hg-dashboard-kpi">
                <div class="hg-dashboard-kpi-title">
                    <span>Net Profit Preview</span>
                    <span class="hg-dashboard-kpi-icon soft-purple">📈</span>
                </div>
                <div class="hg-dashboard-value"><?php echo e(\App\Support\CompanyContext::money($metrics['profit'])); ?></div>
                <div class="hg-dashboard-sub">Income minus expenses for <?php echo e(strtolower($periodLabel)); ?>. Before tax and adjustments.</div>
            </article>

            <article class="hg-dashboard-card hg-dashboard-kpi">
                <div class="hg-dashboard-kpi-title">
                    <span>Customer Due</span>
                    <span class="hg-dashboard-kpi-icon soft-amber">🤝</span>
                </div>
                <div class="hg-dashboard-value"><?php echo e(\App\Support\CompanyContext::money($metrics['customer_due'])); ?></div>
                <div class="hg-dashboard-sub">
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($receivableCount > 0): ?>
                        <span class="hg-dashboard-warn"><?php echo e($receivableCount); ?> account<?php echo e($receivableCount === 1 ? '' : 's'); ?> outstanding.</span> Follow-up needed.
                    <?php else: ?>
                        No positive customer balance is outstanding.
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </div>
            </article>

            <article class="hg-dashboard-card hg-dashboard-kpi">
                <div class="hg-dashboard-kpi-title">
                    <span>Payables + Loans</span>
                    <span class="hg-dashboard-kpi-icon soft-red">🏦</span>
                </div>
                <div class="hg-dashboard-value"><?php echo e(\App\Support\CompanyContext::money($metrics['payables_loans'])); ?></div>
                <div class="hg-dashboard-sub">
                    Supplier payable + lender balance.
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($metrics['payables_loans'] > $metrics['available_money']): ?>
                        <span class="hg-dashboard-down">Watch cash flow</span>
                    <?php else: ?>
                        <span class="hg-dashboard-up">Within available money</span>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </div>
            </article>
        </div>

        <div class="hg-dashboard-grid hg-dashboard-two-col">
            <section class="hg-dashboard-card hg-dashboard-section">
                <div class="hg-dashboard-section-head">
                    <h2>Today’s Accounting Position</h2>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(auth()->user()?->canAccounting('journals.view')): ?>
                    <a href="<?php echo e(route('journal-entries.index')); ?>">View ledger</a>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </div>
                <div class="hg-dashboard-grid hg-dashboard-three-col">
                    <div class="hg-dashboard-formula">
                        <strong>Cash position</strong><br>
                        Opening <?php echo e(\App\Support\CompanyContext::money($position['cash']['opening'])); ?>

                        + Received <?php echo e(\App\Support\CompanyContext::money($position['cash']['received'])); ?>

                        - Paid <?php echo e(\App\Support\CompanyContext::money($position['cash']['paid'])); ?>

                        = <strong><?php echo e(\App\Support\CompanyContext::money($position['cash']['closing'])); ?></strong>
                    </div>
                    <div class="hg-dashboard-formula">
                        <strong>Profit preview</strong><br>
                        Income <?php echo e(\App\Support\CompanyContext::money($position['profit']['income'])); ?>

                        - Expense <?php echo e(\App\Support\CompanyContext::money($position['profit']['expense'])); ?>

                        = <strong><?php echo e(\App\Support\CompanyContext::money($position['profit']['net'])); ?></strong>
                    </div>
                    <div class="hg-dashboard-formula">
                        <strong>Owner movement</strong><br>
                        Investment <?php echo e(\App\Support\CompanyContext::money($position['owner']['investment'])); ?>

                        - Withdrawal <?php echo e(\App\Support\CompanyContext::money($position['owner']['withdrawal'])); ?>

                        = <strong><?php echo e(\App\Support\CompanyContext::money($position['owner']['net'])); ?> net</strong>
                    </div>
                </div>
            </section>

            <section class="hg-dashboard-card hg-dashboard-section">
                <div class="hg-dashboard-section-head">
                    <h2>Quick Alerts</h2>
                    <span class="hg-dashboard-badge amber"><?php echo e($alerts->count()); ?> item<?php echo e($alerts->count() === 1 ? '' : 's'); ?></span>
                </div>
                <div class="hg-dashboard-todo">
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $alerts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $alert): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                        <div class="hg-dashboard-todo-item <?php echo e($alert['tone']); ?>">
                            <div class="hg-dashboard-check"><?php echo e($alert['icon']); ?></div>
                            <div>
                                <strong><?php echo e($alert['title']); ?></strong><br>
                                <span class="hg-dashboard-muted"><?php echo e($alert['detail']); ?></span>
                            </div>
                        </div>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                </div>
            </section>
        </div>

        <div class="hg-dashboard-grid hg-dashboard-two-col hg-dashboard-block">
            <section class="hg-dashboard-card hg-dashboard-section">
                <div class="hg-dashboard-section-head">
                    <h2>Recent Transactions</h2>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(auth()->user()?->canAccounting('transactions.view')): ?>
                    <a href="<?php echo e(route('transactions.index', ['period' => $period])); ?>">Open register</a>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </div>

                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($recentTransactions->isEmpty()): ?>
                    <div class="hg-dashboard-empty">No posted transactions were found for <?php echo e(strtolower($periodLabel)); ?>.</div>
                <?php else: ?>
                    <div class="hg-dashboard-table-wrap">
                        <table class="hg-dashboard-table">
                            <thead>
                            <tr>
                                <th>Voucher</th>
                                <th>Type</th>
                                <th>Details</th>
                                <th class="amount">Amount</th>
                                <th>Status</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $recentTransactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                                <?php
                                    $debitAccounts = $transaction->journalEntry?->lines
                                        ?->filter(fn ($line) => (float) $line->debit > 0)
                                        ->map(fn ($line) => $line->chartOfAccount?->name)
                                        ->filter()
                                        ->join(', ');
                                    $creditAccounts = $transaction->journalEntry?->lines
                                        ?->filter(fn ($line) => (float) $line->credit > 0)
                                        ->map(fn ($line) => $line->chartOfAccount?->name)
                                        ->filter()
                                        ->join(', ');
                                ?>
                                <tr>
                                    <td>
                                        <strong><?php echo e($transaction->voucher_no); ?></strong><br>
                                        <span class="hg-dashboard-muted"><?php echo e($transaction->transaction_date->format('d M')); ?></span>
                                    </td>
                                    <td><span class="hg-dashboard-badge <?php echo e(strtolower($transaction->category)); ?>"><?php echo e($categoryLabels[$transaction->category] ?? $transaction->category); ?></span></td>
                                    <td>
                                        <?php echo e($transaction->displayHeadName('—')); ?>

                                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($transaction->party): ?>
                                            — <?php echo e($transaction->party->name); ?>

                                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                        <br>
                                        <span class="hg-dashboard-muted">Dr <?php echo e($debitAccounts ?: '—'); ?>, Cr <?php echo e($creditAccounts ?: '—'); ?></span>
                                    </td>
                                    <td class="amount"><?php echo e(\App\Support\CompanyContext::money((float) $transaction->amount)); ?></td>
                                    <td><span class="hg-dashboard-badge blue"><?php echo e(ucfirst($transaction->status)); ?></span></td>
                                </tr>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </section>

            <section class="hg-dashboard-card hg-dashboard-section">
                <div class="hg-dashboard-section-head">
                    <h2>Money Accounts</h2>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(auth()->user()?->canAnyAccounting(['money_accounts.view', 'money_accounts.manage'])): ?>
                    <a href="<?php echo e(route('money-accounts.index', auth()->user()?->canAccounting('money_accounts.view') ? [] : ['action' => 'add'])); ?>"><?php echo e(auth()->user()?->canAccounting('money_accounts.manage') ? 'Update accounts' : 'View accounts'); ?></a>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </div>

                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($moneyAccounts->isEmpty()): ?>
                    <div class="hg-dashboard-empty">No active money account is mapped to a COA.</div>
                <?php else: ?>
                    <div class="hg-dashboard-cash-list">
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $moneyAccounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $moneyAccount): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                            <div class="hg-dashboard-cash-row">
                                <div>
                                    <strong><?php echo e($moneyAccount['name']); ?></strong><br>
                                    <span class="hg-dashboard-muted"><?php echo e($moneyAccount['description']); ?></span>
                                    <div class="hg-dashboard-progress">
                                        <div class="hg-dashboard-bar <?php echo e($moneyAccount['bar_tone']); ?>" style="width: <?php echo e(number_format($moneyAccount['progress'], 2, '.', '')); ?>%"></div>
                                    </div>
                                </div>
                                <strong><?php echo e(\App\Support\CompanyContext::money($moneyAccount['balance'])); ?></strong>
                            </div>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                    </div>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                <div class="hg-dashboard-divider"></div>
                <div class="hg-dashboard-notice"><strong>Accountant note:</strong> <?php echo e($accountantNote); ?></div>
            </section>
        </div>

        <div class="hg-dashboard-grid hg-dashboard-three-col hg-dashboard-block">
            <section class="hg-dashboard-card hg-dashboard-section">
                <div class="hg-dashboard-section-head">
                    <h2>Receivables</h2>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(auth()->user()?->canAccounting('balances.view')): ?>
                    <a href="<?php echo e(route('balances.index', ['section' => 'parties'])); ?>#party-balances">View parties</a>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </div>
                <div class="hg-dashboard-table-wrap">
                    <table class="hg-dashboard-table">
                        <thead><tr><th>Customer</th><th class="amount">Due</th><th>Status</th></tr></thead>
                        <tbody>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $receivables; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $receivable): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                            <tr>
                                <td><?php echo e($receivable['name']); ?></td>
                                <td class="amount"><?php echo e(\App\Support\CompanyContext::money($receivable['balance'])); ?></td>
                                <td><span class="hg-dashboard-badge <?php echo e($receivable['tone']); ?>"><?php echo e($receivable['status']); ?></span></td>
                            </tr>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                            <tr><td colspan="3" class="hg-dashboard-empty-cell">No customer due found.</td></tr>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </section>

            <section class="hg-dashboard-card hg-dashboard-section">
                <div class="hg-dashboard-section-head">
                    <h2>Payables</h2>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(auth()->user()?->canAccounting('balances.view')): ?>
                    <a href="<?php echo e(route('balances.index', ['section' => 'parties'])); ?>#party-balances">View parties</a>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </div>
                <div class="hg-dashboard-table-wrap">
                    <table class="hg-dashboard-table">
                        <thead><tr><th>Supplier / Lender</th><th class="amount">Balance</th><th>Status</th></tr></thead>
                        <tbody>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $payables; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payable): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                            <tr>
                                <td><?php echo e($payable['name']); ?></td>
                                <td class="amount"><?php echo e(\App\Support\CompanyContext::money($payable['balance'])); ?></td>
                                <td><span class="hg-dashboard-badge <?php echo e($payable['tone']); ?>"><?php echo e($payable['status']); ?></span></td>
                            </tr>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                            <tr><td colspan="3" class="hg-dashboard-empty-cell">No supplier or lender balance found.</td></tr>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </section>

            <section class="hg-dashboard-card hg-dashboard-section">
                <div class="hg-dashboard-section-head">
                    <h2>Invoice Status</h2>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(auth()->user()?->canAccounting('transactions.manage')): ?>
                    <a href="<?php echo e(route('transactions.create', ['category' => \App\Support\TransactionTypes::SALE])); ?>">Generate invoice</a>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </div>
                <div class="hg-dashboard-table-wrap">
                    <table class="hg-dashboard-table">
                        <thead><tr><th>Status</th><th class="amount">Count</th><th class="amount">Amount</th></tr></thead>
                        <tbody>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $invoiceStatus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                            <tr>
                                <td><span class="hg-dashboard-badge <?php echo e($status['tone']); ?>"><?php echo e($status['label']); ?></span></td>
                                <td class="amount"><?php echo e($status['count']); ?></td>
                                <td class="amount"><?php echo e(\App\Support\CompanyContext::money($status['amount'])); ?></td>
                            </tr>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </section>
        </div>

        <div class="hg-dashboard-grid hg-dashboard-two-col hg-dashboard-block">
            <section class="hg-dashboard-card hg-dashboard-section">
                <div class="hg-dashboard-section-head">
                    <h2>Sales vs Expenses Trend</h2>
                    <span class="hg-dashboard-muted">Last 6 months</span>
                </div>

                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($trend->isEmpty()): ?>
                    <div class="hg-dashboard-empty">No trend data is available.</div>
                <?php else: ?>
                    <div class="hg-dashboard-chart-legend">
                        <span><i class="sales"></i> Sales</span>
                        <span><i class="expense"></i> Expenses</span>
                    </div>
                    <div class="hg-dashboard-mini-chart" aria-label="Sales and expenses monthly chart">
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $trend; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $month): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                            <div class="hg-dashboard-month-bars">
                                <div class="hg-dashboard-mini-bar sales" style="height: <?php echo e(number_format($month['sales_height'], 2, '.', '')); ?>%" title="<?php echo e($month['label']); ?> sales: <?php echo e(\App\Support\CompanyContext::money($month['sales'])); ?>">
                                    <span><?php echo e(number_format($month['sales'] / 1000, 1)); ?>k</span>
                                </div>
                                <div class="hg-dashboard-mini-bar expense" style="height: <?php echo e(number_format($month['expense_height'], 2, '.', '')); ?>%" title="<?php echo e($month['label']); ?> expenses: <?php echo e(\App\Support\CompanyContext::money($month['expense'])); ?>">
                                    <span><?php echo e(number_format($month['expense'] / 1000, 1)); ?>k</span>
                                </div>
                            </div>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                    </div>
                    <div class="hg-dashboard-mini-labels">
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $trend; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $month): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                            <span><?php echo e($month['label']); ?></span>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                    </div>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </section>

            <section class="hg-dashboard-card hg-dashboard-section">
                <div class="hg-dashboard-section-head">
                    <h2>What I Need to Decide Today</h2>
                    <span class="hg-dashboard-badge blue">Owner view</span>
                </div>
                <div class="hg-dashboard-todo">
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $decisions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $decision): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                        <div class="hg-dashboard-todo-item">
                            <div class="hg-dashboard-check"><?php echo e($loop->iteration); ?></div>
                            <div>
                                <strong><?php echo e($decision['title']); ?></strong><br>
                                <span class="hg-dashboard-muted"><?php echo e($decision['detail']); ?></span>
                            </div>
                        </div>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                </div>
            </section>
        </div>

        <div class="hg-dashboard-grid hg-dashboard-two-col hg-dashboard-block">
            <section class="hg-dashboard-card hg-dashboard-section">
                <div class="hg-dashboard-section-head">
                    <h2>Financial Statement Snapshot</h2>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(auth()->user()?->canAccounting('statements.view')): ?>
                    <a href="<?php echo e(route('basic-statements.index', ['section' => 'income'])); ?>#income-statement">Open statements</a>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </div>
                <div class="hg-dashboard-table-wrap">
                    <table class="hg-dashboard-table">
                        <thead><tr><th>Statement Item</th><th class="amount">Amount</th><th>Meaning</th></tr></thead>
                        <tbody>
                        <tr><td>Revenue</td><td class="amount"><?php echo e(\App\Support\CompanyContext::money($statement['revenue'])); ?></td><td>Income posted in <?php echo e(strtolower($periodLabel)); ?></td></tr>
                        <tr><td>Total Expense</td><td class="amount"><?php echo e(\App\Support\CompanyContext::money($statement['expense'])); ?></td><td>Expenses posted in <?php echo e(strtolower($periodLabel)); ?></td></tr>
                        <tr><td>Net Profit</td><td class="amount"><?php echo e(\App\Support\CompanyContext::money($statement['net_profit'])); ?></td><td>Revenue minus expense</td></tr>
                        <tr><td>Total Assets</td><td class="amount"><?php echo e(\App\Support\CompanyContext::money($statement['assets'])); ?></td><td>Current account balances classified as assets</td></tr>
                        <tr><td>Total Liabilities</td><td class="amount"><?php echo e(\App\Support\CompanyContext::money($statement['liabilities'])); ?></td><td>Current supplier payable and loan balances</td></tr>
                        <tr><td>Owner Equity</td><td class="amount"><?php echo e(\App\Support\CompanyContext::money($statement['equity'])); ?></td><td>Capital plus accumulated profit minus drawings</td></tr>
                        </tbody>
                    </table>
                </div>
            </section>

            <section class="hg-dashboard-card hg-dashboard-section">
                <div class="hg-dashboard-section-head">
                    <h2>Dashboard Data Sources</h2>
                    <span class="hg-dashboard-badge green">Auto calculated</span>
                </div>
                <div class="hg-dashboard-formula"><strong>Sales cards</strong> come from posted sales transactions and income journals.</div>
                <div class="hg-dashboard-formula hg-dashboard-formula-gap"><strong>Money balance</strong> comes from journal lines posted to COA accounts linked with money accounts.</div>
                <div class="hg-dashboard-formula hg-dashboard-formula-gap"><strong>Customer and supplier balances</strong> come from party-linked receivable and payable journals.</div>
                <div class="hg-dashboard-formula hg-dashboard-formula-gap"><strong>Profit and balance sheet</strong> come from COA type: Asset, Liability, Income, Expense and Equity.</div>

                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(auth()->user()?->canAccounting('settings.manage')): ?>
                <form class="hg-dashboard-reset" method="POST" action="<?php echo e(route('dashboard.reset-demo')); ?>" onsubmit="return confirm('Reset all company accounting data to the sample dataset?')">
                    <?php echo csrf_field(); ?>
                    <button type="submit">Reset Sample Data</button>
                </form>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </section>
        </div>

    </section>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9bfc79a588c44096104b78e73dee62a6)): ?>
<?php $attributes = $__attributesOriginal9bfc79a588c44096104b78e73dee62a6; ?>
<?php unset($__attributesOriginal9bfc79a588c44096104b78e73dee62a6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9bfc79a588c44096104b78e73dee62a6)): ?>
<?php $component = $__componentOriginal9bfc79a588c44096104b78e73dee62a6; ?>
<?php unset($__componentOriginal9bfc79a588c44096104b78e73dee62a6); ?>
<?php endif; ?>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel/hisebghor/resources/views/dashboard/index.blade.php ENDPATH**/ ?>