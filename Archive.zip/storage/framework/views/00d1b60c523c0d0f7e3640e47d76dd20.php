<?php # [BlazeFolded]:{flux::toast}:{/Applications/XAMPP/xamppfiles/htdocs/laravel/hisebghor/vendor/livewire/flux/src/../stubs/resources/views/flux/toast/index.blade.php}:{1784098722} ?>
<?php # [BlazeFolded]:{flux::toast.group}:{/Applications/XAMPP/xamppfiles/htdocs/laravel/hisebghor/vendor/livewire/flux/src/../stubs/resources/views/flux/toast/group.blade.php}:{1784098722} ?>
<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <?php echo $__env->make('partials.head', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</head>
<body class="hg-auth-body">
    <?php
        $brand = \App\Support\HisebGhorBrand::data();
    ?>
    <main class="hg-auth-page">
        <section class="hg-auth-shell" aria-label="HisebGhor authentication">
            <aside class="hg-auth-intro">
                <div class="hg-auth-decoration hg-auth-decoration-one" aria-hidden="true"></div>
                <div class="hg-auth-decoration hg-auth-decoration-two" aria-hidden="true"></div>

                <a href="<?php echo e(route('home')); ?>" class="hg-auth-brand" wire:navigate>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(!empty($brand['logo_url'])): ?>
                        <span class="hg-auth-brand-mark hg-auth-brand-image"><img src="<?php echo e($brand['logo_url']); ?>" alt="<?php echo e($brand['name']); ?> logo"></span>
                    <?php else: ?>
                        <span class="hg-auth-brand-mark" aria-hidden="true">HG</span>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    <span class="hg-auth-brand-copy">
                        <strong><?php echo e($brand['name'] ?? 'HisebGhor'); ?></strong>
                        <small>Smart Accounting Workspace</small>
                    </span>
                </a>

                <div class="hg-auth-intro-content">
                    <span class="hg-auth-eyebrow">Accounting made understandable</span>
                    <h1>Run daily accounts with clarity and confidence.</h1>
                    <div class="hg-auth-benefits" aria-label="HisebGhor benefits">
                        <div class="hg-auth-benefit">
                            <span class="hg-auth-benefit-icon" aria-hidden="true">
                                <svg viewBox="0 0 24 24" fill="none">
                                    <path d="m7.5 12 3 3 6-7" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                    <path d="M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18Z" stroke="currentColor" stroke-width="1.7"/>
                                </svg>
                            </span>
                            <span><strong>Automatic journal flow</strong><small>Accounting rules handle debit and credit posting.</small></span>
                        </div>
                        <div class="hg-auth-benefit">
                            <span class="hg-auth-benefit-icon" aria-hidden="true">
                                <svg viewBox="0 0 24 24" fill="none">
                                    <path d="M4 19V9m5 10V5m6 14v-7m5 7V3" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/>
                                </svg>
                            </span>
                            <span><strong>Clear business overview</strong><small>See balances, transactions and statements together.</small></span>
                        </div>
                        <div class="hg-auth-benefit">
                            <span class="hg-auth-benefit-icon" aria-hidden="true">
                                <svg viewBox="0 0 24 24" fill="none">
                                    <path d="M7 10V8a5 5 0 0 1 10 0v2" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/>
                                    <rect x="4" y="10" width="16" height="11" rx="3" stroke="currentColor" stroke-width="1.8"/>
                                    <path d="M12 14v3" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/>
                                </svg>
                            </span>
                            <span><strong>Protected workspace</strong><small>Your company records stay inside your secured account.</small></span>
                        </div>
                    </div>
                </div>

                <p class="hg-auth-intro-footer">Simple setup. Reliable records. Better decisions.</p>
            </aside>

            <section class="hg-auth-panel">
                <div class="hg-auth-mobile-brand">
                    <a href="<?php echo e(route('home')); ?>" class="hg-auth-brand" wire:navigate>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(!empty($brand['logo_url'])): ?>
                        <span class="hg-auth-brand-mark hg-auth-brand-image"><img src="<?php echo e($brand['logo_url']); ?>" alt="<?php echo e($brand['name']); ?> logo"></span>
                    <?php else: ?>
                        <span class="hg-auth-brand-mark" aria-hidden="true">HG</span>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        <span class="hg-auth-brand-copy">
                            <strong><?php echo e($brand['name'] ?? 'HisebGhor'); ?></strong>
                            <small>Smart Accounting Workspace</small>
                        </span>
                    </a>
                </div>

                <div class="hg-auth-form-wrap">
                    <?php echo e($slot); ?>

                </div>

                <?php if (isset($component)) { $__componentOriginal2406b976bc9b7a352210f63b9be43324 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2406b976bc9b7a352210f63b9be43324 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.accounting.footer','data' => ['brand' => $brand,'class' => 'hg-auth-system-footer']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('accounting.footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['brand' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($brand),'class' => 'hg-auth-system-footer']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2406b976bc9b7a352210f63b9be43324)): ?>
<?php $attributes = $__attributesOriginal2406b976bc9b7a352210f63b9be43324; ?>
<?php unset($__attributesOriginal2406b976bc9b7a352210f63b9be43324); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2406b976bc9b7a352210f63b9be43324)): ?>
<?php $component = $__componentOriginal2406b976bc9b7a352210f63b9be43324; ?>
<?php unset($__componentOriginal2406b976bc9b7a352210f63b9be43324); ?>
<?php endif; ?>
            </section>
        </section>
    </main>

    <?php app("livewire")->forceAssetInjection(); ?><div x-persist="<?php echo e('toast'); ?>">
        <?php ob_start(); ?><ui-toast-group x-data x-on:toast-show.document="$el.showToast($event.detail)" popover="manual" position="bottom end"  wire:ignore>
    <?php ob_start(); ?>
            <?php ob_start(); ?><ui-toast x-data x-on:toast-show.document="! $el.closest('ui-toast-group') && $el.showToast($event.detail)" popover="manual" position="bottom end" wire:ignore>
    <template>
        <div class="max-w-sm in-[ui-toast-group]:max-w-auto in-[ui-toast-group]:w-xs sm:in-[ui-toast-group]:w-sm" data-variant="" data-flux-toast-dialog>
            <div class="p-2 flex rounded-xl shadow-lg bg-white border border-zinc-200 border-b-zinc-300/80 dark:bg-zinc-700 dark:border-zinc-600">
                <div class="flex-1 flex items-start gap-4 overflow-hidden">
                    <div class="flex-1 py-1.5 ps-2.5 flex gap-2">
                        
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" fill="currentColor" class="hidden [[data-flux-toast-dialog][data-variant=success]_&]:block shrink-0 mt-0.5 size-4 text-lime-600 dark:text-lime-400">
                            <path fill-rule="evenodd" d="M8 15A7 7 0 1 0 8 1a7 7 0 0 0 0 14Zm3.844-8.791a.75.75 0 0 0-1.188-.918l-3.7 4.79-1.649-1.833a.75.75 0 1 0-1.114 1.004l2.25 2.5a.75.75 0 0 0 1.15-.043l4.25-5.5Z" clip-rule="evenodd" />
                        </svg>

                        
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" fill="currentColor" class="hidden [[data-flux-toast-dialog][data-variant=warning]_&]:block shrink-0 mt-0.5 size-4 text-amber-500 dark:text-amber-400">
                            <path fill-rule="evenodd" d="M6.701 2.25c.577-1 2.02-1 2.598 0l5.196 9a1.5 1.5 0 0 1-1.299 2.25H2.804a1.5 1.5 0 0 1-1.3-2.25l5.197-9ZM8 4a.75.75 0 0 1 .75.75v3a.75.75 0 1 1-1.5 0v-3A.75.75 0 0 1 8 4Zm0 8a1 1 0 1 0 0-2 1 1 0 0 0 0 2Z" clip-rule="evenodd" />
                        </svg>

                        
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" fill="currentColor" class="hidden [[data-flux-toast-dialog][data-variant=info]_&]:block shrink-0 mt-0.5 size-4 text-cyan-500 dark:text-cyan-400">
                            <path fill-rule="evenodd" d="M15 8A7 7 0 1 1 1 8a7 7 0 0 1 14 0ZM9 5a1 1 0 1 1-2 0 1 1 0 0 1 2 0ZM6.75 8a.75.75 0 0 0 0 1.5h.75v1.75a.75.75 0 0 0 1.5 0v-2.5A.75.75 0 0 0 8.25 8h-1.5Z" clip-rule="evenodd" />
                        </svg>
                        
                        
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" fill="currentColor" class="hidden [[data-flux-toast-dialog][data-variant=danger]_&]:block shrink-0 mt-0.5 size-4 text-rose-500 dark:text-rose-400">
                            <path fill-rule="evenodd" d="M8 15A7 7 0 1 0 8 1a7 7 0 0 0 0 14ZM8 4a.75.75 0 0 1 .75.75v3a.75.75 0 0 1-1.5 0v-3A.75.75 0 0 1 8 4Zm0 8a1 1 0 1 0 0-2 1 1 0 0 0 0 2Z" clip-rule="evenodd" />
                        </svg>

                        <div>
                            
                            <div class="font-medium text-sm text-zinc-800 dark:text-white [&:not(:empty)+div]:font-normal [&:not(:empty)+div]:text-zinc-500 [&:not(:empty)+div]:dark:text-zinc-300 [&:not(:empty)]:pb-2"><slot name="heading"></slot></div>

                            
                            <div class="font-medium text-sm text-zinc-800 dark:text-white"><slot name="text"></slot></div>
                        </div>
                    </div>

                    
                    <ui-close class="flex items-center">
                        <button type="button" class="inline-flex items-center font-medium justify-center gap-2 truncate disabled:opacity-50 dark:disabled:opacity-75 disabled:cursor-default h-8 text-sm rounded-md w-8 bg-transparent hover:bg-zinc-800/5 dark:hover:bg-white/15 text-zinc-400 hover:text-zinc-800 dark:text-zinc-400 dark:hover:text-white" as="button">
                            <div>
                                <svg class="[:where(&)]:size-5" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true" data-slot="icon">
                                    <path d="M6.28 5.22a.75.75 0 0 0-1.06 1.06L8.94 10l-3.72 3.72a.75.75 0 1 0 1.06 1.06L10 11.06l3.72 3.72a.75.75 0 1 0 1.06-1.06L11.06 10l3.72-3.72a.75.75 0 0 0-1.06-1.06L10 8.94 6.28 5.22Z"></path>
                                </svg>
                            </div>
                        </button>
                    </ui-close>
                </div>
            </div>
        </div>
    </template>
</ui-toast>
<?php echo ltrim(ob_get_clean()); ?>
        <?php echo trim(ob_get_clean()); ?>

</ui-toast-group>
<?php echo ltrim(ob_get_clean()); ?>
    </div>

    <?php app('livewire')->forceAssetInjection(); ?>
<?php echo app('flux')->scripts(); ?>

</body>
</html>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel/hisebghor/resources/views/layouts/auth/simple.blade.php ENDPATH**/ ?>