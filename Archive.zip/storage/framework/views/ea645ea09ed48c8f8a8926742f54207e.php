<?php if (isset($component)) { $__componentOriginal9bfc79a588c44096104b78e73dee62a6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9bfc79a588c44096104b78e73dee62a6 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'f4ac99e09542ff494432bc959d4fee61::accounting','data' => ['title' => 'Journal Entries']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layouts::accounting'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Journal Entries']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

    <div class="hg-page-header">
        <div>
            <h1>Journal Entries</h1>
        </div>
    </div>

    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($journalLines->isEmpty()): ?>
        <div class="hg-empty">No records found.</div>
    <?php else: ?>
        <div class="hg-table-wrap">
            <table class="hg-table">
                <thead>
                <tr>
                    <th>Voucher</th>
                    <th>Type</th>
                    <th>Account</th>
                    <th class="right">Debit</th>
                    <th class="right">Credit</th>
                </tr>
                </thead>
                <tbody>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $journalLines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $line): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                    <?php
                        $transaction = $line->journalEntry?->transaction;
                    ?>
                    <tr>
                        <td><strong><?php echo e($line->journalEntry?->voucher_no); ?></strong><br><span class="hg-muted"><?php echo e($line->journalEntry?->entry_date?->format('Y-m-d')); ?></span></td>
                        <td><span class="hg-badge <?php echo e(strtolower($transaction?->category ?? '')); ?>"><?php echo e($categoryLabels[$transaction?->category] ?? $transaction?->category); ?></span></td>
                        <td>
                            <?php echo e($line->chartOfAccount?->code); ?> — <?php echo e($line->chartOfAccount?->name); ?>

                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($line->moneyAccount): ?>
                                <br><small class="hg-muted">Money Account: <?php echo e($line->moneyAccount->name); ?></small>
                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </td>
                        <td class="right"><?php echo e(\App\Support\CompanyContext::money((float) $line->debit)); ?></td>
                        <td class="right"><?php echo e(\App\Support\CompanyContext::money((float) $line->credit)); ?></td>
                    </tr>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9bfc79a588c44096104b78e73dee62a6)): ?>
<?php $attributes = $__attributesOriginal9bfc79a588c44096104b78e73dee62a6; ?>
<?php unset($__attributesOriginal9bfc79a588c44096104b78e73dee62a6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9bfc79a588c44096104b78e73dee62a6)): ?>
<?php $component = $__componentOriginal9bfc79a588c44096104b78e73dee62a6; ?>
<?php unset($__componentOriginal9bfc79a588c44096104b78e73dee62a6); ?>
<?php endif; ?>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel/hisebghor/resources/views/journal-entries/index.blade.php ENDPATH**/ ?>