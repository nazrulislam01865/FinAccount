<section class="section pricing-section" id="pricing">
  <div class="container">
    <?php echo $__env->make('landing.components.section-title', [
      'mini' => data_get($landing, 'pricing.mini'),
      'title' => data_get($landing, 'pricing.title'),
      'subtitle' => data_get($landing, 'pricing.subtitle'),
    ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <div class="packages implementation-packages">
      <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = data_get($landing, 'packages', []); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $package): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
        <?php
          $feeRows = [
            ['key' => 'installation', 'icon' => 'wallet'],
            ['key' => 'maintenance', 'icon' => 'settings'],
            ['key' => 'hosting', 'icon' => 'server'],
          ];
        ?>

        <article class="package implementation-package">

          <div class="package-heading-row">
            <div class="package-heading-main">
              <span class="package-icon-badge">
                <?php echo $__env->make('landing.components.pricing-icon', ['icon' => data_get($package, 'icon', 'cloud')], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
              </span>
              <h3 data-bn="<?php echo e($txt(data_get($package, 'name'), 'bn')); ?>"
                  data-en="<?php echo e($txt(data_get($package, 'name'), 'en')); ?>">
                <?php echo e($txt(data_get($package, 'name'), $defaultLang)); ?>

              </h3>
            </div>

            <span class="package-small-tag"
                  data-bn="<?php echo e($txt(data_get($package, 'tag'), 'bn')); ?>"
                  data-en="<?php echo e($txt(data_get($package, 'tag'), 'en')); ?>">
              <?php echo e($txt(data_get($package, 'tag'), $defaultLang)); ?>

            </span>
          </div>

          <p class="package-description"
             data-bn="<?php echo e($txt(data_get($package, 'body'), 'bn')); ?>"
             data-en="<?php echo e($txt(data_get($package, 'body'), 'en')); ?>">
            <?php echo e($txt(data_get($package, 'body'), $defaultLang)); ?>

          </p>

          <div class="package-fees">
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $feeRows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feeRow): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
              <?php ($feePath = 'fees.'.$feeRow['key']); ?>
              <div class="package-fee-row">
                <span class="fee-icon-badge">
                  <?php echo $__env->make('landing.components.pricing-icon', ['icon' => $feeRow['icon']], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                </span>
                <div class="package-fee-copy">
                  <span class="package-fee-label"
                        data-bn="<?php echo e($txt(data_get($package, $feePath.'.label'), 'bn')); ?>"
                        data-en="<?php echo e($txt(data_get($package, $feePath.'.label'), 'en')); ?>">
                    <?php echo e($txt(data_get($package, $feePath.'.label'), $defaultLang)); ?>

                  </span>
                  <strong><?php echo e(data_get($package, $feePath.'.amount')); ?></strong>
                  <small data-bn="<?php echo e($txt(data_get($package, $feePath.'.note'), 'bn')); ?>"
                         data-en="<?php echo e($txt(data_get($package, $feePath.'.note'), 'en')); ?>">
                    <?php echo e($txt(data_get($package, $feePath.'.note'), $defaultLang)); ?>

                  </small>
                </div>
              </div>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
          </div>

          <ul class="package-feature-list">
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = data_get($package, 'features', []); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feature): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
              <li data-bn="<?php echo e($txt($feature, 'bn')); ?>"
                  data-en="<?php echo e($txt($feature, 'en')); ?>">
                <?php echo e($txt($feature, $defaultLang)); ?>

              </li>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
          </ul>
        </article>
      <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
    </div>

    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(count(data_get($landing, 'pricing_notes', []))): ?>
      <div class="important-notes-heading">
        <span></span>
        <div>
          <span class="important-note-icon">i</span>
          <strong data-bn="<?php echo e($txt(data_get($landing, 'pricing.notes_title'), 'bn', 'Important Notes')); ?>"
                  data-en="<?php echo e($txt(data_get($landing, 'pricing.notes_title'), 'en', 'Important Notes')); ?>">
            <?php echo e($txt(data_get($landing, 'pricing.notes_title'), $defaultLang, 'Important Notes')); ?>

          </strong>
        </div>
        <span></span>
      </div>

      <div class="pricing-notes-grid">
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = data_get($landing, 'pricing_notes', []); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $note): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
          <article class="pricing-note-card">
            <span class="pricing-note-icon">
              <?php echo $__env->make('landing.components.pricing-icon', ['icon' => data_get($note, 'icon', 'tag')], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            </span>
            <div>
              <h3 data-bn="<?php echo e($txt(data_get($note, 'title'), 'bn')); ?>"
                  data-en="<?php echo e($txt(data_get($note, 'title'), 'en')); ?>">
                <?php echo e($txt(data_get($note, 'title'), $defaultLang)); ?>

              </h3>
              <p data-bn="<?php echo e($txt(data_get($note, 'body'), 'bn')); ?>"
                 data-en="<?php echo e($txt(data_get($note, 'body'), 'en')); ?>">
                <?php echo e($txt(data_get($note, 'body'), $defaultLang)); ?>

              </p>
            </div>
          </article>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
      </div>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
  </div>
</section>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel/hisebghor/resources/views/landing/components/pricing.blade.php ENDPATH**/ ?>