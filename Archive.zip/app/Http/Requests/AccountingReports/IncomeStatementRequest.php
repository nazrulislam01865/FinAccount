<?php

namespace App\Http\Requests\AccountingReports;

use App\Services\Accounting\FinancialYearService;
use Illuminate\Foundation\Http\FormRequest;

class IncomeStatementRequest extends FormRequest
{
    public function authorize(): bool
    {
        return (bool) $this->user()?->hasPermission('reports.full');
    }

    public function rules(): array
    {
        return [
            'q' => ['nullable', 'string', 'max:120'],
            'from_date' => ['nullable', 'date'],
            'to_date' => ['nullable', 'date', 'after_or_equal:from_date'],
            'section' => ['nullable', 'in:All,Revenue,Cost of Sales,Cost of Services,Operating Expenses,Administrative & Selling Expenses,Financial Expenses,Other Income / Loss,Income Tax Expense'],
            'statement_format' => ['nullable', 'in:management,audit'],
            'basis' => ['nullable', 'in:Accrual'],
        ];
    }

    public function filters(): array
    {
        $range = app(FinancialYearService::class)->reportRange((int) ($this->user()?->company_id ?? 0));
        $section = (string) $this->input('section', 'All');

        if ($section === 'Cost of Sales') {
            $section = 'Cost of Services';
        }

        if ($section === 'Operating Expenses') {
            $section = 'Administrative & Selling Expenses';
        }

        return [
            'q' => $this->input('q'),
            'from_date' => $this->input('from_date', $range['from_date']),
            'to_date' => $this->input('to_date', $range['to_date']),
            'section' => $section,
            'statement_format' => $this->input('statement_format', 'management'),
            'basis' => 'Accrual',
        ];
    }
}
