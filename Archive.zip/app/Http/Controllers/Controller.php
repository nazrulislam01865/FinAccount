<?php

namespace App\Http\Controllers;

abstract class Controller
{
    // Base controller for Laravel 11/12 lightweight skeletons.
}
