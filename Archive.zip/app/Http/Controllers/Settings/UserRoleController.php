<?php

namespace App\Http\Controllers\Settings;

use App\AccountingEngine\Services\AuditTrailService;
use App\Http\Controllers\Concerns\RespondsToDelete;
use App\Http\Controllers\Controller;
use App\Models\Permission;
use App\Models\Role;
use App\Models\User;
use App\Services\Setup\EntityDeleteService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Validation\Rule;
use Illuminate\Validation\Rules\Password;
use Illuminate\View\View;
use Throwable;

class UserRoleController extends Controller
{
    use RespondsToDelete;

    public function index(Request $request): View
    {
        $actor = $request->user();

        $users = User::query()
            ->with(['roles.permissions', 'directPermissions'])
            ->orderBy('name')
            ->get();

        $roles = Role::query()
            ->with('permissions')
            ->where('status', 'Active')
            ->orderBy('level')
            ->orderBy('name')
            ->get();

        $permissionLabels = collect(config('access.permissions', []));
        $permissionRows = $permissionLabels
            ->map(fn (string $label, string $name) => [
                'name' => $name,
                'label' => $label,
                'module' => $this->permissionModule($name),
            ])
            ->values();

        $userPermissionMatrix = $users->mapWithKeys(function (User $user) {
            return [
                (int) $user->id => $user->directPermissions
                    ->pluck('name')
                    ->mapWithKeys(fn (string $name) => [$name => true])
                    ->all(),
            ];
        });

        $assignableRoleIds = $actor?->manageableRoleIds($roles) ?? [];

        return view('settings.users-roles', [
            'users' => $users,
            'roles' => $roles,
            'assignableRoleIds' => $assignableRoleIds,
            'permissionRows' => $permissionRows,
            'userPermissionMatrix' => $userPermissionMatrix,
            'canManageUsers' => $actor?->hasPermission('users.manage') ?? false,
            'canManageUserPermissions' => $actor?->hasPermission('roles.manage') ?? false,
        ]);
    }

    public function storeUser(Request $request): JsonResponse
    {
        $actor = $request->user();
        abort_unless($actor?->hasPermission('users.manage'), 403, 'You are not allowed to create users.');

        $data = $request->validate([
            'name' => ['required', 'string', 'max:255'],
            'email' => ['required', 'email', 'max:255', 'unique:users,email'],
            'password' => ['required', 'confirmed', Password::min(8)],
            'role_ids' => ['required', 'array', 'size:1'],
            'role_ids.*' => ['integer', Rule::exists('roles', 'id')->where(fn ($query) => $query->where('status', 'Active'))],
            'status' => ['required', Rule::in(['Active', 'Inactive'])],
        ]);

        $roleIds = $this->authorizedRoleIds($actor, $data['role_ids']);

        $user = DB::transaction(function () use ($data, $roleIds) {
            $user = User::create([
                'name' => $data['name'],
                'email' => $data['email'],
                'password' => Hash::make($data['password']),
                'status' => $data['status'],
                'uses_direct_permissions' => true,
            ]);

            $user->roles()->sync($roleIds);
            $this->syncUserPermissionsFromRoles($user, $roleIds);

            return $user;
        });

        $this->auditSecurityChange(
            'USER_CREATED',
            null,
            [
                'user_id' => $user->id,
                'email' => $user->email,
                'status' => $user->status,
                'role_ids' => $roleIds,
            ],
            $actor
        );

        return response()->json([
            'success' => true,
            'message' => 'User created successfully.',
            'data' => $user->load('roles'),
            'redirect' => route('settings.users-roles'),
        ], 201);
    }

    public function updateUser(Request $request, User $user): JsonResponse
    {
        $actor = $request->user();
        abort_unless($actor?->canManageUser($user), 403, 'You cannot update this user because of role hierarchy rules.');

        $data = $request->validate([
            'name' => ['required', 'string', 'max:255'],
            'email' => ['required', 'email', 'max:255', Rule::unique('users', 'email')->ignore($user->id)],
            'password' => ['nullable', 'confirmed', Password::min(8)],
            'role_ids' => ['required', 'array', 'size:1'],
            'role_ids.*' => ['integer', Rule::exists('roles', 'id')->where(fn ($query) => $query->where('status', 'Active'))],
            'status' => ['required', Rule::in(['Active', 'Inactive'])],
        ]);

        $roleIds = $this->authorizedRoleIds($actor, $data['role_ids']);
        $this->guardLastSuperAdmin($user, $roleIds, $data['status']);

        $oldUserAudit = [
            'user_id' => $user->id,
            'email' => $user->email,
            'status' => $user->status,
            'role_ids' => $user->roles()->pluck('roles.id')->map(fn ($id) => (int) $id)->values()->all(),
        ];

        DB::transaction(function () use ($user, $data, $roleIds) {
            $payload = [
                'name' => $data['name'],
                'email' => $data['email'],
                'status' => $data['status'],
                'uses_direct_permissions' => true,
            ];

            if (!empty($data['password'])) {
                $payload['password'] = Hash::make($data['password']);
            }

            $user->update($payload);
            $user->roles()->sync($roleIds);
            $this->syncUserPermissionsFromRoles($user, $roleIds);
        });

        $freshUser = $user->fresh(['roles', 'directPermissions']);

        $this->auditSecurityChange(
            'USER_UPDATED',
            $oldUserAudit,
            [
                'user_id' => $freshUser->id,
                'email' => $freshUser->email,
                'status' => $freshUser->status,
                'role_ids' => $freshUser->roles->pluck('id')->map(fn ($id) => (int) $id)->values()->all(),
            ],
            $actor
        );

        return response()->json([
            'success' => true,
            'message' => 'User updated successfully.',
            'data' => $freshUser,
            'redirect' => route('settings.users-roles'),
        ]);
    }

    public function destroyUser(
        Request $request,
        User $user,
        EntityDeleteService $deleteService
    ): JsonResponse|RedirectResponse {
        $actor = $request->user();
        abort_unless($actor?->canManageUser($user), 403, 'You cannot delete this user because of role hierarchy rules.');
        $this->guardLastSuperAdmin($user, [], 'Inactive', deleting: true);

        $oldUserAudit = [
            'user_id' => $user->id,
            'email' => $user->email,
            'status' => $user->status,
            'role_ids' => $user->roles()->pluck('roles.id')->map(fn ($id) => (int) $id)->values()->all(),
        ];

        try {
            $deleteService->deleteUser($user->id);
        } catch (Throwable $exception) {
            return $this->deleteFailure(
                $request,
                'settings.users-roles',
                'This user could not be deleted. Please try again or check related records.',
                $exception
            );
        }

        $this->auditSecurityChange('USER_DELETED', $oldUserAudit, null, $actor);

        return $this->deleteSuccess(
            $request,
            'settings.users-roles',
            'User deleted successfully.'
        );
    }

    public function updateRolePermissions(Request $request): JsonResponse
    {
        $actor = $request->user();
        abort_unless($actor?->hasPermission('roles.manage'), 403, 'You are not allowed to update user permission access.');

        $data = $request->validate([
            'permissions' => ['required', 'array'],
            'permissions.*' => ['array'],
        ]);

        $userIds = collect(array_keys($data['permissions']))
            ->map(fn ($id) => (int) $id)
            ->filter()
            ->unique()
            ->values();

        $users = User::query()
            ->whereIn('id', $userIds)
            ->with(['roles', 'directPermissions'])
            ->get()
            ->keyBy(fn (User $user) => (int) $user->id);

        if ($users->count() !== $userIds->count()) {
            abort(422, 'One or more selected users are invalid.');
        }

        $permissionIdsByName = Permission::query()->pluck('id', 'name');
        $allPermissionIds = $permissionIdsByName->values()->map(fn ($id) => (int) $id)->all();
        $configuredPermissionNames = array_keys(config('access.permissions', []));

        $oldMatrixAudit = $users
            ->mapWithKeys(fn (User $user) => [
                $user->name.' <'.$user->email.'>' => $user->directPermissions->pluck('name')->sort()->values()->all(),
            ])
            ->all();

        DB::transaction(function () use ($actor, $data, $users, $permissionIdsByName, $allPermissionIds, $configuredPermissionNames) {
            foreach ($data['permissions'] as $userId => $permissionPayload) {
                $targetUser = $users->get((int) $userId);

                if (!$targetUser) {
                    abort(422, 'One or more selected users are invalid.');
                }

                if ($targetUser->hasFixedFullAccessRole()) {
                    $targetUser->directPermissions()->sync($allPermissionIds);
                    $targetUser->forceFill(['uses_direct_permissions' => true])->save();
                    continue;
                }

                if (!$actor->canManageUser($targetUser)) {
                    abort(403, 'You cannot update access for '.$targetUser->name.' because of role hierarchy rules.');
                }

                $selectedPermissionIds = collect($permissionPayload)
                    ->filter(fn ($value) => in_array((string) $value, ['1', 'true', 'on', 'yes'], true))
                    ->keys()
                    ->filter(fn ($permissionName) => in_array((string) $permissionName, $configuredPermissionNames, true))
                    ->map(fn ($permissionName) => $permissionIdsByName[$permissionName] ?? null)
                    ->filter()
                    ->map(fn ($id) => (int) $id)
                    ->unique()
                    ->values()
                    ->all();

                $targetUser->directPermissions()->sync($selectedPermissionIds);
                $targetUser->forceFill(['uses_direct_permissions' => true])->save();
                $targetUser->flushAccessCache();
            }
        });

        $newMatrixAudit = User::query()
            ->whereIn('id', $users->keys())
            ->with('directPermissions')
            ->get()
            ->mapWithKeys(fn (User $user) => [
                $user->name.' <'.$user->email.'>' => $user->directPermissions->pluck('name')->sort()->values()->all(),
            ])
            ->all();

        $this->auditSecurityChange('USER_PERMISSION_MATRIX_UPDATED', $oldMatrixAudit, $newMatrixAudit, $actor);

        return response()->json([
            'success' => true,
            'message' => 'User access matrix updated successfully.',
            'redirect' => route('settings.users-roles'),
        ]);
    }

    /**
     * @param array<string, mixed>|null $oldValues
     * @param array<string, mixed>|null $newValues
     */
    private function auditSecurityChange(string $action, ?array $oldValues, ?array $newValues, ?User $actor): void
    {
        try {
            app(AuditTrailService::class)->recordAction(
                'SecurityAccess',
                $action,
                $oldValues,
                $newValues,
                $actor?->id,
                ['source' => 'users_roles_matrix'],
                (int) ($actor?->company_id ?? 0) ?: null
            );
        } catch (Throwable) {
            // Audit logging must not block security administration.
        }
    }

    private function authorizedRoleIds(User $actor, array $requestedRoleIds): array
    {
        $requestedRoleIds = collect($requestedRoleIds)->map(fn ($id) => (int) $id)->unique()->values();
        $roles = Role::query()->whereIn('id', $requestedRoleIds)->where('status', 'Active')->get();

        if ($roles->count() !== $requestedRoleIds->count()) {
            abort(422, 'One or more selected roles are invalid.');
        }

        $blockedRole = $roles->first(fn (Role $role) => !$actor->canAssignRole($role));

        if ($blockedRole) {
            abort(403, 'You cannot assign the '.$blockedRole->name.' role because it is at your level or above.');
        }

        return $requestedRoleIds->all();
    }

    private function syncUserPermissionsFromRoles(User $user, array $roleIds): void
    {
        $permissionIds = $this->permissionIdsForRoles($roleIds);

        $user->directPermissions()->sync($permissionIds);
        $user->forceFill(['uses_direct_permissions' => true])->save();
        $user->flushAccessCache();
    }

    /**
     * @param array<int, int|string> $roleIds
     * @return array<int, int>
     */
    private function permissionIdsForRoles(array $roleIds): array
    {
        $roles = Role::query()
            ->whereIn('id', collect($roleIds)->map(fn ($id) => (int) $id)->all())
            ->with('permissions')
            ->get();

        if ($roles->contains(fn (Role $role) => $role->isFixedFullAccessRole())) {
            return Permission::query()
                ->pluck('id')
                ->map(fn ($id) => (int) $id)
                ->all();
        }

        return $roles
            ->flatMap(fn (Role $role) => $role->permissions->pluck('id'))
            ->map(fn ($id) => (int) $id)
            ->unique()
            ->values()
            ->all();
    }

    private function permissionModule(string $permission): string
    {
        $prefix = str($permission)->before('.')->headline()->toString();

        return match ($prefix) {
            'Cash Bank' => 'Cash / Bank',
            'Chart Of Accounts' => 'Chart of Accounts',
            'Due Management' => 'Due Management',
            'Advance Management' => 'Advance Management',
            'Ledger Mapping' => 'Accounting Rules',
            'Ledger Report' => 'Ledger Report',
            'Master Data' => 'Master Data',
            'Opening Balances' => 'Opening Balance',
            'Sales Invoices' => 'Sales Invoice',
            'Purchase Bills' => 'Purchase Bill',
            'Transaction Heads' => 'Transaction Heads',
            'Transactions' => 'Transaction Entry',
            'Voucher Numbering' => 'Voucher Numbering',
            default => $prefix,
        };
    }

    private function guardLastSuperAdmin(User $user, array $newRoleIds, string $newStatus, bool $deleting = false): void
    {
        if (!$user->isSuperAdmin()) {
            return;
        }

        $superAdminRoleId = Role::query()->where('name', 'Super Admin')->value('id');
        $keepsSuperAdminRole = !$deleting && in_array((int) $superAdminRoleId, array_map('intval', $newRoleIds), true);
        $keepsActiveStatus = !$deleting && $newStatus === 'Active';

        if ($keepsSuperAdminRole && $keepsActiveStatus) {
            return;
        }

        $otherActiveSuperAdmins = User::query()
            ->where('id', '!=', $user->id)
            ->where('status', 'Active')
            ->whereHas('roles', fn ($query) => $query->where('name', 'Super Admin')->where('status', 'Active'))
            ->exists();

        abort_unless($otherActiveSuperAdmins, 422, 'At least one active Super Admin must remain in the system.');
    }
}
